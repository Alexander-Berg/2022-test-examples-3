
(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"300x250_1_atlas_", frames: [[0,0,1210,1218],[1212,0,338,500]]}
];


// symbols:



(lib.fon012 = function() {
	this.spriteSheet = ss["300x250_1_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.person01s = function() {
	this.spriteSheet = ss["300x250_1_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.person01s();
	this.instance.parent = this;
	this.instance.setTransform(-58.2,-86.2,0.345,0.345);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-58.2,-86.2,116.6,172.4);


(lib.Tween19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.person01s();
	this.instance.parent = this;
	this.instance.setTransform(-58.2,-86.2,0.345,0.345);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-58.2,-86.2,116.6,172.4);


(lib.Tween18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.person01s();
	this.instance.parent = this;
	this.instance.setTransform(-58.2,-86.2,0.345,0.345);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-58.2,-86.2,116.6,172.4);


(lib.Tween17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.person01s();
	this.instance.parent = this;
	this.instance.setTransform(-58.2,-86.2,0.345,0.345);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-58.2,-86.2,116.6,172.4);


(lib.Tween16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.person01s();
	this.instance.parent = this;
	this.instance.setTransform(-58.2,-86.2,0.345,0.345);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-58.2,-86.2,116.6,172.4);


(lib.Tween14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.fon012();
	this.instance.parent = this;
	this.instance.setTransform(-82.3,-82.9,0.136,0.136);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-82.3,-82.9,164.8,165.9);


(lib.Tween13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.fon012();
	this.instance.parent = this;
	this.instance.setTransform(-82.3,-82.9,0.136,0.136);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-82.3,-82.9,164.8,165.9);


(lib.Tween12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.fon012();
	this.instance.parent = this;
	this.instance.setTransform(-82.4,-82.9,0.136,0.136);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-82.4,-82.9,164.8,165.9);


(lib.Tween11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.fon012();
	this.instance.parent = this;
	this.instance.setTransform(-82.3,-82.9,0.136,0.136);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-82.3,-82.9,164.8,165.9);


(lib.Tween10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.fon012();
	this.instance.parent = this;
	this.instance.setTransform(-82.3,-82.9,0.136,0.136);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-82.3,-82.9,164.8,165.9);


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgiAvIAAhdIAQAAIAAAgIAQAAQARAAAKAIQAKAGAAAQQAAAIgDAFQgCAHgGADQgFAFgHABQgHACgIAAgAgSAiIAPAAQAJgBAHgEQAGgEAAgIQAAgKgGgEQgFgDgKAAIgQAAg");
	this.shape.setTransform(24.6,0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgHAvIAAhQIgeAAIAAgNIBLAAIAAANIgeAAIAABQg");
	this.shape_1.setTransform(15.5,0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdApQgIgGAAgOQAAgPAKgGQAMgIASAAIASAAIAAgIQAAgJgFgFQgFgEgLAAQgJAAgIADIgOAGIAAgOIAOgGQAIgDAJAAQASAAAKAHQAJAIAAAPIAAAyIAAAEIAAADIAAAFIABADIgOAAIgBgHIgBgIIgBgDIgEAHIgGAHIgJAEQgEACgHAAQgMAAgIgIgAgPAIQgGAEAAAIQAAAGAEAEQAEAFAHAAQAHAAAGgEQAEgDAEgDIAEgIIACgGIAAgHIgQAAQgNAAgHAEg");
	this.shape_2.setTransform(6.4,0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgHAvIAAhQIgeAAIAAgNIBLAAIAAANIgeAAIAABQg");
	this.shape_3.setTransform(-2.6,0.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAZAvIAAhHIgxBHIgQAAIAAhdIAQAAIAABHIAxhHIAQAAIAABdg");
	this.shape_4.setTransform(-12.4,0.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAfBBIAAg5QgPAJgQAAQgXAAgMgLQgMgKAAgYIAAgkIARAAIAAAkQAAAQAIAHQAHAIAPAAQAIAAAIgCQAIgCAHgFIAAg6IARAAIAACBg");
	this.shape_5.setTransform(-24.1,-1.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFD961").s().p("AtIC1QgNAAgIgJQgJgJAAgMIAAktQAAgMAJgJQAIgJANAAIaRAAQANAAAIAJQAJAJAAAMIAAEtQAAAMgJAJQgIAJgNAAg");
	this.shape_6.setTransform(0,0,0.575,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50.1,-18,100.3,36.2);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAaA3IAAgoIgUAAIgcAoIgVAAIAfgsQgLgEgHgHQgGgGAAgMQAAgKAEgGQADgHAGgEQAGgFAJgCQAIgCAKAAIAjAAIAABtgAgKghQgHAEAAAJQAAALAHAEQAGAFAMAAIASAAIAAgmIgQAAQgLAAgJAFg");
	this.shape.setTransform(8.2,28.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgLA1QgLgEgGgHQgIgIgEgKQgDgLAAgNQAAgNADgKQAEgLAIgHQAGgIALgDQALgEALAAQALAAAIACQAJACAGAEIAAARQgIgEgIgDQgJgCgIAAQgTABgJAJQgJALAAATQABAVAIAJQAJALARgBQALABAIgDIAQgGIAAAQQgHAEgIADQgIACgMAAQgLAAgKgEg");
	this.shape_1.setTransform(-2.4,28.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgtA3IgCAAIAAgSIADAAQAKAAAEgQQADgLABgSIABguIBJAAIAABtIgTAAIAAhdIgkAAIgCAnQgBASgEAMQgEAMgGAGQgIAGgLAAg");
	this.shape_2.setTransform(-13.8,28.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAaA3IAAgoIgUAAIgcAoIgWAAIAggsQgMgEgFgHQgHgGAAgMQAAgKADgGQAEgHAGgEQAGgFAJgCQAIgCAJAAIAkAAIAABtgAgJghQgIAEAAAJQAAALAHAEQAHAFALAAIASAAIAAgmIgRAAQgLAAgHAFg");
	this.shape_3.setTransform(-25.2,28.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("Ag0BLIAAiTIARAAIACAWQAGgLAJgHQAJgGANAAQAJAAAJAEQAJADAHAHQAGAHAEALQAFALAAAOQgBAPgEAJQgEALgHAHQgGAHgKAEQgIADgKAAQgMAAgJgGQgJgFgGgLIAAA6gAgMg3QgGADgFAFQgEAFgDAHQgDAIAAAKQAAAKADAHQADAIAEAFQAFAFAGACQAGADAGAAQAPAAAJgKQAJgKAAgUQAAgUgJgKQgJgKgPAAQgGAAgGACg");
	this.shape_4.setTransform(-36.4,30.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgiAqQgOgPAAgbQAAgNAEgKQADgLAIgHQAHgIAJgDQAKgEAKAAQAMAAAJAEQAJAEAHAHQAGAJACALQACAMgCAOIhNAAQABASAKAIQAJAKASgBQANABAJgEQAJgDAGgFIAAARIgFADIgIAEIgLADIgPABQgbAAgOgPgAgRggQgJAHgCAQIA6AAQABgQgIgIQgIgHgNAAQgKAAgJAIg");
	this.shape_5.setTransform(-48.9,28.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgJA3IAAhdIgiAAIAAgQIBXAAIAAAQIgjAAIAABdg");
	this.shape_6.setTransform(-59.6,28.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgUA2QgKgFgHgHQgHgHgEgLQgEgKAAgOQAAgMAEgLQAEgLAHgIQAHgHAKgDQAJgEALAAQALAAAKAEQAKADAHAHQAHAIAEALQAEALAAAMQAAAOgEAKQgEALgHAHQgHAHgKAFQgKADgLAAQgLAAgJgDgAgNglQgGACgFAFQgEAGgDAHQgCAHAAAKQAAALACAHQADAIAEAEQAFAFAGADQAGADAHgBQAHABAGgDQAHgDAEgFQAFgEACgIQADgHAAgLQAAgKgDgHQgCgHgFgGQgEgFgHgCQgGgCgHgBQgHABgGACg");
	this.shape_7.setTransform(-70.7,28.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAaA3IAAhdIgyAAIAABdIgTAAIAAhtIBXAAIAABtg");
	this.shape_8.setTransform(-82.7,28.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AghAqQgPgPAAgbQAAgNAEgKQAEgLAHgHQAHgIAKgDQAJgEAKAAQAMAAAJAEQAJAEAHAHQAFAJADALQACAMgCAOIhNAAQABASAKAIQAKAKARgBQANABAJgEQAJgDAHgFIAAARIgHADIgIAEIgKADIgPABQgaAAgOgPgAgRggQgJAHgCAQIA6AAQABgQgIgIQgIgHgMAAQgLAAgJAIg");
	this.shape_9.setTransform(-99,28.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAaA3IAAgxIgzAAIAAAxIgUAAIAAhtIAUAAIAAAuIAzAAIAAguIAUAAIAABtg");
	this.shape_10.setTransform(-110.7,28.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AA2A3IgkgvIgJAAIAAAvIgRAAIAAgvIgKAAIgjAvIgWAAIAqg3Igpg2IAWAAIAiAvIAKAAIAAgvIARAAIAAAvIAKAAIAjgvIAVAAIgpA2IAqA3g");
	this.shape_11.setTransform(48.1,1.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AghAqQgPgPAAgbQAAgMAEgLQADgLAIgHQAHgIAKgEQAJgDAKAAQAMAAAJAEQAJAEAHAHQAFAJADALQACAMgCAOIhNAAQABASAKAIQAKAJARAAQANAAAJgDQAJgEAHgEIAAAQIgHAEIgIAEIgKADIgPABQgbAAgNgPgAgRggQgJAHgCAQIA6AAQABgQgIgIQgIgGgMgBQgLAAgJAIg");
	this.shape_12.setTransform(34.3,1.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgIA3IAAhdIgjAAIAAgQIBXAAIAAAQIgjAAIAABdg");
	this.shape_13.setTransform(23.6,1.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgiAxQgJgJAAgPQgBgTANgHQANgIAWAAIAVAAIAAgJQAAgMgGgFQgGgFgNAAQgKABgKADIgQAHIAAgQQAGgEAKgEQAKgDALAAQAVAAAKAJQAMAIAAASIAAA6IAAAFIAAAEIAAAGIABADIgRAAIgBgJIgBgJIAAgDIgFAIIgIAHQgEAEgGACQgFACgIAAQgPAAgJgIgAgRAKQgHAEAAAKQAAAHAEAFQAFAFAJgBQAHAAAHgDQAGgEAEgFQAEgEABgFIACgHIAAgIIgTAAQgPABgIAFg");
	this.shape_14.setTransform(12.8,1.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgtA3IgCAAIAAgSIACAAQAMAAADgQQADgLABgSIABguIBJAAIAABtIgTAAIAAhdIglAAIgBAnQgBASgDAMQgFAMgHAGQgGAGgNAAg");
	this.shape_15.setTransform(1.2,1.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAaA3IAAhdIgyAAIAABdIgTAAIAAhtIBXAAIAABtg");
	this.shape_16.setTransform(-10.2,1.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAaA3IAAgxIg0AAIAAAxIgTAAIAAhtIATAAIAAAuIA0AAIAAguIATAAIAABtg");
	this.shape_17.setTransform(-26.8,1.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAeA3IAAhTIg6BTIgTAAIAAhtIATAAIAABTIA5hTIATAAIAABtg");
	this.shape_18.setTransform(-39.2,1.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAsBHIgDggIhRAAIgCAgIgRAAIAAgwIAJAAQAFgDAEgIQAEgIACgKQACgMAAgQIABgkIBLAAIAABdIAQAAIAAAwgAgSgEQgEASgGAJIA1AAIAAhNIgoAAQgBAfgCATg");
	this.shape_19.setTransform(-51.9,3.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgUA2QgKgEgHgIQgHgHgEgKQgEgMAAgNQAAgNAEgLQAEgKAHgIQAHgGAKgFQAJgDALAAQALAAAKADQAKAFAHAGQAHAIAEAKQAEALAAANQAAANgEAMQgEAKgHAHQgHAIgKAEQgKADgLAAQgLAAgJgDgAgNglQgGACgFAGQgEAFgDAHQgCAIAAAJQAAALACAHQADAIAEAEQAFAFAGADQAGACAHAAQAHAAAGgCQAHgDAEgFQAFgEACgIQADgHAAgLQAAgJgDgIQgCgHgFgFQgEgGgHgCQgGgDgHAAQgHAAgGADg");
	this.shape_20.setTransform(-64,1.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AAeA3IAAhTIg6BTIgTAAIAAhtIATAAIAABTIA5hTIATAAIAABtg");
	this.shape_21.setTransform(-81,1.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAbA3IAAgxIg0AAIAAAxIgTAAIAAhtIATAAIAAAuIA0AAIAAguIATAAIAABtg");
	this.shape_22.setTransform(-93.4,1.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AAeA3IAAhTIg6BTIgTAAIAAhtIATAAIAABTIA5hTIATAAIAABtg");
	this.shape_23.setTransform(-110.4,1.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgNAYIAEgFIADgGIADgGIABgFQgEgBgDgDQgDgDAAgFQAAgFAEgEQADgEAFAAQAGAAAEAEQAEAEAAAHIgBAJIgEAJIgEAIIgFAGg");
	this.shape_24.setTransform(114.1,-19.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAeA3IAAhTIg6BTIgTAAIAAhtIATAAIAABTIA5hTIATAAIAABtg");
	this.shape_25.setTransform(105.2,-25);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgaA2QgJgCgFgDIAAgRQAHAEAIACQAKADAKAAQALAAAJgFQAIgDAAgKQAAgJgHgFQgHgDgNAAIgPAAIAAgOIAQAAQAKAAAGgEQAGgEAAgJQAAgEgBgCQgDgEgDgCIgIgCIgJAAQgJAAgJACQgIACgHAFIAAgRQAGgEAIgDQAJgCAMAAQATAAAKAIQALAHgBAOQABAMgHAFQgFAGgKADQANABAGAGQAHAHAAAKQAAAJgEAGQgEAHgGAFQgHADgIACQgIACgIAAQgMAAgKgDg");
	this.shape_26.setTransform(93.7,-25);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAeBNIAAhUIg6BUIgTAAIAAhtIATAAIAABTIA5hTIATAAIAABtgAgNgxQgGgCgFgEQgEgEgCgFQgCgGAAgGIATAAQAAAIAEAEQAEAEAGAAQAGAAAEgEQAEgEAAgIIATAAQAAAMgJAJQgIAIgQAAQgIAAgGgCg");
	this.shape_27.setTransform(82.1,-27.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgiAxQgKgJAAgPQAAgSAOgIQAMgIAXgBIAUAAIAAgJQAAgLgGgFQgGgFgOABQgJAAgKACIgQAIIAAgRQAGgDAKgEQAKgDALAAQAVAAALAJQALAIgBASIAAA6IAAAFIABAEIAAAGIAAADIgRAAIgBgJIAAgJIgBgDIgEAIIgHAIQgFADgGACQgFACgIAAQgPAAgJgIgAgRAJQgIAFAAAKQAAAHAFAFQAFAFAJAAQAIAAAFgEQAHgDADgGQAFgFABgEIACgGIAAgIIgTAAQgQAAgHAEg");
	this.shape_28.setTransform(70,-25);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AAZA3IAAgwQgGAEgHADQgIACgIAAQgTAAgKgJQgKgIAAgVIAAggIATAAIAAAhQAAAMAGAGQAGADALAAQAGAAAHgBQAHgCAGgEIAAgvIATAAIAABtg");
	this.shape_29.setTransform(58.7,-25);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAbA3IAAgxIg0AAIAAAxIgTAAIAAhtIATAAIAAAtIA0AAIAAgtIATAAIAABtg");
	this.shape_30.setTransform(47,-25);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgiAxQgJgJAAgPQAAgSAMgIQANgIAWgBIAVAAIAAgJQAAgLgGgFQgGgFgOABQgJAAgKACIgQAIIAAgRQAGgDAKgEQAKgDALAAQAVAAAKAJQALAIAAASIAAA6IAAAFIABAEIAAAGIABADIgRAAIgBgJIgBgJIgBgDIgEAIIgIAIQgEADgGACQgFACgIAAQgPAAgJgIgAgRAJQgHAFAAAKQgBAHAFAFQAFAFAJAAQAIAAAFgEQAHgDAEgGQAEgFABgEIACgGIAAgIIgTAAQgPAAgIAEg");
	this.shape_31.setTransform(35.2,-25);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgzBLIAAiTIAQAAIACAWQAGgLAJgHQAJgGANAAQAKAAAIAEQAJADAHAHQAHAHAEALQADALAAAOQABAPgFAJQgEALgGAHQgHAHgJAEQgJADgKAAQgLAAgKgGQgJgFgFgLIAAA6gAgMg3QgGADgFAFQgEAFgDAHQgDAIAAAKQAAAKADAHQADAIAEAFQAFAFAGACQAGADAHAAQAOAAAJgKQAJgKAAgUQAAgUgJgKQgJgKgOAAQgHAAgGACg");
	this.shape_32.setTransform(23.9,-23.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgIBgIAAgkQgNgBgKgDQgLgEgIgHQgIgHgFgLQgEgKAAgOQAAgMAEgLQAFgKAIgIQAIgHALgDQAKgEANAAIAAgrIARAAIAAArQANAAALAEQAKAEAIAHQAIAHAFAKQAEALAAAMQAAAOgEAKQgFALgIAHQgIAHgLAEQgKADgNABIAAAkgAAJArQAJAAAHgDQAIgCAFgFQAFgFADgHQADgIAAgKQAAgJgDgIQgDgHgFgFQgGgFgHgCQgHgDgJAAgAgYghQgHACgGAFQgFAFgDAIQgDAHAAAJQAAAKADAIQADAHAFAFQAGAFAHACQAHADAJAAIAAhPQgJAAgHADg");
	this.shape_33.setTransform(9.5,-25.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AAeA3IAAhTIg6BTIgTAAIAAhtIATAAIAABTIA5hTIATAAIAABtg");
	this.shape_34.setTransform(-9,-25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AAbA3IAAgxIg0AAIAAAxIgTAAIAAhtIATAAIAAAtIA0AAIAAgtIATAAIAABtg");
	this.shape_35.setTransform(-21.4,-25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgJA3IAAhdIgiAAIAAgQIBXAAIAAAQIgjAAIAABdg");
	this.shape_36.setTransform(-32.5,-25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgUA1QgKgDgHgIQgHgHgEgKQgEgLAAgOQAAgMAEgMQAEgKAHgIQAHgGAKgFQAJgDALAAQALAAAKADQAKAFAHAGQAHAIAEAKQAEAMAAAMQAAAOgEALQgEAKgHAHQgHAIgKADQgKAEgLAAQgLAAgJgEgAgNglQgGADgFAFQgEAEgDAIQgCAHAAAKQAAAKACAIQADAHAEAGQAFAFAGACQAGADAHAAQAHAAAGgDQAHgCAEgFQAFgGACgHQADgIAAgKQAAgKgDgHQgCgIgFgEQgEgFgHgDQgGgCgHAAQgHAAgGACg");
	this.shape_37.setTransform(-43.6,-25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgLA1QgLgEgGgHQgIgHgEgLQgDgKAAgOQAAgMADgLQAEgKAIgIQAGgHALgFQALgDALAAQALAAAIACQAJACAGAFIAAARQgIgFgIgCQgJgCgIAAQgTAAgJAKQgJAKAAATQABAUAIALQAJAJARABQALAAAIgDIAQgGIAAARQgHADgIACQgIADgMAAQgLAAgKgEg");
	this.shape_38.setTransform(-55,-25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgLA1QgKgEgIgHQgHgHgDgLQgEgKgBgOQABgMAEgLQADgKAHgIQAIgHAKgFQAKgDANAAQAKAAAJACQAIACAFAFIAAARQgGgFgJgCQgJgCgIAAQgTAAgIAKQgJAKAAATQgBAUAJALQAJAJASABQAKAAAIgDIAPgGIAAARQgFADgJACQgJADgKAAQgMAAgKgEg");
	this.shape_39.setTransform(-70.3,-25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgiAxQgJgJAAgPQgBgSANgIQANgIAWgBIAVAAIAAgJQAAgLgGgFQgGgFgNABQgKAAgKACIgQAIIAAgRQAGgDAKgEQAKgDALAAQAVAAAKAJQAMAIAAASIAAA6IAAAFIAAAEIAAAGIABADIgRAAIgBgJIgBgJIAAgDIgFAIIgIAIQgEADgGACQgFACgIAAQgPAAgJgIgAgRAJQgHAFAAAKQAAAHAEAFQAFAFAJAAQAHAAAHgEQAGgDAEgGQAEgFABgEIACgGIAAgIIgTAAQgPAAgIAEg");
	this.shape_40.setTransform(-81.2,-25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AAaA3IAAgxIgzAAIAAAxIgUAAIAAhtIAUAAIAAAtIAzAAIAAgtIAUAAIAABtg");
	this.shape_41.setTransform(-92.7,-25);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgkBMIgCAAIAAgUIADAAIABAAQAMAAAGgFQAGgFAFgIIg4hxIAWAAIArBbIAmhbIAVAAIgxBuQgDAKgGAIQgEAHgFAFQgGAGgHACQgHADgKAAg");
	this.shape_42.setTransform(-109.9,-27.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-118.7,-41.2,237.6,82.4);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhjDQQgeglAAg/QAAhLAogmQAogmBLAAIAzAAIAAg7QAAg1gUgZQgTgZgmAAQgeAAgaAOQgaANgQAZIgMgqQAPgUAbgNQAfgOAlAAQB4gBAACIIAAD/QAAA2AKAhIgoAAQgIgfgDghQgkBJhBAAQgwAAgdgkgAg6APQgcAcAAA9QAAAxAUAcQAUAbAhABQAegBAZgbQAWgYANgpIAAiAIgyAAQg5AAgcAbg");
	this.shape.setTransform(52.2,2.3,0.285,0.285);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhYC0QgnhAAAhzQAAhzAnhAQAnhABGAAQBDAAAjArIgMAvQgmg1g0AAQg0gBgaA3QgaA0AABkQAADNBoAAQAmAAAfgZQAQgNAIgNIAOAkQgJANgRANQgkAbguAAQhFAAgnhAg");
	this.shape_1.setTransform(43.5,2.3,0.285,0.285);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhYC0QgnhAAAhzQAAhzAnhAQAmhABHAAQBDAAAjArIgMAvQglg1g1AAQg0gBgbA3QgZA0AABkQAABjAZA0QAbA2A0AAQAmAAAfgZQAQgNAIgNIAOAkQgJANgSANQgjAbguAAQhGAAgmhAg");
	this.shape_2.setTransform(34.7,2.3,0.285,0.285);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhjDQQgeglAAg/QAAhLAogmQAogmBLAAIAzAAIAAg7QAAg1gUgZQgTgZgmAAQgeAAgaAOQgaANgQAZIgMgqQAPgUAbgNQAfgOAlAAQB4gBAACIIAAD/QAAA2AKAhIgoAAQgIgfgDghQgkBJhBAAQgwAAgdgkgAg6APQgcAcAAA9QAAAxAUAcQAUAbAhABQAegBAZgbQAWgYANgpIAAiAIgyAAQg5AAgcAbg");
	this.shape_3.setTransform(25.7,2.3,0.285,0.285);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("ABjFNIjLleIAAFeIguAAIAAqZIAuAAIAAE3IDCk3IAsAAIi+EzIDPFmg");
	this.shape_4.setTransform(16.8,-0.5,0.285,0.285);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AjaEcIAAhcIjIAAIAABcIhBAAIAAiYIAcAAQAdhDALhrQAIhLAAh3IAAgoIDZAAIAAGYIAmAAIAACYgAlWjRQAADmgsBvIB9AAIAAldIhRAAgAIzCKQgrg+AAh2QAAhwAqg/QArhCBRAAQAwAAAnAZIgLBEQgmgggnAAQgoAAgYAsQgZAvAABWQAABYAVAvQAWAwArAAQAvAAAggdIARA2QgpAjg4AAQhNAAgpg8gAhDCOQgqg7AAhpQAAh3AihEQAkhKBHAAQCBAAAADaIAAAoIjCAAQAABOAWAqQAVApArAAQAuAAAuggIARA4QgxAmhDAAQhIAAgpg4gAgPi5QgOAhgDBDIB2AAQAAiKg2AAQggAAgPAmgAGvDAIh7jpIAADpIhJAAIAAnUIBJAAIAADZIBwjZIBKAAIh1DcICFD4gApVDAIAAjSIhsAAIAADSIhIAAIAAnUIBIAAIAADHIBsAAIAAjHIBIAAIAAHUg");
	this.shape_5.setTransform(-16,3.5,0.285,0.285);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF051A").s().p("ABcFNIAAj/Ig7AAIhxD/IhTAAIB9kRQhigyAAiFQAAhjA6g5QA0g1BTAAIBrAAIAAKZgAgXjuQgjAnAABMQAABMAhAkQAcAdAzAAIAmAAIAAkhIgmAAQgxAAgcAhg");
	this.shape_6.setTransform(-45.5,-0.5,0.285,0.285);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50.2,-10,106.1,21.6);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#808285").s().p("AAUAqIAAghIgPAAIgWAhIgOAAIAagjQgKgDgEgEQgFgGAAgKQAAgHACgEQADgGADgCQAEgDAGgCIAMgBIAZAAIAABTgAgBgfIgGADIgEAEQgCADAAAFQAAAIAFADQAFAFAHAAIAQAAIAAgfIgOAAIgHAAg");
	this.shape.setTransform(53.1,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#808285").s().p("AAXAqIAAhEIgtBEIgLAAIAAhTIAKAAIAABFIAthFIAMAAIAABTg");
	this.shape_1.setTransform(44.7,-0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#808285").s().p("AAWAqIAAglIgrAAIAAAlIgKAAIAAhTIAKAAIAAAlIArAAIAAglIALAAIAABTg");
	this.shape_2.setTransform(35.5,-0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#808285").s().p("AgZAqIAAhTIAzAAIAAAKIgoAAIAAAZIAiAAIAAAJIgiAAIAAAdIAoAAIAAAKg");
	this.shape_3.setTransform(27.3,-0.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#808285").s().p("AgtAqIAAhTIALAAIAABJIAdAAIAAhJIAKAAIAABJIAdAAIAAhJIAMAAIAABTg");
	this.shape_4.setTransform(17.6,-0.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#808285").s().p("AgZAqIAAhTIAzAAIAAAKIgoAAIAAAZIAiAAIAAAJIgiAAIAAAdIAoAAIAAAKg");
	this.shape_5.setTransform(8,-0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#808285").s().p("AgcAqIAAhTIAbAAQANAAAJAGQAHAFABANQgBAIgCAEQgCAFgEADQgEADgGACQgGABgGAAIgOAAIAAAhgAgQAAIAOAAIAHAAIAHgEQADgCABgDQACgDAAgFQgBgIgFgDQgEgDgJAAIgPAAg");
	this.shape_6.setTransform(0.6,-0.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#808285").s().p("AgNAFIAAgJIAbAAIAAAJg");
	this.shape_7.setTransform(-5.9,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#808285").s().p("AgIAoQgIgCgFgGQgGgGgDgIQgCgIAAgKQgBgJADgIQADgIAFgGQAFgFAIgDQAIgDAIAAQAJAAAGACIALAEIAAALQgFgEgHgBQgGgCgIAAQgOAAgGAIQgIAJAAAPQABARAHAIQAIAIAOAAQAGAAAHgBQAFgCAGgEIAAAKIgKAFQgGACgJAAQgIAAgIgDg");
	this.shape_8.setTransform(-12.6,-0.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#808285").s().p("AgZAqIAAhTIAzAAIAAAKIgoAAIAAAZIAiAAIAAAJIgiAAIAAAdIAoAAIAAAKg");
	this.shape_9.setTransform(-20.4,-0.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#808285").s().p("AAVAqIAAglIgpAAIAAAlIgMAAIAAhTIAMAAIAAAlIApAAIAAglIAMAAIAABTg");
	this.shape_10.setTransform(-28.7,-0.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#808285").s().p("AgTApIgKgFIAAgKQAMAHAPAAIAHAAIAHgDIAEgFQACgCAAgFQAAgIgFgDQgFgDgKAAIgLAAIAAgJIALAAQAIAAAFgEQAEgDAAgHQABgHgGgDQgEgDgHAAQgIAAgHACQgGABgFADIAAgKQAEgDAGgBQAGgCAKAAQAMAAAIAFQAHAGAAALQAAAIgDAEQgFAFgJACQALABAEAEQAFAFABAJQAAAHgDAFQgDAEgEADQgEADgHACQgFABgGAAQgJAAgIgCg");
	this.shape_11.setTransform(-37.1,-0.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#808285").s().p("AAXAqIAAhEIgtBEIgMAAIAAhTIALAAIAABFIAthFIANAAIAABTg");
	this.shape_12.setTransform(-45.6,-0.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#808285").s().p("AgbAqIAAhTIAyAAIAAAKIgnAAIAAAYIAQAAQANgBAIAHQAHAEAAANQAAAHgCAFQgCAFgEADQgEADgGABQgGACgFAAgAgQAgIAPAAIAGgBIAGgCIAEgFQACgDAAgEQAAgIgFgEQgEgDgIgBIgQAAg");
	this.shape_13.setTransform(-54,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59.8,-8.8,119.8,17.8);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCC00").s().p("AB+DbQhZgohXhJQhbhKg9hTQhChagQhNQAShODhBcQBwAvBuA9IgCAnQAAAxAGAtQAVCUBOBFIgUABQg7AAhPgkg");
	this.shape.setTransform(-67.9,48.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFCC00").s().p("Ay0IzQg2AAgngnQgngnAAg3IAAtcQAAg3AngmQAmgmA3AAMAlpAAAQA3AAAmAmQAnAmAAA3IAANcQAAA3gnAnQgmAng3AAg");
	this.shape_1.setTransform(0,-17.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-133.6,-73.9,267.4,147.9);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Tween8("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,-18.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50.1,-36.1,100.3,36.2);


// stage content:
(lib._300x2501 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		canvas.style.cursor = "pointer"; 
		
	
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(120));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgDAWIAAgTIgSAAIAAgFIASAAIAAgTIAHAAIAAATIASAAIAAAFIgSAAIAAATg");
	this.shape.setTransform(295.6,7.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AgIAfQgDgBgDgCQgDgCgCgEQgBgDAAgEQAAgHADgEQADgEAGgBQgFgCgDgDQgCgEAAgFQAAgFABgCIAEgGIAGgDQAEgBADAAIAIABIAGADIAEAGQABACAAAFQAAAFgDAEQgCADgFACQAGABADAEQADAEAAAGQAAAFgBADQgCAEgDACQgDACgEABQgDACgFAAQgEAAgEgCgAgEACQgBAAAAAAQgBABAAAAQgBAAAAABQgBAAAAAAIgDAEIgBAFIABAGIADADIAEADIAEABIAFgBIAEgDIADgDIABgGIgBgFIgDgEQAAAAgBAAQAAgBAAAAQgBAAgBgBQAAAAgBAAIgFgBIgEABgAgHgWQgDADAAAFQAAAEADADQADADAEAAQAFAAADgDQADgDAAgEQAAgFgDgDQgDgDgFAAQgEAAgDADg");
	this.shape_1.setTransform(290.7,6.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s().p("AAFAgIAAg1IgRAOIAAgJIASgPIAHAAIAAA/g");
	this.shape_2.setTransform(285.3,6.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(120));

	// copy
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#434343").s().p("AAAASIALgSIgLgRIAIAAIAMARIgMASgAgTASIAMgSIgMgRIAJAAIALARIgLASg");
	this.shape_3.setTransform(140.5,242);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#434343").s().p("AANAXIAAgjIgYAjIgIAAIAAgtIAIAAIAAAjIAYgjIAHAAIAAAtg");
	this.shape_4.setTransform(135.6,242);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#434343").s().p("AgOAXIAAgtIAdAAIAAAHIgVAAIAAAmg");
	this.shape_5.setTransform(131.1,242);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#434343").s().p("AgRAXIAAgtIAIAAIAAAQIAJAAQAHAAAFADQAGADAAAIQAAAEgCADIgEAFIgGADIgHAAgAgJAQIAIAAQAEABADgCQAEgCAAgFQAAgEgDgCQgDgCgEAAIgJAAg");
	this.shape_6.setTransform(126.9,242);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#434343").s().p("AALAXIAAgUIgVAAIAAAUIgIAAIAAgtIAIAAIAAATIAVAAIAAgTIAIAAIAAAtg");
	this.shape_7.setTransform(122,242);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#434343").s().p("AgNASQgHgHAAgLQAAgFACgEQACgFADgDQACgDAFgCQADgBAFAAQAEAAAFABQAEACACADQADAEABAFQABAEgBAGIghAAQABAIAEADQAEAEAHAAQAGAAADgBIAHgEIAAAHIgDACIgDABIgFACIgGAAQgLAAgFgGgAANgEQAAgGgDgDQgDgDgGAAQgEAAgDADQgFADgBAGIAZAAIAAAAg");
	this.shape_8.setTransform(117,242);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#434343").s().p("AAYAoIgBgQIgtAAIgBAQIgIAAIAAgXIAFAAQADgDABgFIADgLIACgQIAAgVIApAAIAAA4IAIAAIAAAXgAgJgNIgCANIgCAKIgEAHIAgAAIAAgwIgYAAg");
	this.shape_9.setTransform(111.1,241.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#434343").s().p("AgDAEIgCgEQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAABABQAAAAAAAAQABAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAIgCAEQAAABgBAAQAAAAAAAAQgBABgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBAAAAgBg");
	this.shape_10.setTransform(106.7,243.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#434343").s().p("AgEAXQgEgCgDgDQgDgDgCgFQgCgEAAgGQAAgFACgEQACgFADgDQADgDAEgCQAEgBAFAAIAIAAIAGADIAAAHQgDgCgDAAIgIgBQgHAAgEAEQgDAEgBAIQABAJADAEQADAEAIAAIAIgBIAGgDIAAAHIgGADIgIABQgFAAgEgBg");
	this.shape_11.setTransform(103.3,242);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#434343").s().p("AAKAXIgQgTIgEAAIAAATIgIAAIAAgtIAIAAIAAAUIAFAAIAPgUIAJAAIgTAWIATAXg");
	this.shape_12.setTransform(99,242);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#434343").s().p("AgOASQgGgHAAgLQAAgFACgEQABgFADgDQAEgDADgCQAEgBAEAAQAFAAAEABQAEACADADQADAEAAAFQABAEgBAGIgfAAQAAAIAEADQAEAEAHAAQAFAAAEgBIAGgEIAAAHIgBACIgEABIgFACIgGAAQgKAAgHgGgAANgEQAAgGgDgDQgEgDgFAAQgEAAgEADQgDADgBAGIAYAAIAAAAg");
	this.shape_13.setTransform(94,242);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#434343").s().p("AASAeIgBgNIghAAIgBANIgHAAIAAgUIADAAQADgCABgDIACgHIACgMIAAgPIAfAAIAAAnIAHAAIAAAUgAgHgBQgCAHgDAEIAWAAIAAggIgQAAIgBAVg");
	this.shape_14.setTransform(88.9,242.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#434343").s().p("AALAXIAAgUIgVAAIAAAUIgIAAIAAgtIAIAAIAAATIAVAAIAAgTIAIAAIAAAtg");
	this.shape_15.setTransform(83.8,242);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#434343").s().p("AAQAgIAAgaIgMAAIgRAaIgKAAIAUgbQgIgCgDgDQgFgEAAgIQAAgFACgEQACgEADgCQAEgCAEgBIAIgBIAUAAIAAA/gAgBgXIgEACIgEADIgBAGQABAGADADQADADAHAAIAMAAIAAgYIgMAAIgFABg");
	this.shape_16.setTransform(78.1,241.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#434343").s().p("AALASIgLgSIALgRIAJAAIgMARIAMASgAgHASIgMgSIAMgRIAHAAIgKARIAKASg");
	this.shape_17.setTransform(73.3,242);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#434343").s().p("AgLAfQgGgCgEgEQgEgFgDgGQgCgGAAgIQAAgHACgHQADgGAEgEQAEgEAGgCQAFgCAGAAQAHAAAFACQAGACAEAEQAEAEADAGQACAHAAAHQAAAIgCAGQgDAGgEAFQgEAEgGACQgFACgHAAQgGAAgFgCgAgIgXQgEABgDADQgDADgBAFQgCAFAAAGQAAAHACAFQABAFADADQADADAEABIAIABIAJgBQAEgBADgDIAEgIQACgFAAgHQAAgGgCgFIgEgIQgDgDgEgBQgEgCgFAAQgEAAgEACg");
	this.shape_18.setTransform(65.5,241.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#434343").s().p("AAOAgIgWgbIgHAAIAAAbIgIAAIAAg/IAIAAIAAAdIAHAAIAWgdIAJAAIgYAfIAZAgg");
	this.shape_19.setTransform(59.4,241.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#434343").s().p("AAQAgIAAgcIgfAAIAAAcIgJAAIAAg/IAJAAIAAAcIAfAAIAAgcIAJAAIAAA/g");
	this.shape_20.setTransform(53,241.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#434343").s().p("AgLAfQgGgCgEgEQgEgFgDgGQgCgGAAgIQAAgHACgHQADgGAEgEQAEgEAGgCQAFgCAGAAQAHAAAFACQAGACAEAEQAEAEADAGQACAHAAAHQAAAIgCAGQgDAGgEAFQgEAEgGACQgFACgHAAQgGAAgFgCgAgIgXQgEABgDADQgDADgBAFQgCAFAAAGQAAAHACAFQABAFADADQADADAEABIAIABIAJgBQAEgBADgDIAEgIQACgFAAgHQAAgGgCgFIgEgIQgDgDgEgBQgEgCgFAAQgEAAgEACg");
	this.shape_21.setTransform(44.4,241.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#434343").s().p("AgLAfQgGgCgEgEQgEgFgDgGQgCgGAAgIQAAgHACgHQADgGAEgEQAEgEAGgCQAFgCAGAAQAHAAAFACQAGACAEAEQAEAEADAGQACAHAAAHQAAAIgCAGQgDAGgEAFQgEAEgGACQgFACgHAAQgGAAgFgCgAgIgXQgEABgDADQgDADgBAFQgCAFAAAGQAAAHACAFQABAFADADQADADAEABIAIABIAJgBQAEgBADgDIAEgIQACgFAAgHQAAgGgCgFIgEgIQgDgDgEgBQgEgCgFAAQgEAAgEACg");
	this.shape_22.setTransform(37.4,241.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#434343").s().p("AgLAfQgGgCgEgEQgEgFgDgGQgCgGAAgIQAAgHACgHQADgGAEgEQAEgEAGgCQAFgCAGAAQAHAAAFACQAGACAEAEQAEAEADAGQACAHAAAHQAAAIgCAGQgDAGgEAFQgEAEgGACQgFACgHAAQgGAAgFgCgAgIgXQgEABgDADQgDADgBAFQgCAFAAAGQAAAHACAFQABAFADADQADADAEABIAIABIAJgBQAEgBADgDIAEgIQACgFAAgHQAAgGgCgFIgEgIQgDgDgEgBQgEgCgFAAQgEAAgEACg");
	this.shape_23.setTransform(30.5,241.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},65).wait(55));

	// btn
	this.button_1 = new lib.btn();
	this.button_1.name = "button_1";
	this.button_1.parent = this;
	this.button_1.setTransform(75.5,187.9,1.002,1.002,0,0,0,0.2,-17.9);
	this.button_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.button_1).wait(68).to({_off:false},0).wait(10).to({regX:0.3,regY:-17.8,scaleX:1.2,scaleY:1.2,x:75.6,y:184.5},8).to({regX:0.2,regY:-17.9,scaleX:1,scaleY:1,x:75.5,y:187.9},7).wait(27));

	// text
	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AAnA3IAAhtIATAAIAABtgAg5A3IAAhtIATAAIAAAmIASAAQAUAAAMAJQAMAHAAATQAAAJgEAHQgDAHgGAFQgHAEgHACQgIACgLAAgAgmAnIAQAAQANAAAHgFQAHgEAAgKQAAgLgGgFQgHgEgMAAIgSAAg");
	this.shape_24.setTransform(190.7,133.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgLA1QgKgDgIgIQgHgHgEgLQgDgKAAgOQAAgMADgLQAEgLAHgHQAIgHAKgEQALgEALAAQALAAAIACQAJACAGAFIAAAQQgIgEgIgCQgIgDgJAAQgSAAgJAKQgKAKABAUQgBAVAKAKQAIAKASAAQAKAAAIgDIAQgGIAAARQgHADgIADQgJACgKAAQgMAAgKgEg");
	this.shape_25.setTransform(178,133.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgLA1QgLgDgGgIQgIgHgEgLQgDgKgBgOQABgMADgLQAEgLAIgHQAHgHAKgEQAKgEAMAAQALAAAIACQAJACAGAFIAAAQQgIgEgIgCQgIgDgJAAQgTAAgJAKQgJAKAAAUQAAAVAJAKQAJAKASAAQAKAAAIgDIAQgGIAAARQgHADgIADQgJACgKAAQgMAAgKgEg");
	this.shape_26.setTransform(167.4,133.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgiAxQgJgIAAgQQgBgSANgIQANgIAWAAIAVAAIAAgJQAAgMgGgFQgGgFgNAAQgKAAgKAEIgQAHIAAgQQAGgEAKgEQAKgDALAAQAVAAALAJQALAIAAASIAAA6IAAAFIAAAFIABAFIAAADIgRAAIgBgIIgBgKIAAgDIgFAIIgIAIQgEADgGACQgFACgIAAQgPAAgJgIgAgRAKQgHAEAAAKQAAAHAEAFQAFAFAJAAQAIAAAGgEQAGgDAEgFIAFgKIACgGIAAgIIgTAAQgPAAgIAFg");
	this.shape_27.setTransform(156.4,133.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AAgBMIg0hBIgQAAIAABBIgUAAIAAiXIAUAAIAABFIAOAAIA2hFIAXAAIg7BLIA9BMg");
	this.shape_28.setTransform(144.9,131.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgqA3IAAhtIApAAQATAAAKAGQALAHAAAQQAAAJgFAGQgFAFgJADQAXADAAAWQAAAJgDAGQgEAGgGAEQgGADgIACQgIACgJAAgAgXAnIAWAAIAJAAIAJgEQADgCACgCQACgEAAgFQAAgJgHgDQgGgFgMAAIgWAAgAgXgJIAVAAQAJAAAHgDQAGgEAAgHQAAgJgGgDQgFgDgKgBIgWAAg");
	this.shape_29.setTransform(127.2,133.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgUA2QgKgEgHgIQgHgHgEgLQgEgKAAgOQAAgNAEgKQAEgLAHgHQAHgIAKgDQAKgEAKAAQALAAAKAEQAKADAHAIQAHAHAEALQAEAKAAANQAAAOgEAKQgEALgHAHQgHAIgKAEQgKADgLAAQgKAAgKgDgAgNglQgGACgFAFQgEAFgDAIQgCAIAAAJQAAALACAHQADAIAEAFQAFAFAGACQAGADAHAAQAHAAAHgDQAGgCAEgFQAFgFADgIQACgHAAgLQAAgJgCgIQgDgIgFgFQgEgFgGgCQgHgDgHAAQgHAAgGADg");
	this.shape_30.setTransform(115.3,133.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgzBLIAAiSIAQAAIACAUQAFgKAKgHQAKgGAMAAQAKAAAIADQAJAEAHAHQAHAIADAKQAEALABAOQgBAPgEAKQgEAKgGAIQgHAGgJAEQgJAEgKgBQgLAAgKgFQgJgGgFgKIAAA5gAgMg2QgHACgEAFQgFAFgCAHQgCAIAAAKQAAAKACAHQACAIAFAFQAEAFAHACQAGADAHAAQAOAAAJgKQAJgKAAgUQAAgTgJgLQgJgLgOAAQgHABgGADg");
	this.shape_31.setTransform(103.3,135.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgiAqQgOgPAAgbQAAgMAEgLQADgLAIgHQAHgHAJgEQAKgEAKAAQAMAAAJAEQAJAEAHAIQAGAIACALQACAMgCAOIhNAAQABASAKAJQAJAJASAAQANAAAJgEQAJgDAGgFIAAARIgFAEIgJADIgLADIgOABQgaAAgPgPgAgRggQgJAHgCAPIA6AAQABgPgIgHQgIgIgNAAQgLAAgIAIg");
	this.shape_32.setTransform(90.8,133.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AAbA3IAAgxIg1AAIAAAxIgTAAIAAhtIATAAIAAAtIA1AAIAAgtIASAAIAABtg");
	this.shape_33.setTransform(79,133.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgJA3IAAheIgiAAIAAgPIBXAAIAAAPIgjAAIAABeg");
	this.shape_34.setTransform(67.9,133.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("Ag0BLIAAiSIARAAIACAUQAFgKAKgHQAJgGANAAQAKAAAJADQAIAEAHAHQAGAIAFAKQADALAAAOQAAAPgDAKQgFAKgHAIQgGAGgJAEQgJAEgKgBQgMAAgJgFQgJgGgGgKIAAA5gAgMg2QgHACgEAFQgFAFgCAHQgDAIAAAKQAAAKADAHQACAIAFAFQAEAFAHACQAHADAFAAQAPAAAJgKQAJgKAAgUQAAgTgJgLQgJgLgPAAQgFABgHADg");
	this.shape_35.setTransform(56.9,135.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgiAxQgKgIAAgQQAAgSAOgIQAMgIAXAAIAUAAIAAgJQAAgMgGgFQgGgFgOAAQgJAAgKAEQgJADgHAEIAAgQQAGgEAKgEQAKgDALAAQAVAAALAJQAKAIAAASIAAA6IABAFIAAAFIAAAFIAAADIgRAAIgBgIIAAgKIAAgDIgFAIIgHAIQgFADgGACQgFACgIAAQgPAAgJgIgAgRAKQgIAEAAAKQAAAHAFAFQAFAFAJAAQAIAAAGgEQAGgDAEgFIAGgKIABgGIAAgIIgSAAQgRAAgHAFg");
	this.shape_36.setTransform(44.4,133.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AAaA3IAAheIgyAAIAABeIgTAAIAAhtIBXAAIAABtg");
	this.shape_37.setTransform(33,133.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgiAxQgKgIAAgQQABgSANgIQAMgIAXAAIAUAAIAAgJQAAgMgGgFQgGgFgNAAQgLAAgIAEIgRAHIAAgQQAGgEAKgEQAKgDALAAQAVAAALAJQALAIAAASIAAA6IAAAFIAAAFIAAAFIAAADIgRAAIgBgIIAAgKIAAgDIgFAIIgHAIQgFADgGACQgFACgIAAQgPAAgJgIgAgRAKQgIAEAAAKQABAHAEAFQAFAFAJAAQAHAAAHgEQAGgDAEgFIAGgKIABgGIAAgIIgSAAQgQAAgIAFg");
	this.shape_38.setTransform(180.1,104);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AAdA3IgdgsIgeAsIgTAAIAog4Igjg1IAVAAIAaAnIAagnIATAAIgkA0IAmA5g");
	this.shape_39.setTransform(169.3,104.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgiAqQgOgPAAgbQAAgMAEgLQADgLAIgHQAHgHAJgEQAKgEAKAAQAMAAAJAEQAJAEAHAIQAGAIACALQACAMgCAOIhNAAQABASAKAJQAJAJASAAQANAAAJgEQAJgDAGgFIAAARIgFAEIgJADIgLADIgOABQgaAAgPgPgAgRggQgJAHgCAPIA6AAQABgPgIgHQgIgIgNAAQgLAAgIAIg");
	this.shape_40.setTransform(158.2,104);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AAaA3IAAheIgyAAIAABeIgTAAIAAhtIBXAAIAABtg");
	this.shape_41.setTransform(146.6,104.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgLA1QgKgDgHgIQgIgHgDgLQgFgKAAgOQAAgMAFgLQADgLAIgHQAHgHAKgEQALgEAMAAQAKAAAJACQAIACAFAFIAAAQQgGgEgJgCQgIgDgJAAQgSAAgKAKQgIAKgBAUQABAVAIAKQAJAKASAAQAKAAAIgDIAPgGIAAARQgFADgJADQgJACgKAAQgMAAgKgEg");
	this.shape_42.setTransform(135.3,104);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgmBKIgHgBIAAgSIAGACIAIABQAIAAAFgDQAFgEAFgIIgth1IAUAAIAjBcIAihcIASAAIgpBsIgIASQgEAHgEAFQgGAGgGACQgHADgIAAg");
	this.shape_43.setTransform(124.3,106);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AAeA3IAAhUIg6BUIgTAAIAAhtIATAAIAABUIA6hUIASAAIAABtg");
	this.shape_44.setTransform(107.7,104.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AAeA3IAAhUIg6BUIgTAAIAAhtIATAAIAABUIA6hUIASAAIAABtg");
	this.shape_45.setTransform(95,104.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgzBLIAAiTIAQAAIACAVQAGgKAJgHQAJgGANAAQAJAAAKADQAIAEAHAHQAGAIAFAKQADALAAAOQAAAPgDAKQgFAKgGAIQgHAGgJAEQgJADgKAAQgMAAgJgFQgJgGgFgLIAAA6gAgMg2QgGACgFAFQgEAFgDAHQgCAIAAAKQAAALACAGQADAIAEAFQAFAFAGACQAHADAFAAQAPAAAJgKQAJgKAAgUQAAgTgJgLQgJgLgPABQgFAAgHADg");
	this.shape_46.setTransform(82.7,105.8);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AgUA2QgKgEgHgIQgHgHgEgLQgEgKAAgOQAAgNAEgKQAEgLAHgHQAHgIAKgDQAKgEAKAAQALAAAKAEQAKADAHAIQAHAHAEALQAEAKAAANQAAAOgEAKQgEALgHAHQgHAIgKAEQgKADgLAAQgKAAgKgDgAgNglQgGACgFAFQgEAFgDAIQgCAIAAAJQAAALACAHQADAIAEAFQAFAFAGACQAGADAHAAQAHAAAHgDQAGgCAEgFQAFgFADgIQACgHAAgLQAAgJgCgIQgDgIgFgFQgEgFgGgCQgHgDgHAAQgHAAgGADg");
	this.shape_47.setTransform(69.9,104);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgJA3IAAheIgiAAIAAgPIBXAAIAAAPIgjAAIAABeg");
	this.shape_48.setTransform(58.8,104.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgLA1QgKgDgHgIQgIgHgDgLQgFgKAAgOQAAgMAFgLQADgLAIgHQAHgHAKgEQAKgEAMAAQALAAAJACQAIACAFAFIAAAQQgGgEgJgCQgIgDgJAAQgSAAgKAKQgIAKgBAUQABAVAIAKQAJAKASAAQAKAAAIgDIAPgGIAAARQgFADgJADQgJACgKAAQgMAAgKgEg");
	this.shape_49.setTransform(48.3,104);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AAqBMIAAh8IhSB8IgVAAIAAiXIAUAAIAAB9IBSh9IAVAAIAACXg");
	this.shape_50.setTransform(35.1,101.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24}]},65).to({state:[{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24}]},54).wait(1));

	// slogan
	this.instance = new lib.Tween2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(216.9,38,1.002,1.002,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({startPosition:0},23).to({startPosition:0},47).wait(50));

	// logo
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(78.6,35.4,1.002,1.002,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({startPosition:0},23).to({startPosition:0},39).to({startPosition:0},8).wait(50));

	// babl-text
	this.instance_2 = new lib.Tween4("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(130.5,112.1,0.876,0.876,0,0,0,0.4,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({startPosition:0},23,cjs.Ease.quadOut).to({startPosition:0},41,cjs.Ease.quadOut).to({_off:true},1).wait(55));

	// men
	this.instance_3 = new lib.Tween16("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(259.7,149.1,1.2,1.2,0,0,0,0.1,0.1);

	this.instance_4 = new lib.Tween17("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(259.7,154.3,1.2,1.2,0,0,0,0.1,0.1);
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween18("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(259.7,159.1,1.2,1.2,0,0,0,0.1,0.1);
	this.instance_5._off = true;

	this.instance_6 = new lib.Tween19("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(259.7,151.1,1.2,1.2,0,0,0,0.1,0.1);
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween20("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(259.7,159.1,1.2,1.2,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).to({state:[{t:this.instance_4}]},15).to({state:[{t:this.instance_5}]},8).to({state:[{t:this.instance_6}]},14).to({state:[{t:this.instance_7}]},27).to({state:[]},1).to({state:[]},7).wait(48));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true,y:154.3},15,cjs.Ease.quadOut).wait(105));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({_off:false},15,cjs.Ease.quadOut).to({_off:true,y:159.1},8,cjs.Ease.quadOut).wait(97));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(15).to({_off:false},8,cjs.Ease.quadOut).to({_off:true,y:151.1},14,cjs.Ease.quadOut).wait(83));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(23).to({_off:false},14,cjs.Ease.quadOut).to({_off:true,y:159.1},27,cjs.Ease.quadOut).wait(56));

	// babl
	this.instance_8 = new lib.Tween1("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(129.8,128.7,0.842,0.841,0,0,0,0.5,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({startPosition:0},64).to({_off:true},1).wait(55));

	// fon
	this.instance_9 = new lib.Tween10("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(236.1,238.4,1.5,1.5,0,0,0,0.1,0.1);

	this.instance_10 = new lib.Tween11("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(236.1,244.4,1.5,1.5,0,0,0,0.1,0.1);
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween12("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(236,238.3,1.5,1.5);
	this.instance_11._off = true;

	this.instance_12 = new lib.Tween13("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(236.1,232.4,1.5,1.5,0,0,0,0.1,0.1);
	this.instance_12._off = true;

	this.instance_13 = new lib.Tween14("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(236.1,238.4,1.5,1.5,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9}]}).to({state:[{t:this.instance_10}]},5).to({state:[{t:this.instance_11}]},18).to({state:[{t:this.instance_12}]},11).to({state:[{t:this.instance_13}]},25).to({state:[]},6).to({state:[]},3).wait(52));
	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({_off:true,y:244.4},5,cjs.Ease.quadOut).wait(115));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({_off:false},5,cjs.Ease.quadOut).to({_off:true,regX:0,regY:0,x:236,y:238.3},18,cjs.Ease.quadOut).wait(97));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(5).to({_off:false},18,cjs.Ease.quadOut).to({_off:true,regX:0.1,regY:0.1,x:236.1,y:232.4},11,cjs.Ease.quadOut).wait(86));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(23).to({_off:false},11,cjs.Ease.quadOut).to({_off:true,y:238.4},25,cjs.Ease.quadOut).wait(61));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(165.9,124,342.7,362.7);
// library properties:
lib.properties = {
	id: '562C67D21D3C4B768423DA1E80F29E0D',
	width: 298,
	height: 248,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/300x250_1_atlas_.png", id:"300x250_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['562C67D21D3C4B768423DA1E80F29E0D'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;