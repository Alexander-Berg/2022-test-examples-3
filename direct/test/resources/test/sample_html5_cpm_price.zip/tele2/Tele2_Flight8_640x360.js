(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Tele2_Flight8_640x360_atlas_NP_", frames: [[1002,0,1000,1144],[0,0,1000,1144],[0,1146,832,1032],[834,1146,832,1032]]}
];


// symbols:



(lib.Visual_1 = function() {
	this.initialize(ss["Tele2_Flight8_640x360_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Visual_111 = function() {
	this.initialize(ss["Tele2_Flight8_640x360_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.visual_22 = function() {
	this.initialize(ss["Tele2_Flight8_640x360_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.visual_228 = function() {
	this.initialize(ss["Tele2_Flight8_640x360_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Символ34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CD1277").s().p("A/wWsMAAAgtXMA/gAAAMAAAAtXg");
	this.shape.setTransform(68.249,-73.3066,1.8123,1.7948);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-300.1,-333.9,736.7,521.2);


(lib.Символ29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A+9RMMAAAgiXMA97AAAMAAAAiXg");
	this.shape.setTransform(61.7492,-103.0215,1.7674,1.8196);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-288.5,-303.2,700.6,400.5);


(lib.Символ28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A9zRxMAAAgjhMA7nAAAMAAAAjhg");
	this.shape.setTransform(46.075,-98.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-144.7,-212.5,381.6,227.3);


(lib.Символ30копия4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EARZAiJMAAAgzmMguQAAAMAAAAzWI7WAAMAAAgzWIgFAAIAAwrMBwlAAAIAAQrIglAAMAAAAzmg");
	this.shape.setTransform(4.2,-79.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Слой_4
	this.instance = new lib.Visual_1();
	this.instance.parent = this;
	this.instance.setTransform(-182.9,-206.4,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-356.1,-297.6,720.6,436.90000000000003);


(lib.Символ30копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CD1277").s().p("EgykAfVMAAAg0XIi9AAIAAqSMBZuAAAIAABAIRVAAMAAAA9hI+cAAMAAAg0PMguDAAAMAAAA0Xg");
	this.shape.setTransform(-33.65,-57.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Слой_4
	this.instance = new lib.Visual_111();
	this.instance.parent = this;
	this.instance.setTransform(-182.9,-206.4,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-376.3,-258.2,685.3,400.9);


(lib.Символ27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhGBRQgOgOAAgWQAAghAagOQAagPA1AAIAAgJQAAgngqABQgcAAgXAQIAAghQAVgOAkAAQBHAAABBGIAABYIAcAAIAAAdIg+AAIAAgdIgCAAQgKARgKAHQgMAJgUAAQgZAAgOgPgAggAPQgPAIAAATQAAALAGAGQAIAIANgBQASAAALgNQAMgNAAgZIAAgIQglAAgQAIg");
	this.shape.setTransform(33.1735,-0.2896,0.244,0.244);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhbBcIAAghIAJABQASAAAJghQAIgcACg/IgcAAIAAgcIClAAIAAAcIgcAAIAAB+IAcAAIAAAdIhAAAIAAiZIgrAAQgBBLgKAiQgPAvglAAg");
	this.shape_1.setTransform(28.3243,-0.2652,0.244,0.244);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOBcIAAgcIAbAAIAAhoIgCAAIhOCEIg/AAIAAgcIAcAAIAAh+IgcgBIAAgcIBaAAIAAAcIgbAAIAABqIABAAIBOiGIA/AAIAAAcIgcAAIAAB/IAcAAIAAAcg");
	this.shape_2.setTransform(23.0846,-0.2957,0.244,0.244);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhRBcIAAgcIAdAAIAAh/IgdAAIAAgcIBUAAQBIAAAAAuQAAAigjAHIAAACQAVACALAMQAKALAAAQQAAAYgQAOQgRAPglAAgAgRBCIAaAAQARAAAKgHQAJgHAAgNQAAgcgkAAIgaAAgAgRgNIATAAQAkAAAAgcQAAgXgkAAIgTAAg");
	this.shape_3.setTransform(17.9975,-0.2957,0.244,0.244);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhGBRQgOgOAAgWQAAghAagOQAagPA1AAIAAgJQABgngrABQgcAAgXAQIAAghQAWgOAjAAQBIAAAABGIAABYIAcAAIAAAdIg+AAIAAgdIgCAAQgJARgKAHQgNAJgUAAQgZAAgOgPgAgfAPQgPAIgBATQAAALAGAGQAIAIANgBQATAAAKgNQAMgNAAgZIAAgIQgkAAgQAIg");
	this.shape_4.setTransform(13.5203,-0.2896,0.244,0.244);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhgCMIAAgdIAcAAIAAjaIgcAAIAAgcIA+AAIAAAaIACAAQASgeAmAAQAhAAATAZQAVAaAAArQAAAtgVAbQgTAZghAAQgkAAgUgeIgCAAIABBZIAdAAIAAAdgAgUhgQgNANAAAZIAAAZQAAAbAPAOQAMANAUAAQAUAAAMgPQANgRAAghQABgggOgRQgMgPgUAAQgVAAgNAMg");
	this.shape_5.setTransform(8.5795,0.7839,0.244,0.244);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAgBcIAAiaIg/AAIAAB+IAaAAIAAAcIhaAAIAAgcIAcAAIAAh/IgcAAIAAgcIC+AAIAAAcIgcAAIAAB/IAcAAIAAAcg");
	this.shape_6.setTransform(3.285,-0.2957,0.244,0.244);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag1BIQgXgYgBgwQAAgrAYgbQAWgZAjAAQAhAAATATQAWAUAAAlQAAARgDAFIhxAAQABA+A2AAQAgAAAXgRIAAAgQgVAQgoAAQgpAAgXgYgAgmgVIBQAAQgBgugnABQgigBgGAug");
	this.shape_7.setTransform(-4.2177,-0.2896,0.244,0.244);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAOBcIAAgcIAbAAIAAhoIgCAAIhOCEIg/AAIAAgcIAdAAIAAh/IgdAAIAAgcIBaAAIAAAcIgbAAIAABpIACAAIBOiFIA+AAIAAAcIgcAAIgBB/IAdAAIAAAcg");
	this.shape_8.setTransform(-9.134,-0.2957,0.244,0.244);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhHBcIAAgdIAcAAIAAh+IgcAAIAAgcICQAAIAABCIgeAAIAAglIgzAAIAAB9IAhAAIAAAdg");
	this.shape_9.setTransform(-13.9528,-0.2896,0.244,0.244);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag/CKIAAgdIAbAAIAWg9Ig7idIgVAAIAAgcIAwAAIAvCJIAEAAIAlhtIgVAAIAAgcIBKAAIAAAcIgVAAIhNDbIAXAAIAAAcg");
	this.shape_10.setTransform(-18.4422,0.8266,0.244,0.244);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhgCMIAAgdIAcAAIAAjaIgcAAIAAgcIA9AAIAAAaIADAAQASgeAmAAQAhAAATAZQAVAaAAAsQAAAsgVAbQgTAZghAAQgkAAgUgeIgDAAIACBZIAeAAIAAAdgAgThgQgOANAAAZIAAAZQAAAbAOAOQAOANATAAQAUAAAMgPQAOgRAAghQAAgggOgRQgMgPgUAAQgVAAgMAMg");
	this.shape_11.setTransform(-23.3158,0.7839,0.244,0.244);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ABDB1IgEgxIh9AAIgEAxIgeAAIAAhOIASAAQANgRAGgbQAHgfACgzIgcAAIAAgcICsAAIAAAcIgcAAIAAB+IAfAAIAABOgAgsAnIBLAAIAAh9IgzAAQgBBcgXAhg");
	this.shape_12.setTransform(-28.647,0.296,0.244,0.244);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-2.6,66.3,6.800000000000001);


(lib.Символ26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAAAYIAVgXIgVgWIAAgWIAkAnIAAAJIgkAngAgiAXIAVgXIgWgWIAAgUIAkAmIAAAJIgjAmg");
	this.shape.setTransform(75.6,26.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAjAwIAAhJIgCAAIgbBJIgNAAIgchJIgCAAIAABJIgPAAIAAhfIAaAAIAaBIIABAAIAbhIIAaAAIAABfg");
	this.shape_1.setTransform(64.55,26.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgXBIIARgvIgmhgIATAAIAaBGIACAAIAZhGIARAAIgzCPg");
	this.shape_2.setTransform(53.325,28.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAUAwIAAhBIgBAAIgpBBIgQAAIAAhfIATAAIAABBIABAAIAohBIARAAIAABfg");
	this.shape_3.setTransform(43.6,26.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAjAwIAAhJIgBAAIgcBJIgOAAIgbhJIgCAAIAABJIgQAAIAAhfIAaAAIAbBIIAAAAIAchIIAZAAIAABfg");
	this.shape_4.setTransform(31.65,26.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcAmQgNgNAAgZQAAgWANgOQALgNATAAQASAAAKAJQAMALAAATQAAAJgCACIg9AAQAAAQAIAIQAIAJANAAQATAAALgKIAAARQgKAJgWAAQgWAAgMgMgAAXgLQgBgYgVABQgTgBgDAYIAsAAIAAAAg");
	this.shape_5.setTransform(20.125,26.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgsBJIAAiPIASAAIAAAOIABAAQAJgQAUAAQASAAALANQAMAOAAAWQAAAXgMAOQgLANgSAAQgTAAgKgQIgBAAIABAQIAAAugAgSgyQgHAIAAAMIAAANQAAAOAHAGQAHAIALAAQAKAAAHgIQAIgIAAgSQAAgQgIgJQgHgIgKAAQgMAAgGAGg");
	this.shape_6.setTransform(10.075,28.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAcBIIAAh+Ig4AAIAAB+IgTAAIAAiPIBfAAIAACPg");
	this.shape_7.setTransform(-2,24.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgjAFIAAgJIAkgnIAAAVIgVAWIAVAWIAAAWgAAAAFIAAgJIAkgmIAAAUIgVAWIAVAXIAAAUg");
	this.shape_8.setTransform(-12.725,26.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgcAmQgNgNAAgZQAAgWANgOQALgNATAAQASAAAKAJQAMALAAATQAAAJgCACIg9AAQAAAQAIAIQAIAJANAAQATAAALgKIAAARQgKAJgWAAQgWAAgMgMgAAXgLQgBgYgVABQgTgBgDAYIAsAAIAAAAg");
	this.shape_9.setTransform(-26.075,26.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgIBgIAAgvQgYAAgNgOQgNgNAAgWQAAgVANgOQANgOAYAAIAAguIARAAIAAAuQAYAAANAOQANANAAAWQAAAWgNANQgNAOgYAAIAAAvgAAJAjQAPAAAIgKQAIgJAAgQQAAgQgIgJQgIgJgPAAgAgfgZQgIAKAAAPQAAAQAIAJQAIAKAPAAIAAhFQgPAAgIAJg");
	this.shape_10.setTransform(-37.475,26.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAVAwIAAhBIgCAAIgpBBIgQAAIAAhfIASAAIAABBIABAAIAqhBIAQAAIAABfg");
	this.shape_11.setTransform(-49.15,26.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgsBJIAAiPIASAAIAAAOIABAAQAJgQAUAAQASAAALANQAMAOAAAWQAAAXgMAOQgLANgSAAQgTAAgKgQIgBAAIABAQIAAAugAgSgyQgHAIAAAMIAAANQAAAOAHAGQAHAIALAAQAKAAAHgIQAIgIAAgSQAAgQgIgJQgHgIgKAAQgMAAgGAGg");
	this.shape_12.setTransform(-59.575,28.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgfAqQgHgHAAgMQAAgRANgHQAOgHAfAAIAAgFQAAgVgWABQgRgBgNAJIAAgRQAMgHAUAAQAnAAAAAkIAAA9IgRAAIAAgPIgCAAQgKARgTAAQgOAAgIgIgAgKAGQgJAFAAAKQAAAOARAAQAJAAAGgHQAIgHgBgNIAAgFQgUAAgKADg");
	this.shape_13.setTransform(-70.5,26.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgJAwIAAhPIgcAAIAAgQIBLAAIAAAQIgdAAIAABPg");
	this.shape_14.setTransform(-79.2,26.55);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAVAwIAAhBIgCAAIgpBBIgQAAIAAhfIASAAIAABBIABAAIAqhBIAQAAIAABfg");
	this.shape_15.setTransform(-92.8,26.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAAAYIAVgXIgVgWIAAgWIAkAnIAAAJIgkAngAgjAXIAVgXIgVgWIAAgUIAjAmIAAAJIgjAmg");
	this.shape_16.setTransform(75.55,5.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgqBIIAAgPIAqgzQARgXAAgRQAAgVgVAAQgSAAgOALIAAgSQAMgKAYAAQAlAAAAAlQAAANgHANQgEAJgNAPIgfAoIA9AAIAAARg");
	this.shape_17.setTransform(66.45,3.65);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgcAlQgNgMAAgZQAAgWANgOQALgNATAAQASAAAKAKQAMAKAAATQAAAJgCACIg9AAQAAAQAIAIQAIAJANAAQATAAALgJIAAARQgKAIgWAAQgWAAgMgNgAAXgLQgBgYgVAAQgTAAgDAYIAsAAIAAAAg");
	this.shape_18.setTransform(56.725,6.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgSAxIAAh5IASAAIAAB2QAAAKAJAAQAFAAAFgCIAAAQQgFADgJAAQgXAAAAgYg");
	this.shape_19.setTransform(49.825,3.825);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgcAlQgNgMAAgZQAAgWANgOQALgNATAAQASAAAKAKQAMAKAAATQAAAJgCACIg9AAQAAAQAIAIQAIAJANAAQATAAALgJIAAARQgKAIgWAAQgWAAgMgNgAAXgLQgBgYgVAAQgTAAgDAYIAsAAIAAAAg");
	this.shape_20.setTransform(41.875,6.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgJBIIAAh+IgnAAIAAgRIBhAAIAAARIgnAAIAAB+g");
	this.shape_21.setTransform(31.725,3.725);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAVBFIAAhCIgCAAIgpBCIgQAAIAAhfIASAAIAABBIABAAIAphBIARAAIAABfgAgVguQgIgHAAgPIAQAAQAAAPANAAQAOAAAAgPIAQAAQABAPgKAHQgIAHgNAAQgMAAgJgHg");
	this.shape_22.setTransform(16.75,4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgfAlQgNgNAAgYQAAgWANgOQAMgNATAAQATAAANANQANAOAAAWQAAAYgNANQgNANgTAAQgTAAgMgNgAgRgZQgIAJAAAQQAAARAIAJQAGAIALAAQALAAAHgIQAHgJABgRQgBgPgHgKQgHgIgLAAQgLAAgGAIg");
	this.shape_23.setTransform(6.35,6.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAsBIIAAhyIgCAAIglByIgMAAIglhyIgBAAIAAByIgRAAIAAiPIAaAAIAkByIABAAIAlhyIAZAAIAACPg");
	this.shape_24.setTransform(-6.55,3.725);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgjAFIAAgJIAkgnIAAAVIgVAWIAVAWIAAAWgAAAAFIAAgJIAkgmIAAAUIgVAWIAVAXIAAAUg");
	this.shape_25.setTransform(-18.775,5.775);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAUAwIAAhBIgBAAIgpBBIgQAAIAAhfIATAAIAABBIABAAIAohBIARAAIAABfg");
	this.shape_26.setTransform(-32.45,6.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAQAwIgcgqIgHACIAAAoIgTAAIAAhfIATAAIAAAqIAHgDIAdgnIATAAIgiAsIAlAzg");
	this.shape_27.setTransform(-41.7,6.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAVBFIAAhCIgCAAIgpBCIgQAAIAAhfIASAAIAABBIABAAIAphBIARAAIAABfgAgVguQgIgHAAgPIAQAAQAAAPANAAQAOAAAAgPIAQAAQABAPgKAHQgIAHgNAAQgMAAgJgHg");
	this.shape_28.setTransform(-52.1,4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgcAlQgNgMAAgZQAAgWANgOQALgNATAAQASAAAKAKQAMAKAAATQAAAJgCACIg9AAQAAAQAIAIQAIAJANAAQATAAALgJIAAARQgKAIgWAAQgWAAgMgNgAAXgLQgBgYgVAAQgTAAgDAYIAsAAIAAAAg");
	this.shape_29.setTransform(-62.225,6.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AAUAwIAAgqIgoAAIAAAqIgSAAIAAhfIASAAIAAAmIAoAAIAAgmIATAAIAABfg");
	this.shape_30.setTransform(-72.25,6.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAVAwIAAhBIgCAAIgpBBIgQAAIAAhfIASAAIAABBIABAAIAphBIARAAIAABfg");
	this.shape_31.setTransform(-82.7,6.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgqAwIAAgRIAFAAQALAAAEgXQACgQABgoIA+AAIAABfIgTAAIAAhPIgcAAQAAAlgFATQgHAZgTAAIgHgBg");
	this.shape_32.setTransform(-93.45,6.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAWAwIgXgkIgXAkIgSAAIAggwIghgvIAWAAIAWAiIAWgiIASAAIgfAuIAiAxg");
	this.shape_33.setTransform(82.475,-14.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgfAqQgHgHAAgMQAAgRANgHQAOgHAfAAIAAgFQAAgUgWAAQgRAAgNAIIAAgRQAMgHAUAAQAnAAAAAkIAAA9IgSAAIAAgPIgBAAQgKARgTAAQgOAAgIgIgAgJAGQgKAFABAKQAAAOAQAAQAJAAAGgHQAIgHgBgNIAAgFQgUAAgJADg");
	this.shape_34.setTransform(72.5,-14.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgIBgIAAgvQgYAAgNgOQgNgNAAgWQAAgVANgOQANgOAYAAIAAguIARAAIAAAuQAYAAANAOQANANAAAWQAAAWgNANQgNAOgYAAIAAAvgAAJAjQAPAAAIgKQAIgJAAgQQAAgQgIgJQgIgJgPAAgAgfgZQgIAKAAAPQAAAQAIAJQAIAKAPAAIAAhFQgPAAgIAJg");
	this.shape_35.setTransform(61.175,-14.275);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAUAwIAAhBIgBAAIgpBBIgQAAIAAhfIATAAIAABBIABAAIAohBIARAAIAABfg");
	this.shape_36.setTransform(49.45,-14.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgsBJIAAiPIASAAIAAAOIABAAQAJgQAUAAQASAAALAOQAMANAAAXQAAAWgMAOQgLANgSAAQgTAAgKgQIgBAAIABAQIAAAugAgSgxQgHAGAAANIAAANQAAAOAHAHQAHAHALAAQAKAAAHgIQAIgIAAgRQAAgRgIgJQgHgIgKAAQgMAAgGAHg");
	this.shape_37.setTransform(39.075,-12);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgfAqQgHgHAAgMQAAgRANgHQAOgHAgAAIAAgFQAAgUgXAAQgRAAgNAIIAAgRQAMgHAUAAQAnAAAAAkIAAA9IgRAAIAAgPIgCAAQgKARgTAAQgOAAgIgIgAgKAGQgJAFAAAKQAAAOARAAQAJAAAGgHQAIgHAAgNIAAgFQgVAAgKADg");
	this.shape_38.setTransform(28.15,-14.3);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgIAwIAAhPIgdAAIAAgQIBLAAIAAAQIgdAAIAABPg");
	this.shape_39.setTransform(19.45,-14.3);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AAWAwIgXgkIgXAkIgSAAIAggwIghgvIAWAAIAWAiIAWgiIASAAIgfAuIAiAxg");
	this.shape_40.setTransform(6.325,-14.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AAhAwIAAhfIATAAIAABfgAgzAwIAAhfIATAAIAAAgIANAAQAVAAAKAKQAJAHAAANQAAAPgJAIQgKAKgVAAgAggAhIAPAAQATAAAAgSQAAgPgTAAIgPAAg");
	this.shape_41.setTransform(-5,-14.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgIAwIAAhPIgcAAIAAgQIBJAAIAAAQIgcAAIAABPg");
	this.shape_42.setTransform(-15.45,-14.3);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAhAwIAAhfIASAAIAABfgAgyAwIAAhfIASAAIAAAgIAMAAQAWAAALAKQAIAHABANQgBAPgIAIQgLAKgWAAgAggAhIAOAAQAVAAAAgSQAAgPgVAAIgOAAg");
	this.shape_43.setTransform(-25.85,-14.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgsBJIAAiPIASAAIAAAOIABAAQAJgQAUAAQASAAALAOQAMANAAAXQAAAWgMAOQgLANgSAAQgTAAgKgQIgBAAIABAQIAAAugAgSgxQgHAGAAANIAAANQAAAOAHAHQAHAHALAAQAKAAAHgIQAIgIAAgRQAAgRgIgJQgHgIgKAAQgMAAgGAHg");
	this.shape_44.setTransform(-37.525,-12);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AAQAwIgcgqIgIADIAAAnIgSAAIAAhfIASAAIAAAqIAIgCIAdgoIATAAIghArIAkA0g");
	this.shape_45.setTransform(-47.35,-14.3);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgIAwIAAhPIgcAAIAAgQIBKAAIAAAQIgdAAIAABPg");
	this.shape_46.setTransform(-56.5,-14.3);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgfAlQgNgNAAgYQAAgWANgNQAMgOATAAQAUAAAMANQANAOAAAWQAAAYgNANQgMANgUAAQgTAAgMgNgAgRgZQgHAJAAAQQAAARAHAJQAHAIAKAAQALAAAHgIQAIgJgBgRQABgPgIgKQgHgIgLAAQgKAAgHAIg");
	this.shape_47.setTransform(-65.6,-14.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgfAqQgHgHAAgMQAAgRAOgHQAOgHAeAAIAAgFQABgUgXAAQgRAAgNAIIAAgRQAMgHAUAAQAnAAAAAkIAAA9IgSAAIAAgPIgBAAQgKARgTAAQgOAAgIgIgAgJAGQgJAFAAAKQAAAOAQAAQAJAAAGgHQAHgHAAgNIAAgFQgVAAgIADg");
	this.shape_48.setTransform(-80.35,-14.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AAeBIIAAhBIg7AAIAABBIgUAAIAAiPIAUAAIAAA+IA7AAIAAg+IATAAIAACPg");
	this.shape_49.setTransform(-91.6,-16.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101.2,-34,197.8,74.1);


(lib.Символ25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhBBVIAAgbIAUAAIAAhzIgUAAIAAgbIB5AAIAAAzIgcAAIAAgVIgoAAIAAAkIAQAAQAeAAARAPQAPAMAAAWQAAAWgPAPQgRARgfAAgAgMA3IAOAAQAdAAAAgWQAAgWgdAAIgOAAg");
	this.shape.setTransform(56.475,27.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag7BVIAAgbIAUAAIAAhzIgUAAIAAgbIB3AAIAAAzIgcAAIAAgVIgmAAIAABwIAWAAIAAAbg");
	this.shape_1.setTransform(42.575,27.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAFA6IAAgaIAPAAIAAgpIgCAAIgmBDIguAAIAAgaIARAAIAAg/IgRAAIAAgaIA+AAIAAAaIgPAAIAAApIABAAIAnhDIAuAAIAAAaIgRAAIAAA/IARAAIAAAag");
	this.shape_2.setTransform(22.05,29.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgiA6IAAgaIATAAIAAg+IgOAAIAAAVIgbAAIAAgwIBxAAIAAAwIgbAAIAAgVIgOAAIAAA+IATAAIAAAag");
	this.shape_3.setTransform(2.3,29.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgpBWIAAgZIASAAIAKgeIgjhbIgMAAIAAgZIAkAAIAZBKIACAAIAQgxIgLAAIAAgZIA1AAIAAAZIgMAAIgrB5IANAAIAAAZg");
	this.shape_4.setTransform(-10.025,32.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAPA6IAAguIgdAAIAAAUIANAAIAAAaIg9AAIAAgaIAQAAIAAg/IgQAAIAAgaIAwAAIAAArIAdAAIAAgRIgNAAIAAgaIA9AAIAAAaIgQAAIAAA/IAQAAIAAAag");
	this.shape_5.setTransform(-23.275,29.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAFA6IAAgaIAPAAIAAgpIgCAAIgmBDIguAAIAAgaIARAAIAAg/IgRAAIAAgaIA+AAIAAAaIgPAAIAAApIABAAIAnhDIAuAAIAAAaIgRAAIAAA/IARAAIAAAag");
	this.shape_6.setTransform(-37.8,29.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAmA6IAAhPIgBAAIgZBPIgbAAIgZhPIgBAAIAABPIgtAAIAAgaIAQAAIAAg/IgQAAIAAgaIBBAAIAVBJIABAAIAXhJIA/AAIAAAaIgQAAIAAA/IAQAAIAAAag");
	this.shape_7.setTransform(-54.625,29.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-67.9,-46,135.8,92);


(lib.Символ24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgyABQABgbAOgQQAOgRAYAAQAWAAAMAMQANANAAAWQAAANgCAHIg+AAQABAYAaAAQAUAAANgJIAAAcQgNAJgYAAQg6AAgBg7gAATgOQgBgTgQAAQgPAAgCATIAiAAIAAAAg");
	this.shape.setTransform(58.7,-1.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AA3A6IgegvIgJACIAAATIALAAIAAAaIg1AAIAAgaIALAAIAAgTIgJgCIgfAvIghAAIAAgaIANAAIAagkIgXgbIgOAAIAAgaIA0AAIAAAaIgEAAIAPAUIAIACIAAgWIgJAAIAAgaIAxAAIAAAaIgJAAIAAAWIAIgCIAPgUIgFAAIAAgaIA0AAIAAAaIgOAAIgWAaIAbAlIAMAAIAAAag");
	this.shape_1.setTransform(43.7,-1.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgvAzQgJgJAAgOQAAgpBAAAIAAgCQAAgPgVgBQgTAAgPAKIAAgdQAPgJAXAAQAxAAAAAsIAAAvIARAAIAAAaIgwAAIAAgSIgBAAQgGAKgFAEQgIAGgMAAQgPAAgJgJgAgWAWQAAAKAMAAQAIAAAEgFQAGgGAAgKIAAgEQgeAAAAAPg");
	this.shape_2.setTransform(28.425,-1.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAiBJIgCgeIg/AAIgCAeIgdAAIAAg5IAKAAQAOgOADgwIgPAAIAAgaIBwAAIAAAaIgQAAIAAA+IARAAIAAA5gAgLgNQgEAUgGAJIAiAAIAAg9IgVAAQAAAQgDAQg");
	this.shape_3.setTransform(14.85,0.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgnAtQgQgRAAgbQAAgbAQgRQAPgQAYAAQAYAAAPAQQARARAAAbQAAAbgQARQgQAPgYAAQgYAAgPgPgAgWABQAAAeAWAAQAWAAAAgeQAAgfgWAAQgWAAAAAfg");
	this.shape_4.setTransform(2.125,-1.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag+BYIAAgaIAQAAIAAh4IgQAAIAAgaIAvAAIAAAQIACAAQAKgSAWgBQAUAAAMARQAMARAAAZQAAAcgMAQQgMARgVAAQgVAAgKgSIgCAAIACASIAAAdIARAAIAAAagAgNgeIAAAGQAAAcAUAAQAXgBAAgeQAAgegWAAQgVAAAAAbg");
	this.shape_5.setTransform(-11.225,1.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAOA6IAAhYIgbAAIAAA+IANAAIAAAaIg9AAIAAgaIAQAAIAAg/IgQAAIAAgaIB7AAIAAAaIgRAAIAAA/IARAAIAAAag");
	this.shape_6.setTransform(-25.15,-1.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgnAtQgQgRAAgbQAAgbAQgRQAPgQAYAAQAYAAAPAQQARARAAAbQAAAbgQARQgQAPgYAAQgYAAgPgPgAgWABQAAAeAWAAQAWAAAAgeQAAgfgWAAQgWAAAAAfg");
	this.shape_7.setTransform(-44.675,-1.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAOA6IAAhYIgbAAIAAA+IANAAIAAAaIg9AAIAAgaIAQAAIAAg/IgQAAIAAgaIB7AAIAAAaIgRAAIAAA/IARAAIAAAag");
	this.shape_8.setTransform(-57.9,-1.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68.7,-46,137.4,87.2);


(lib.Символ23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgdAtQgPgQAAgdQAAgaAPgRQAQgQAaAAQASAAAOAHIAAAqIgaAAIAAgTIgFgBQgMAAgGAIQgHAIAAAOQAAAfAcAAQASAAAKgJIAAAfQgKAHgWAAQgbAAgPgPg");
	this.shape.setTransform(78.725,-9.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAFA6IAAgaIAPAAIAAgpIgCAAIgmBDIguAAIAAgaIARAAIAAg/IgRAAIAAgaIA+AAIAAAaIgPAAIAAApIABAAIAnhDIAuAAIAAAaIgRAAIAAA/IARAAIAAAag");
	this.shape_1.setTransform(66.05,-9.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag2A6IAAgaIARAAIAAg/IgRAAIAAgaIA9AAQAsAAAAAeQAAAUgUAFIAAABQAYADgBAXQAAAhgsAAgAgGAjIALAAQAQAAAAgMQAAgNgQAAIgLAAgAgGgLIAIAAQAPAAABgMQgBgLgPAAIgIAAg");
	this.shape_2.setTransform(52.25,-9.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag+BXIAAgZIAQAAIAAh4IgQAAIAAgaIAvAAIAAAQIACAAQAKgSAWAAQAUgBAMASQAMAPAAAaQAAAcgMAQQgMAQgVAAQgVAAgKgRIgCAAIACARIAAAeIARAAIAAAZgAgNgfIAAAIQAAAbAUAAQAXAAAAgfQAAgegWAAQgVAAAAAag");
	this.shape_3.setTransform(38.975,-6.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgxAAQAAgbANgQQAPgQAXAAQAXAAAMAMQAOAMAAAYQgBAMgCAHIg+AAQABAYAbAAQATAAANgIIAAAcQgNAIgYAAQg7AAABg8gAASgOQAAgTgRAAQgPAAgBATIAhAAIAAAAg");
	this.shape_4.setTransform(26.25,-9.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdAtQgPgQAAgdQAAgaAPgRQAQgQAaAAQASAAAOAHIAAAqIgaAAIAAgTIgFgBQgMAAgGAIQgHAIAAAOQAAAfAcAAQASAAAKgJIAAAfQgKAHgWAAQgbAAgPgPg");
	this.shape_5.setTransform(14.925,-9.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAFBRIAAgZIAPAAIAAgqIgCAAIgmBDIguAAIAAgZIARAAIAAhAIgRAAIAAgZIA+AAIAAAZIgPAAIAAApIABAAIAnhCIAuAAIAAAZIgRAAIAABAIARAAIAAAZgAgbgzQgMgKAAgTIAcAAQAAAOALAAQAMAAAAgOIAcAAQAAATgNAKQgLAIgQAAQgQAAgLgIg");
	this.shape_6.setTransform(-4.05,-11.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAiA6IAAhZIgRAAIAAgaIBBAAIAAAaIgQAAIAAA/IAQAAIAAAagAhRA6IAAgaIAQAAIAAg/IgQAAIAAgaIBAAAIAAAaIgQAAIAAAPIALAAQAXAAANAKQAMAJAAAQQAAASgMAKQgNALgXAAgAghAhIAKAAQARAAAAgNQAAgMgRAAIgKAAg");
	this.shape_7.setTransform(-20.475,-9.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag2A6IAAgaIARAAIAAg/IgRAAIAAgaIA9AAQAsAAAAAeQAAAUgUAFIAAABQAYADgBAXQAAAhgsAAgAgGAjIALAAQAQAAABgMQgBgNgQAAIgLAAgAgGgLIAIAAQAQAAgBgMQABgLgQAAIgIAAg");
	this.shape_8.setTransform(-35.85,-9.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag+BXIAAgZIAQAAIAAh4IgQAAIAAgaIAvAAIAAAQIACAAQAKgSAWAAQAUgBAMASQAMAPAAAaQAAAcgMAQQgMAQgVAAQgVAAgKgRIgCAAIACARIAAAeIARAAIAAAZgAgNgfIAAAIQAAAbAUAAQAXAAAAgfQAAgegWAAQgVAAAAAag");
	this.shape_9.setTransform(-49.125,-6.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgxAAQAAgbANgQQAOgQAZAAQAVAAANAMQAOAMAAAYQgBAMgCAHIg+AAQABAYAbAAQATAAANgIIAAAcQgNAIgYAAQg7AAABg8gAASgOQAAgTgRAAQgPAAgBATIAhAAIAAAAg");
	this.shape_10.setTransform(-61.85,-9.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAYBVIAAiLIgvAAIAABwIAUAAIAAAbIhJAAIAAgbIAUAAIAAhzIgUAAIAAgbICZAAIAAAbIgUAAIAABzIAUAAIAAAbg");
	this.shape_11.setTransform(-76.125,-12.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-88.5,-32.9,177,65.8);


(lib.Символ19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUBWIAAggIAWAAQAOAAAHgHQAIgHAAgNQAAgbgdAAIgWAAIAAgeIAaAAQAeAAAPARQANAOAAAaQAAAZgNAPQgQASgeABgAg/BWIAAiqIAkAAIAACqg");
	this.shape.setTransform(48.65,0.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgRBWIAAiqIAjAAIAACqgAAZg1IAAgfIAoAAIAAAfgAhAg1IAAgfIAoAAIAAAfg");
	this.shape_1.setTransform(33.8,0.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAoBWIg7iqIAkAAIA8CqgAhMBWIA1ifIARAwIgSA5IAlAAIAKAcIg4AAIgIAag");
	this.shape_2.setTransform(18.85,0.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAyBqIAAgpIgtAAIAAggIAVAAIAAhqIgVAAIAAggIA5AAIAACKIAYAAIAABJgAhUBqIAAhJQASgCAEgRQAFgNAAgqIAAhAIA4AAIAAAgIgVAAIAAAkQAAAwgIAWIAdAAIAAAgIgwAAIAAApg");
	this.shape_3.setTransform(1.95,2.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AADA5QARgCALgNQANgPAAgbQAAgbgOgQQgKgLgRgCIAAghQAfABAUATQAbAYAAAtQAAArgZAYQgVAVggACgAg4BDQgYgZAAgqQAAgsAagYQAVgUAegBIAAAhQgQACgLAMQgNAPAAAbQAAAaAMAQQALANARACIAAAhQgggCgVgVg");
	this.shape_4.setTransform(-15.925,0.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag/BWIAAiqIAkAAIAACqgAgUAdIAAgdIAUAAQAcAAAAgcQAAgNgIgHQgHgHgNAAIgUAAIAAgdIAWAAQAfAAARARQAOAOAAAZQAAAagPAOQgQARgeAAg");
	this.shape_5.setTransform(-31.9,0.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAgBWIAAiLIgcAAIAAgfIBAAAIAACqgAhDBWIAAiqIBAAAIAAAfIgcAAIAACLg");
	this.shape_6.setTransform(-47.975,0.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.2,-18.6,120.5,37.2);


(lib.Символ18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUBWIAAggIAWAAQANAAAIgHQAIgHAAgMQAAgdgdABIgWAAIAAgeIAaAAQAdAAAQARQANAOAAAbQAAAYgNAQQgQASgfAAgAg/BWIAAirIAjAAIAACrg");
	this.shape.setTransform(62.525,0.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgRBWIAAirIAjAAIAACrgAAZg1IAAggIApAAIAAAggAhBg1IAAggIApAAIAAAgg");
	this.shape_1.setTransform(47.6,0.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAhBWIAAirIAkAAIAACrgAhEBWIAAirIAjAAIAACrgAgZAPIAzhXIAAA6IgzBYg");
	this.shape_2.setTransform(32.125,0.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgRBWIAAirIAjAAIAACrgAAZg1IAAggIApAAIAAAggAhBg1IAAggIApAAIAAAgg");
	this.shape_3.setTransform(16.65,0.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAoBWIg7irIAkAAIA9CrgAhNBWIA2ifIARAwIgSA5IAlAAIAKAcIg4AAIgIAag");
	this.shape_4.setTransform(1.625,0.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag/BWIAAirIAjAAIAACrgAgUAdIAAgdIAUAAQAcAAAAgdQAAgNgIgGQgHgIgNABIgUAAIAAgeIAWAAQAfAAARARQAOAPAAAYQAAAbgPAOQgQARgeAAg");
	this.shape_5.setTransform(-13.525,0.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgRBWIAAirIAjAAIAACrgAAag1IAAggIAoAAIAAAggAhBg1IAAggIAoAAIAAAgg");
	this.shape_6.setTransform(-28.5,0.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAEA5QARgBALgNQAMgQAAgbQAAgcgNgPQgLgMgQgBIAAgiQAeACAVATQAbAYAAAtQAAArgZAZQgVAVggABgAg4BEQgZgZAAgrQAAgtAagYQAVgTAfgCIAAAiQgQABgLAMQgNAQAAAbQAAAbAMAPQALAOARABIAAAhQgggBgVgVg");
	this.shape_7.setTransform(-44.475,0.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAgBWIAAiLIgcAAIAAggIBAAAIAACrgAhDBWIAAirIBAAAIAAAgIgdAAIAACLg");
	this.shape_8.setTransform(-61.7,0.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74.1,-18.7,148.3,37.5);


(lib.Символ17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVBYIAAghIAXAAQAOAAAHgHQAJgHgBgNQAAgdgdAAIgXAAIAAgeIAbAAQAeAAAPARQAOAPABAbQAAAZgOAQQgQASgfABgAhBBYIAAivIAlAAIAACvg");
	this.shape.setTransform(58.5,0.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgRBYIAAivIAjAAIAACvgAAag2IAAghIApAAIAAAhgAhCg2IAAghIApAAIAAAhg");
	this.shape_1.setTransform(43.275,0.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAiBYIAAivIAlAAIAACvgAhGBYIAAivIAlAAIAACvgAgaAPIA1hZIAAA8Ig1BZg");
	this.shape_2.setTransform(27.525,0.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhABYIAAivIAkAAIAACvgAgUAdIAAgdIAUAAQAdAAAAgdQAAgNgIgIQgIgGgNAAIgUAAIAAgfIAWAAQAgAAARASQAOAPAAAZQABAbgPAOQgRARgfAAg");
	this.shape_3.setTransform(11.65,0.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AApBYIg9ivIAlAAIA+CvgAhOBYIA3ijIARAyIgSA5IAlAAIALAdIg5AAIgJAbg");
	this.shape_4.setTransform(-4.5,0.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAzBtIAAgrIguAAIAAggIAWAAIAAhtIgWAAIAAghIA7AAIAACOIAYAAIAABLgAhXBtIAAhLQATgDAFgRQAEgNAAgsIAAhBIA6AAIAAAhIgVAAIAAAkQAAAygJAXIAeAAIAAAgIgxAAIAAArg");
	this.shape_5.setTransform(-21.825,2.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAEA6QARgCALgNQANgPAAgcQAAgcgOgQQgLgMgQgBIAAgiQAfABAVATQAbAZAAAuQAAAsgZAZQgWAWggABgAg5BFQgZgZAAgsQAAgtAagZQAWgUAfgBIAAAiQgQABgLANQgOAPAAAcQAAAbANAQQALAOARABIAAAiQgggCgWgVg");
	this.shape_6.setTransform(-40.175,0.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAhBYIAAiOIgdAAIAAghIBBAAIAACvgAhEBYIAAivIBBAAIAAAhIgdAAIAACOg");
	this.shape_7.setTransform(-57.7,0.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.3,-19.1,140.7,38.2);


(lib.Символ16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUBXIAAggIAWAAQAOAAAIgHQAHgHAAgNQAAgdgdAAIgWAAIAAgeIAaAAQAeAAAQASQANAOAAAbQAAAZgNAPQgQATgfAAgAhABXIAAitIAkAAIAACtg");
	this.shape.setTransform(41.725,0.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgRBXIAAitIAkAAIAACtgAAag2IAAggIApAAIAAAggAhCg2IAAggIAqAAIAAAgg");
	this.shape_1.setTransform(26.55,0.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA4BXIAAitIAkAAIAACtgAgvBXIAAggIAXAAQAOAAAIgHQAGgHAAgNQAAgdgcAAIgXAAIAAgeIAbAAQAdAAAQASQANAOAAAbQAAAZgNAPQgQATgeAAgAhbBXIAAitIAkAAIAACtg");
	this.shape_2.setTransform(8.675,0.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgUBXIAAggIAWAAQAOAAAIgHQAHgHAAgNQAAgagdAAIgWAAIAAgdIAaAAQA7AAAAA3QAAAZgNAPQgQATgfAAgAhABXIAAitIAkAAIAACtgAgUg2IAAggIBGAAIAAAgg");
	this.shape_3.setTransform(-9.325,0.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AApBXIg9itIAlAAIA+CtgAhOBXIA3iiIARAyIgSA5IAmAAIAKAdIg5AAIgJAag");
	this.shape_4.setTransform(-25.425,0.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAEA+QAMgBAJgGQAKgHAAgMQAAgQgPgHQgJgEgLAAIgPAAIAAgZIAQAAQALAAAIgFQALgGAAgMQAAgKgJgHQgHgGgLAAIAAgdQAdABARAOQASAOAAAVQAAAOgKALQgIAHgMAEQAMADAKAIQANAMgBARQABAZgVAQQgTAPgdABgAgzBMQgQgOgEgeIAigFQADARAGAHQAHAKATABIAAAeQgggBgRgPgAhEgjQAMg2A2gCIAAAdQgQABgIAJQgFAHgDAOg");
	this.shape_5.setTransform(-41.45,0.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53.6,-19,107.2,38);


(lib.Символ12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CD1278").ss(1,1,1).p("Aq+i9IV9AAQBOAAA4A4QA3A3AABOIAAAAQAABPg3A3Qg4A4hOAAI19AAQhPAAg3g4Qg3g3AAhPIAAAAQAAhOA3g3QA3g4BPAAg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.2,-19.9,180.4,39.9);


(lib.Символ11копия3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CD1278").ss(1,1,1).p("Aq+i9IV9AAQBOAAA4A4QA3A3AABOIAAAAQAABPg3A3Qg4A4hOAAI19AAQhPAAg3g4Qg3g3AAhPIAAAAQAAhOA3g3QA3g4BPAAg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.2,-20,180.4,40);


(lib.Символ11копия2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CD1277").s().p("Aq+C+QhPAAg3g4Qg3g3AAhPIAAAAQAAhOA3g3QA3g4BPAAIV9AAQBOAAA3A4QA4A3AABOIAAAAQAABPg4A3Qg3A4hOAAg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-89.2,-19,178.4,38);


(lib.Символ10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CD1278").ss(1,1,1).p("Aq+i9IV9AAQBOAAA4A4QA3A3AABOIAAAAQAABPg3A3Qg4A4hOAAI19AAQhPAAg3g4Qg3g3AAhPIAAAAQAAhOA3g3QA3g4BPAAg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.2,-20,180.4,40);


(lib.Символ9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CD1278").ss(1,1,1).p("Aq+i9IV9AAQBOAAA4A4QA3A3AABOIAAAAQAABPg3A3Qg4A4hOAAI19AAQhPAAg3g4Qg3g3AAhPIAAAAQAAhOA3g3QA3g4BPAAg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.2,-20,180.4,40);


(lib.Символ8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhRhMQBMhxCbgiIAADqQgpARgSAhQgYAwAGBfIjdAUQgIi8BLhwg");
	this.shape.setTransform(21.0464,-8.0083,0.244,0.244);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AllB4IAAjZILLgXIAADwg");
	this.shape_1.setTransform(25.9251,9.433,0.244,0.244);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AjDEYQCSiLA5hEQAtg2ARg0QAQg1gSgmQgLgYgZgMQgZgMggACIAAjmQBQgMBGATQBHATAxAvQAuArAWA6QAWA7gGA/QgKB4hEBuQhEBvihCdIlgALg");
	this.shape_2.setTransform(26.3228,-3.803,0.244,0.244);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AiEBjIAAi9IEJgIIAADFg");
	this.shape_3.setTransform(-2.6495,9.9515,0.244,0.244);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhaGqIAAs5IC1gaIAANTg");
	this.shape_4.setTransform(-8.9513,1.9782,0.244,0.244);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AiZBsIAAjOIEygKIAADYg");
	this.shape_5.setTransform(11.7903,9.7258,0.244,0.244);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhkhgIDJgRIAADYIjJALg");
	this.shape_6.setTransform(10.497,0.7398,0.244,0.244);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AiZhRIEygrIAADYIkyAhg");
	this.shape_7.setTransform(11.7903,-8.4963,0.244,0.244);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhoHSIAAuGIDRgdIAAOjg");
	this.shape_8.setTransform(4.5247,1.0021,0.244,0.244);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhzBbIAAiuIDngHIAAC1g");
	this.shape_9.setTransform(-15.5032,10.1528,0.244,0.244);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhLhRICXgOIAAC2IiXAJg");
	this.shape_10.setTransform(-16.4731,2.6492,0.244,0.244);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhzhGIDnghIAAC1IjnAag");
	this.shape_11.setTransform(-15.5032,-5.0556,0.244,0.244);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhPGGIAAr1ICfgXIAAMMg");
	this.shape_12.setTransform(-21.0241,2.8445,0.244,0.244);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhLEQIAAoQICXgPIAAIfg");
	this.shape_13.setTransform(-29.4061,5.7361,0.244,0.244);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AjPgvIGfg6IAACmImfAtg");
	this.shape_14.setTransform(-29.4244,-3.3475,0.244,0.244);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.5,-13.7,69.2,26.1);


(lib.Символ6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAvIAAgRIApAAIAAARgAggAvIAAhdIAUAAIAABdgAgIAIIAAgQIAlAAIAAAQgAgIgdIAAgRIAnAAIAAARg");
	this.shape.setTransform(35.475,-0.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgIAvIAAgRIApAAIAAARgAggAvIAAhdIAUAAIAABdgAgIAIIAAgQIAlAAIAAAQgAgIgdIAAgRIAnAAIAAARg");
	this.shape_1.setTransform(27.575,-0.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AASAvIAAgpIgQAAIAAgQIAQAAIAAgkIAUAAIAABdgAglAvIAAhdIAUAAIAAAkIAQAAIAAAQIgQAAIAAApg");
	this.shape_2.setTransform(18.925,-0.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgLAvIAAgRIAMAAQAHAAAFgEQAEgEAAgGQAAgPgQAAIgMAAIAAgOIAOAAQAgAAAAAdQAAAMgHAJQgIAKgRAAgAgiAvIAAhdIAUAAIAABdgAgLgdIAAgRIAmAAIAAARg");
	this.shape_3.setTransform(10.45,-0.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AACAfQAJgBAHgHQAGgIABgPQAAgPgIgIQgGgGgJgBIAAgSQARAAALALQAPANAAAYQAAAYgOANQgMAMgRAAgAgeAlQgOgOAAgXQAAgYAPgNQAMgLAQAAIAAASQgJABgGAGQgHAJAAAOQAAAOAHAJQAGAHAJABIAAASQgRgBgMgLg");
	this.shape_4.setTransform(1.3,-0.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgiAvIAAhdIATAAIAABdgAgLAQIAAgQIALAAQAPAAAAgPQAAgHgEgEQgEgDgHAAIgLAAIAAgRIAMAAQASAAAJAJQAHAJAAANQAAAOgIAHQgIAKgRAAg");
	this.shape_5.setTransform(-7.45,-0.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAbA7IAAgXIgYAAIAAgSIAMAAIAAg6IgMAAIAAgRIAfAAIAABLIANAAIAAApgAguA7IAAgpQAKgBADgJQACgIAAgXIAAgiIAfAAIAAARIgLAAIAAAUQAAAagFAMIAQAAIAAASIgaAAIAAAXg");
	this.shape_6.setTransform(-16.7,0.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AACAfQAJgBAGgHQAIgIAAgPQAAgPgIgIQgGgGgJgBIAAgSQAQAAAMALQAOANAAAYQAAAYgNANQgMAMgRAAgAgeAlQgOgOAAgXQAAgYAPgNQALgLARAAIAAASQgJABgGAGQgHAJAAAOQAAAOAHAJQAGAHAJABIAAASQgRgBgMgLg");
	this.shape_7.setTransform(-26.5,-0.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AASAvIAAhMIgQAAIAAgRIAjAAIAABdgAgkAvIAAhdIAjAAIAAARIgQAAIAABMg");
	this.shape_8.setTransform(-35.875,-0.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CD1277").s().p("AohCHIAAkNIRDAAIAAENg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54.6,-13.5,109.30000000000001,27);


(lib.Символ5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBnIAAgmIAaAAQARAAAJgIQAJgIAAgQQAAgigjAAIgaAAIAAgjIAfAAQAkAAASAUQAQASAAAfQAAAdgQATQgSAWgmAAgAhMBnIAAjNIArAAIAADNg");
	this.shape.setTransform(79.775,0.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgVBnIAAjNIAqAAIAADNgAAehAIAAgmIAxAAIAAAmgAhOhAIAAgmIAxAAIAAAmg");
	this.shape_1.setTransform(61.875,0.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAxBnIhJjNIAsAAIBJDNgAhcBnIBAi/IAUA6IgUBEIAsAAIAMAiIhDAAIgKAfg");
	this.shape_2.setTransform(43.8,0.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAuBnIAAinIgZAAIAAgmIBEAAIAADNgAhYBBQAXAAAFgWQAEgPAAg1IAAhNIBDAAIAAAmIgYAAIAAAsQABAogEAVQgDAVgLAOQgSAbgoAAg");
	this.shape_3.setTransform(23.6,0.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgTBnIAAgmIBbAAIAAAmgAhHBnIAAjNIArAAIAADNgAgTARIAAgkIBSAAIAAAkgAgThAIAAgmIBXAAIAAAmg");
	this.shape_4.setTransform(5.75,0.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AA8CAIAAgyIg2AAIAAgmIAaAAIAAiBIgaAAIAAgmIBFAAIAACnIAcAAIAABYgAhmCAIAAhYQAWgDAGgUQAEgQAAgzIAAhNIBEAAIAAAmIgZAAIAAAsQAAA6gKAbIAjAAIAAAmIg5AAIAAAyg");
	this.shape_5.setTransform(-14.025,2.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAFBEQATgCAOgPQAPgTAAggQAAghgRgSQgMgPgTgCIAAgnQAjABAaAWQAgAeAAA2QAAA0geAeQgaAZglACgAhEBRQgdgeAAgzQAAg2AggdQAZgXAlgBIAAAnQgUACgNAPQgRASAAAhQAAAfAQATQANAQAVACIAAApQgngDgagZg");
	this.shape_6.setTransform(-42.25,0.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgVBnIAAjNIAqAAIAADNgAAehAIAAgmIAxAAIAAAmgAhOhAIAAgmIAxAAIAAAmg");
	this.shape_7.setTransform(-61.325,0.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAkBnIAAjNIArAAIAADNgAhBAOQgOgQAAghIAAhDIArAAIAABDQAAAUAJAHQAGAFARAAQALAAAUgGIAAAmQgWAGgUAAQgkAAgOgVg");
	this.shape_8.setTransform(-79.5,0.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93.8,-22.4,187.6,44.9);


(lib.Символ4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgWBpIAAgqIAnAAIAAAqgAgTAwIAAgUQAAgPAHgLQAGgGAKgHIARgOQAIgHgBgLQABgMgIgHQgHgGgLgCIAAgiQAhACASAUQAQAPAAAVQAAAUgJANQgGAJgNAIIgTANQgJAIAAALIAAAMgAhFgpQABgSALgRQARgaAkgCIAAAiQgdADAAAmg");
	this.shape.setTransform(49.2,-0.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYBnIAAgmIAaAAQARAAAJgIQAJgIAAgQQAAgfgjAAIgaAAIAAgiIAfAAQBGAAAABBQAAAdgQATQgSAWgmAAgAhMBnIAAjNIArAAIAADNgAgYhAIAAgmIBTAAIAAAmg");
	this.shape_1.setTransform(32.875,0.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhDBnIAAjNIArAAIAADNgAgPhAIAAgmIBTAAIAAAmg");
	this.shape_2.setTransform(16.125,0.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAoBnIAAjNIArAAIAADNgAhSBnIAAjNIArAAIAADNgAgeASIA+hpIAABHIg+Bpg");
	this.shape_3.setTransform(-9.075,0.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAoBnIAAhZIgkAAIAAglIAkAAIAAhPIArAAIAADNgAhSBnIAAjNIArAAIAABPIAkAAIAAAlIgkAAIAABZg");
	this.shape_4.setTransform(-35.875,0.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAoBnIAAjNIArAAIAADNgAhSBnIAAjNIArAAIAADNgAgeASIA+hpIAABHIg+Bpg");
	this.shape_5.setTransform(-55.975,0.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AA4BnIAAhIIAphtIAAC1gAgTBnIhNjNIApAAIBLDNgAhgBnIAAi1IApBsIAABJgAAFAlIAziLIApAAIhIDBg");
	this.shape_6.setTransform(-77.425,0.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93.8,-22.4,156.3,44.9);


(lib.Символ3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAoBnIAAjNIArAAIAADNgAhSBnIAAjNIArAAIAADNgAgeASIA+hpIAABHIg+Bpg");
	this.shape.setTransform(79.875,0.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AA4BnIAAhIIAphtIAAC1gAgTBnIhNjNIApAAIBLDNgAhgBnIAAi1IApBsIAABJgAAFAlIAziLIApAAIhIDBg");
	this.shape_1.setTransform(58.475,0.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAoBnIAAjNIArAAIAADNgAhSBnIAAjNIArAAIAADNgAgeASIA+hpIAABHIg+Bpg");
	this.shape_2.setTransform(36.925,0.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAoBnIAAhZIgkAAIAAglIAkAAIAAhPIArAAIAADNgAhSBnIAAjNIArAAIAABPIAkAAIAAAlIgkAAIAABZg");
	this.shape_3.setTransform(16.825,0.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AA4BnIAAgmIAaAAIAAinIArAAIAADNgAguBnIAAgmIAaAAIAAinIAqAAIAACnIAZAAIAAAmgAh8BnIAAjNIArAAIAACnIAaAAIAAAmg");
	this.shape_4.setTransform(-7.425,0.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAoBnIAAjNIArAAIAADNgAhSBnIAAjNIArAAIAADNgAgeASIA+hpIAABHIg+Bpg");
	this.shape_5.setTransform(-31.675,0.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAuBnIAAinIgZAAIAAgmIBEAAIAADNgAhYBBQAXAAAGgWQADgPAAg1IAAhNIBEAAIAAAmIgYAAIAAAsQgBAogDAVQgDAVgKAOQgUAbgnAAg");
	this.shape_6.setTransform(-52.4,0.075);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAIBEQAigCAMglIAoATQgZA6g9ADgAhFBMQgYgeAAguQAAg2AfgdQAZgXAlgBIAAAnQgWACgNARQgOATAAAeQAAAcANATQANATAXACIAAApQgrgCgagfgAAlg3QgMgLgRgCIAAgnQA5ACAaA3IgnASQgEgNgLgKg");
	this.shape_7.setTransform(-78.575,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93.8,-22.4,189.2,44.9);


(lib.Символ2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AxIPLIAA+VMAiRAAAIAAeVg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.7,-97.1,219.4,194.3);


(lib.boss_2копия2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CD1277").s().p("EAwxA6iMAAAhk8Mhc7AAAMAAABjaMguHAAAMAAAhvnMAqNAAAIAAj6MBuXAAAIAAAyIb/AAMAAAB0Rg");
	this.shape.setTransform(561.825,333.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(377).to({_off:true},1).wait(86));

	// Слой_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag+BZIA3gbIBKAPIgHAlgAhZBUIAIglIBEghQAhgPAMgLQAKgJADgPQACgLgFgLQgGgMgLgFIAHgiQAhAIAPAXQAOAWgGAdQgFAXgTAQQgNAMgbANIhlAxgAg/gqIADgQQAFgZAWgQQAYgSAgAGIgHAiQgNgBgKAJQgKAIgDANIgDATg");
	this.shape_1.setTransform(456.365,288.3356);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgmBjIAIgnIBaATIgHAmgAhZBYIApjMIArAJIgpDLgAgUANIAHgkIBSARIgHAkgAgEhEIAHglIBXARIgHAmg");
	this.shape_2.setTransform(439.825,284.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgRBkIAIgmIBOAQIgIAmgAhEBZIApjMIAqAJIgoDMg");
	this.shape_3.setTransform(422.35,281.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgmBiIAIgmIBaATIgHAmgAhZBYIApjMIArAIIgpDMgAgUANIAHgkIBSAQIgHAlgAgEhDIAHgnIBXASIgHAmg");
	this.shape_4.setTransform(407.225,277.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag7BoIAqjMIAqAJIgpDMgAAbg0IAHgmIAwAKIgHAmgAhRhKIAHgmIAxAKIgIAmg");
	this.shape_5.setTransform(391.9,273.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAwBpIgfjaIAsAJIAgDagAhcBNIBniyIAIA/IgiA/IAsAJIAFAkIhDgOIgQAdg");
	this.shape_6.setTransform(469.8,260.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("ABEB4IgnhmIAIglIBIhBIAyAKIhcBMIA1CBgAgoBiIAojMIArAIIgpDNgAieBKIBihgIg3hrIAyAKIAqBXIgIAmIhMBPg");
	this.shape_7.setTransform(447.825,254.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AhaBiIApjMIArAJIgpDMgAADAvIgcgGIAHgkIAYAFQAiAHAHgiQADgPgIgKQgHgKgQgDIgXgFIAGgjIAbAFQAmAIAQAYQAMAWgFAcQgHAfgVAPQgQALgWAAQgKAAgLgCg");
	this.shape_8.setTransform(424.384,249.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AATBvIAqjMIArAIIgqDMgAhmBWIApjMIArAIIgqDMgAgiAMIBThcIgOBGIhTBcg");
	this.shape_9.setTransform(405.6,246.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgFBuIgfgGIAIgmIAbAFQAQAEALgHQAKgGADgPQAHgfgjgHIgagGIAHghIAfAGQBFAOgNBBQgGAdgTAPQgQANgYAAQgKAAgJgCgAhXBdIApjMIArAJIgpDMgAgCg+IAHgmIBTARIgHAmg");
	this.shape_10.setTransform(386.125,241.8832);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},377).to({state:[]},1).wait(86));

	// Слой_2
	this.instance = new lib.visual_228();
	this.instance.parent = this;
	this.instance.setTransform(265.85,37.55,0.752,0.752);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(377).to({_off:true},1).wait(86));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16,-41,1155.7,854.6);


(lib.boss_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhnfA5cMAAAhkMIhtAAIAAuqMDSaAAAIAAOqIo0AAMAAABj8Mg9lAAAMAAAhj8MheUAAAMAAABkMg");
	this.shape.setTransform(660.8,326.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(377).to({_off:true},1).wait(86));

	// Слой_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag+BZIA3gbIBKAPIgHAlgAhZBUIAIglIBEghQAhgPAMgLQAKgJADgPQACgLgFgLQgGgMgLgFIAHgiQAhAIAPAXQAOAWgGAdQgFAXgTAQQgNAMgbANIhlAxgAg/gqIADgQQAFgZAWgQQAYgSAgAGIgHAiQgNgBgKAJQgKAIgDANIgDATg");
	this.shape_1.setTransform(456.365,288.3356);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgmBjIAIgnIBaATIgHAmgAhZBYIApjMIArAJIgpDLgAgUANIAHgkIBSARIgHAkgAgEhEIAHglIBXARIgHAmg");
	this.shape_2.setTransform(439.825,284.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgRBkIAIgmIBOAQIgIAmgAhEBZIApjMIAqAJIgoDMg");
	this.shape_3.setTransform(422.35,281.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgmBiIAIgmIBaATIgHAmgAhZBYIApjMIArAIIgpDMgAgUANIAHgkIBSAQIgHAlgAgEhDIAHgnIBXASIgHAmg");
	this.shape_4.setTransform(407.225,277.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag7BoIAqjMIAqAJIgpDMgAAbg0IAHgmIAwAKIgHAmgAhRhKIAHgmIAxAKIgIAmg");
	this.shape_5.setTransform(391.9,273.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAwBpIgfjaIAsAJIAgDagAhcBNIBniyIAIA/IgiA/IAsAJIAFAkIhDgOIgQAdg");
	this.shape_6.setTransform(469.8,260.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("ABEB4IgnhmIAIglIBIhBIAyAKIhcBMIA1CBgAgoBiIAojMIArAIIgpDNgAieBKIBihgIg3hrIAyAKIAqBXIgIAmIhMBPg");
	this.shape_7.setTransform(447.825,254.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AhaBiIApjMIArAJIgpDMgAADAvIgcgGIAHgkIAYAFQAiAHAHgiQADgPgIgKQgHgKgQgDIgXgFIAGgjIAbAFQAmAIAQAYQAMAWgFAcQgHAfgVAPQgQALgWAAQgKAAgLgCg");
	this.shape_8.setTransform(424.384,249.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AATBvIAqjMIArAIIgqDMgAhmBWIApjMIArAIIgqDMgAgiAMIBThcIgOBGIhTBcg");
	this.shape_9.setTransform(405.6,246.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgFBuIgfgGIAIgmIAbAFQAQAEALgHQAKgGADgPQAHgfgjgHIgagGIAHghIAfAGQBFAOgNBBQgGAdgTAPQgQANgYAAQgKAAgJgCgAhXBdIApjMIArAJIgpDMgAgCg+IAHgmIBTARIgHAmg");
	this.shape_10.setTransform(386.125,241.8832);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},377).to({state:[]},1).wait(86));

	// Слой_2
	this.instance = new lib.visual_22();
	this.instance.parent = this;
	this.instance.setTransform(265.85,37.55,0.752,0.752);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(377).to({_off:true},1).wait(86));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.5,-40.7,1346.7,854.3000000000001);


(lib.Анимация3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CD1277").s().p("EA0zhE5MAm5BrKMiR0AdvMgljAA6g");
	this.shape.setTransform(78.825,43.725);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-508,-397.3,1173.7,882.1);


(lib.Символ33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Анимация3("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(6.8,-35.6,1,1,-50.9306);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-609.5,689.5,1273.8);


(lib.Символ15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Символ10("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.2,-20,180.4,40);


(lib.Символ14копия2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Символ11копия2("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-89.2,-19,178.4,38);


(lib.Символ14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Символ11копия3("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.2,-20,180.4,40);


(lib.Символ13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Символ12("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.2,-19.9,180.4,39.9);


(lib.Символ1копия3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// SubLineLast
	this.instance = new lib.Символ26("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-8.3,-120.9,0.9036,0.9036,0,0,0,0.1,-0.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(333).to({_off:false},0).to({alpha:1},10,cjs.Ease.quadInOut).wait(42).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).to({_off:true},88).wait(5));

	// SubLine3
	this.instance_1 = new lib.Символ25("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-37.25,-113.25,0.9726,0.9726,0,0,0,-0.1,-0.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(265).to({_off:false},0).to({alpha:1},10,cjs.Ease.quadInOut).wait(49).to({startPosition:0},0).to({alpha:0},10,cjs.Ease.quadInOut).to({_off:true},147).wait(8));

	// SubLine2
	this.instance_2 = new lib.Символ24("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-36.5,-108.65,0.9726,0.9726,0,0,0,-0.1,-0.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(263).to({_off:false},0).to({alpha:1},10,cjs.Ease.quadInOut).wait(51).to({startPosition:0},0).to({alpha:0},10,cjs.Ease.quadInOut).to({_off:true},147).wait(8));

	// SubLine1
	this.instance_3 = new lib.Символ23("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-17.2,-124.05,0.9726,0.9726,0,0,0,-0.1,-0.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(261).to({_off:false},0).to({alpha:1},10,cjs.Ease.quadInOut).wait(53).to({startPosition:0},0).to({alpha:0},10,cjs.Ease.quadInOut).to({_off:true},147).wait(8));

	// Prodat
	this.instance_4 = new lib.Символ19("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(181.5,-80.45,0.934,0.934,0,0,0,0.1,-0.1);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(110).to({_off:false},0).to({alpha:1},12,cjs.Ease.quadInOut).wait(121).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(235));

	// Ramka_3___копия
	this.instance_5 = new lib.Символ14копия2("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(181.5,-80.45,0.934,0.934,0,0,0,0.1,-0.2);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(187).to({_off:false},0).to({alpha:1},10,cjs.Ease.quadInOut).wait(46).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(235));

	// Ramka_1
	this.instance_6 = new lib.Символ9("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-4.2,-80.9,0.934,0.934,0,0,0,-0.1,-0.1);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(116).to({_off:false},0).to({alpha:1},12,cjs.Ease.quadInOut).wait(111).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(239));

	// Zabit
	this.instance_7 = new lib.Символ16("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(-4.2,-81,0.934,0.934,0,0,0,-0.1,-0.1);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(116).to({_off:false},0).to({alpha:1},12,cjs.Ease.quadInOut).wait(59).to({startPosition:0},0).to({alpha:0.3594},10,cjs.Ease.quadInOut).wait(42).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(239));

	// Ramka_2
	this.instance_8 = new lib.Символ15("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(-4.1,-35.25,0.934,0.934);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(113).to({_off:false},0).to({alpha:1},12,cjs.Ease.quadInOut).wait(116).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(237));

	// Podarit
	this.instance_9 = new lib.Символ17("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(-4.2,-34.85,0.934,0.934,0,0,0,-0.1,-0.1);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(113).to({_off:false},0).to({alpha:1},12,cjs.Ease.quadInOut).wait(62).to({startPosition:0},0).to({alpha:0.3594},10,cjs.Ease.quadInOut).wait(44).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(237));

	// Ramka_3
	this.instance_10 = new lib.Символ14("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(181.5,-80.45,0.934,0.934,0,0,0,0.1,-0.2);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(110).to({_off:false},0).to({alpha:1},12,cjs.Ease.quadInOut).wait(121).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(235));

	// Ramka_4
	this.instance_11 = new lib.Символ13("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(181.5,-35.25,0.934,0.934,0,0,0,0.1,0);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(107).to({_off:false},0).to({alpha:1},12,cjs.Ease.quadInOut).wait(126).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(233));

	// Potratit
	this.instance_12 = new lib.Символ18("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(181.5,-34.15,0.934,0.934,0,0,0,0.1,0);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(107).to({_off:false},0).to({alpha:1},12,cjs.Ease.quadInOut).wait(68).to({startPosition:0},0).to({alpha:0.3594},10,cjs.Ease.quadInOut).wait(48).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(233));

	// Button
	this.instance_13 = new lib.Символ6("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(-42.25,-32.5,0.7556,0.7556);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(23).to({_off:false},0).to({scaleX:1.0485,scaleY:1.0485,alpha:1},12,cjs.Ease.quadInOut).to({scaleX:1,scaleY:1},5,cjs.Ease.quadInOut).wait(45).to({startPosition:0},0).to({alpha:0},13,cjs.Ease.quadInOut).wait(166).to({regX:-0.1,regY:-0.1,scaleX:0.6303,scaleY:0.6303,x:-53.55,y:-28.8},0).to({scaleX:0.8746,scaleY:0.8746,x:-53.6,y:-28.85,alpha:1},12,cjs.Ease.quadInOut).to({regX:0,regY:0,scaleX:0.8342,scaleY:0.8342,x:-53.5,y:-28.75},5,cjs.Ease.quadInOut).wait(104).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).to({_off:true},88).wait(5));

	// Mask3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_15 = new cjs.Graphics().p("AuhinIAAkeIdDAAIAAEeg");
	var mask_graphics_93 = new cjs.Graphics().p("AuhinIAAkeIdDAAIAAEeg");
	var mask_graphics_94 = new cjs.Graphics().p("AuhioIAAkeIdDAAIAAEeg");
	var mask_graphics_95 = new cjs.Graphics().p("AuhirIAAkeIdDAAIAAEeg");
	var mask_graphics_96 = new cjs.Graphics().p("AuhivIAAkfIdDAAIAAEfg");
	var mask_graphics_97 = new cjs.Graphics().p("Auhi2IAAkfIdDAAIAAEfg");
	var mask_graphics_98 = new cjs.Graphics().p("Auhi/IAAkeIdDAAIAAEeg");
	var mask_graphics_99 = new cjs.Graphics().p("AuhjJIAAkfIdDAAIAAEfg");
	var mask_graphics_100 = new cjs.Graphics().p("AuhjWIAAkeIdDAAIAAEeg");
	var mask_graphics_101 = new cjs.Graphics().p("AuhjkIAAkfIdDAAIAAEfg");
	var mask_graphics_102 = new cjs.Graphics().p("Auhj0IAAkfIdDAAIAAEfg");
	var mask_graphics_103 = new cjs.Graphics().p("AuhkHIAAkeIdDAAIAAEeg");
	var mask_graphics_104 = new cjs.Graphics().p("AuhkbIAAkeIdDAAIAAEeg");
	var mask_graphics_105 = new cjs.Graphics().p("AuhkxIAAkeIdDAAIAAEeg");
	var mask_graphics_106 = new cjs.Graphics().p("AuhlJIAAkeIdDAAIAAEeg");
	var mask_graphics_107 = new cjs.Graphics().p("AuhljIAAkeIdDAAIAAEeg");
	var mask_graphics_108 = new cjs.Graphics().p("Auhl9IAAkeIdDAAIAAEeg");
	var mask_graphics_109 = new cjs.Graphics().p("AuhmVIAAkeIdDAAIAAEeg");
	var mask_graphics_110 = new cjs.Graphics().p("AuhmrIAAkeIdDAAIAAEeg");
	var mask_graphics_111 = new cjs.Graphics().p("Auhm/IAAkeIdDAAIAAEeg");
	var mask_graphics_112 = new cjs.Graphics().p("AuhnRIAAkfIdDAAIAAEfg");
	var mask_graphics_113 = new cjs.Graphics().p("AuhnhIAAkfIdDAAIAAEfg");
	var mask_graphics_114 = new cjs.Graphics().p("AuhnwIAAkeIdDAAIAAEeg");
	var mask_graphics_115 = new cjs.Graphics().p("Auhn8IAAkfIdDAAIAAEfg");
	var mask_graphics_116 = new cjs.Graphics().p("AuhoHIAAkeIdDAAIAAEeg");
	var mask_graphics_117 = new cjs.Graphics().p("AuhoPIAAkfIdDAAIAAEfg");
	var mask_graphics_118 = new cjs.Graphics().p("AuhoWIAAkfIdDAAIAAEfg");
	var mask_graphics_119 = new cjs.Graphics().p("AuhobIAAkeIdDAAIAAEeg");
	var mask_graphics_120 = new cjs.Graphics().p("AuhoeIAAkeIdDAAIAAEeg");
	var mask_graphics_121 = new cjs.Graphics().p("AuhofIAAkeIdDAAIAAEeg");
	var mask_graphics_248 = new cjs.Graphics().p("AuhofIAAkeIdDAAIAAEeg");
	var mask_graphics_249 = new cjs.Graphics().p("AuhocIAAkeIdDAAIAAEeg");
	var mask_graphics_250 = new cjs.Graphics().p("AuhoUIAAkeIdDAAIAAEeg");
	var mask_graphics_251 = new cjs.Graphics().p("AuhoGIAAkeIdDAAIAAEeg");
	var mask_graphics_252 = new cjs.Graphics().p("AuhnzIAAkeIdDAAIAAEeg");
	var mask_graphics_253 = new cjs.Graphics().p("AuhnaIAAkeIdDAAIAAEeg");
	var mask_graphics_254 = new cjs.Graphics().p("Auhm8IAAkeIdDAAIAAEeg");
	var mask_graphics_255 = new cjs.Graphics().p("AuhmYIAAkeIdDAAIAAEeg");
	var mask_graphics_256 = new cjs.Graphics().p("AuhluIAAkfIdDAAIAAEfg");
	var mask_graphics_257 = new cjs.Graphics().p("AuhlBIAAkeIdDAAIAAEeg");
	var mask_graphics_258 = new cjs.Graphics().p("AuhkYIAAkeIdDAAIAAEeg");
	var mask_graphics_259 = new cjs.Graphics().p("Auhj0IAAkeIdDAAIAAEeg");
	var mask_graphics_260 = new cjs.Graphics().p("AuhjVIAAkfIdDAAIAAEfg");
	var mask_graphics_261 = new cjs.Graphics().p("Auhi9IAAkeIdDAAIAAEeg");
	var mask_graphics_262 = new cjs.Graphics().p("AuhipIAAkfIdDAAIAAEfg");
	var mask_graphics_263 = new cjs.Graphics().p("AuhicIAAkeIdDAAIAAEeg");
	var mask_graphics_264 = new cjs.Graphics().p("AuhiTIAAkfIdDAAIAAEfg");
	var mask_graphics_265 = new cjs.Graphics().p("AuhiRIAAkeIdDAAIAAEeg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(15).to({graphics:mask_graphics_15,x:-10.275,y:-45.425}).wait(78).to({graphics:mask_graphics_93,x:-10.275,y:-45.425}).wait(1).to({graphics:mask_graphics_94,x:-10.4372,y:-45.5209}).wait(1).to({graphics:mask_graphics_95,x:-10.924,y:-45.8087}).wait(1).to({graphics:mask_graphics_96,x:-11.7352,y:-46.2883}).wait(1).to({graphics:mask_graphics_97,x:-12.8709,y:-46.9597}).wait(1).to({graphics:mask_graphics_98,x:-14.3311,y:-47.823}).wait(1).to({graphics:mask_graphics_99,x:-16.1158,y:-48.8781}).wait(1).to({graphics:mask_graphics_100,x:-18.225,y:-50.125}).wait(1).to({graphics:mask_graphics_101,x:-20.6587,y:-51.5638}).wait(1).to({graphics:mask_graphics_102,x:-23.4168,y:-53.1944}).wait(1).to({graphics:mask_graphics_103,x:-26.4995,y:-55.0168}).wait(1).to({graphics:mask_graphics_104,x:-29.9066,y:-57.0311}).wait(1).to({graphics:mask_graphics_105,x:-33.6383,y:-59.2372}).wait(1).to({graphics:mask_graphics_106,x:-37.6944,y:-61.6352}).wait(1).to({graphics:mask_graphics_107,x:-42.075,y:-64.225}).wait(1).to({graphics:mask_graphics_108,x:-46.4556,y:-66.8148}).wait(1).to({graphics:mask_graphics_109,x:-50.5117,y:-69.2128}).wait(1).to({graphics:mask_graphics_110,x:-54.2434,y:-71.4189}).wait(1).to({graphics:mask_graphics_111,x:-57.6505,y:-73.4332}).wait(1).to({graphics:mask_graphics_112,x:-60.7332,y:-75.2556}).wait(1).to({graphics:mask_graphics_113,x:-63.4913,y:-76.8862}).wait(1).to({graphics:mask_graphics_114,x:-65.925,y:-78.325}).wait(1).to({graphics:mask_graphics_115,x:-68.0342,y:-79.5719}).wait(1).to({graphics:mask_graphics_116,x:-69.8189,y:-80.627}).wait(1).to({graphics:mask_graphics_117,x:-71.2791,y:-81.4903}).wait(1).to({graphics:mask_graphics_118,x:-72.4148,y:-82.1617}).wait(1).to({graphics:mask_graphics_119,x:-73.226,y:-82.6413}).wait(1).to({graphics:mask_graphics_120,x:-73.7128,y:-82.9291}).wait(1).to({graphics:mask_graphics_121,x:-73.875,y:-83.025}).wait(127).to({graphics:mask_graphics_248,x:-73.875,y:-83.025}).wait(1).to({graphics:mask_graphics_249,x:-73.3525,y:-82.7494}).wait(1).to({graphics:mask_graphics_250,x:-71.785,y:-81.9226}).wait(1).to({graphics:mask_graphics_251,x:-69.1726,y:-80.5446}).wait(1).to({graphics:mask_graphics_252,x:-65.5151,y:-78.6153}).wait(1).to({graphics:mask_graphics_253,x:-60.8127,y:-76.1349}).wait(1).to({graphics:mask_graphics_254,x:-55.0653,y:-73.1032}).wait(1).to({graphics:mask_graphics_255,x:-48.2729,y:-69.5203}).wait(1).to({graphics:mask_graphics_256,x:-40.4356,y:-65.3862}).wait(1).to({graphics:mask_graphics_257,x:-31.8144,y:-60.8388}).wait(1).to({graphics:mask_graphics_258,x:-23.9771,y:-56.7047}).wait(1).to({graphics:mask_graphics_259,x:-17.1847,y:-53.1218}).wait(1).to({graphics:mask_graphics_260,x:-11.4373,y:-50.0901}).wait(1).to({graphics:mask_graphics_261,x:-6.7349,y:-47.6097}).wait(1).to({graphics:mask_graphics_262,x:-3.0774,y:-45.6804}).wait(1).to({graphics:mask_graphics_263,x:-0.465,y:-44.3024}).wait(1).to({graphics:mask_graphics_264,x:1.1025,y:-43.4756}).wait(1).to({graphics:mask_graphics_265,x:1.625,y:-43.2}).wait(224));

	// HeadLine3
	this.instance_14 = new lib.Символ4("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(-11.9,-49.7);
	this.instance_14._off = true;

	var maskedShapeInstanceList = [this.instance_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(15).to({_off:false},0).to({y:-72.9},11,cjs.Ease.quadInOut).wait(67).to({startPosition:0},0).to({x:-75.5,y:-148.1},28,cjs.Ease.quadInOut).wait(127).to({startPosition:0},0).to({x:0,y:-68.45,alpha:0},17,cjs.Ease.quadInOut).to({_off:true},219).wait(5));

	// Mask2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_13 = new cjs.Graphics().p("Auhk5IAAkeIdDAAIAAEeg");
	var mask_1_graphics_93 = new cjs.Graphics().p("Auhk5IAAkeIdDAAIAAEeg");
	var mask_1_graphics_94 = new cjs.Graphics().p("Auhk6IAAkeIdDAAIAAEeg");
	var mask_1_graphics_95 = new cjs.Graphics().p("Auhk9IAAkeIdDAAIAAEeg");
	var mask_1_graphics_96 = new cjs.Graphics().p("AuhlBIAAkfIdDAAIAAEfg");
	var mask_1_graphics_97 = new cjs.Graphics().p("AuhlIIAAkfIdDAAIAAEfg");
	var mask_1_graphics_98 = new cjs.Graphics().p("AuhlRIAAkeIdDAAIAAEeg");
	var mask_1_graphics_99 = new cjs.Graphics().p("AuhlbIAAkfIdDAAIAAEfg");
	var mask_1_graphics_100 = new cjs.Graphics().p("AuhloIAAkeIdDAAIAAEeg");
	var mask_1_graphics_101 = new cjs.Graphics().p("Auhl2IAAkfIdDAAIAAEfg");
	var mask_1_graphics_102 = new cjs.Graphics().p("AuhmGIAAkfIdDAAIAAEfg");
	var mask_1_graphics_103 = new cjs.Graphics().p("AuhmZIAAkeIdDAAIAAEeg");
	var mask_1_graphics_104 = new cjs.Graphics().p("AuhmtIAAkeIdDAAIAAEeg");
	var mask_1_graphics_105 = new cjs.Graphics().p("AuhnDIAAkeIdDAAIAAEeg");
	var mask_1_graphics_106 = new cjs.Graphics().p("AuhnbIAAkeIdDAAIAAEeg");
	var mask_1_graphics_107 = new cjs.Graphics().p("Auhn1IAAkeIdDAAIAAEeg");
	var mask_1_graphics_108 = new cjs.Graphics().p("AuhoPIAAkeIdDAAIAAEeg");
	var mask_1_graphics_109 = new cjs.Graphics().p("AuhonIAAkeIdDAAIAAEeg");
	var mask_1_graphics_110 = new cjs.Graphics().p("Auho9IAAkeIdDAAIAAEeg");
	var mask_1_graphics_111 = new cjs.Graphics().p("AuhpRIAAkeIdDAAIAAEeg");
	var mask_1_graphics_112 = new cjs.Graphics().p("AuhpjIAAkfIdDAAIAAEfg");
	var mask_1_graphics_113 = new cjs.Graphics().p("AuhpzIAAkfIdDAAIAAEfg");
	var mask_1_graphics_114 = new cjs.Graphics().p("AuhqCIAAkeIdDAAIAAEeg");
	var mask_1_graphics_115 = new cjs.Graphics().p("AuhqOIAAkfIdDAAIAAEfg");
	var mask_1_graphics_116 = new cjs.Graphics().p("AuhqZIAAkeIdDAAIAAEeg");
	var mask_1_graphics_117 = new cjs.Graphics().p("AuhqhIAAkfIdDAAIAAEfg");
	var mask_1_graphics_118 = new cjs.Graphics().p("AuhqoIAAkfIdDAAIAAEfg");
	var mask_1_graphics_119 = new cjs.Graphics().p("AuhqtIAAkeIdDAAIAAEeg");
	var mask_1_graphics_120 = new cjs.Graphics().p("AuhqwIAAkeIdDAAIAAEeg");
	var mask_1_graphics_121 = new cjs.Graphics().p("AuhqxIAAkeIdDAAIAAEeg");
	var mask_1_graphics_248 = new cjs.Graphics().p("AuhqxIAAkeIdDAAIAAEeg");
	var mask_1_graphics_249 = new cjs.Graphics().p("AuhquIAAkeIdDAAIAAEeg");
	var mask_1_graphics_250 = new cjs.Graphics().p("AuhqmIAAkeIdDAAIAAEeg");
	var mask_1_graphics_251 = new cjs.Graphics().p("AuhqYIAAkeIdDAAIAAEeg");
	var mask_1_graphics_252 = new cjs.Graphics().p("AuhqFIAAkeIdDAAIAAEeg");
	var mask_1_graphics_253 = new cjs.Graphics().p("AuhpsIAAkeIdDAAIAAEeg");
	var mask_1_graphics_254 = new cjs.Graphics().p("AuhpOIAAkeIdDAAIAAEeg");
	var mask_1_graphics_255 = new cjs.Graphics().p("AuhoqIAAkeIdDAAIAAEeg");
	var mask_1_graphics_256 = new cjs.Graphics().p("AuhoAIAAkfIdDAAIAAEfg");
	var mask_1_graphics_257 = new cjs.Graphics().p("AuhnTIAAkeIdDAAIAAEeg");
	var mask_1_graphics_258 = new cjs.Graphics().p("AuhmqIAAkeIdDAAIAAEeg");
	var mask_1_graphics_259 = new cjs.Graphics().p("AuhmGIAAkeIdDAAIAAEeg");
	var mask_1_graphics_260 = new cjs.Graphics().p("AuhlnIAAkfIdDAAIAAEfg");
	var mask_1_graphics_261 = new cjs.Graphics().p("AuhlPIAAkeIdDAAIAAEeg");
	var mask_1_graphics_262 = new cjs.Graphics().p("Auhk7IAAkfIdDAAIAAEfg");
	var mask_1_graphics_263 = new cjs.Graphics().p("AuhkuIAAkeIdDAAIAAEeg");
	var mask_1_graphics_264 = new cjs.Graphics().p("AuhklIAAkfIdDAAIAAEfg");
	var mask_1_graphics_265 = new cjs.Graphics().p("AuhkiIAAkfIdDAAIAAEfg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(13).to({graphics:mask_1_graphics_13,x:-10.275,y:-60.025}).wait(80).to({graphics:mask_1_graphics_93,x:-10.275,y:-60.025}).wait(1).to({graphics:mask_1_graphics_94,x:-10.4372,y:-60.1209}).wait(1).to({graphics:mask_1_graphics_95,x:-10.924,y:-60.4087}).wait(1).to({graphics:mask_1_graphics_96,x:-11.7352,y:-60.8883}).wait(1).to({graphics:mask_1_graphics_97,x:-12.8709,y:-61.5597}).wait(1).to({graphics:mask_1_graphics_98,x:-14.3311,y:-62.423}).wait(1).to({graphics:mask_1_graphics_99,x:-16.1158,y:-63.4781}).wait(1).to({graphics:mask_1_graphics_100,x:-18.225,y:-64.725}).wait(1).to({graphics:mask_1_graphics_101,x:-20.6587,y:-66.1638}).wait(1).to({graphics:mask_1_graphics_102,x:-23.4168,y:-67.7944}).wait(1).to({graphics:mask_1_graphics_103,x:-26.4995,y:-69.6168}).wait(1).to({graphics:mask_1_graphics_104,x:-29.9066,y:-71.6311}).wait(1).to({graphics:mask_1_graphics_105,x:-33.6383,y:-73.8372}).wait(1).to({graphics:mask_1_graphics_106,x:-37.6944,y:-76.2352}).wait(1).to({graphics:mask_1_graphics_107,x:-42.075,y:-78.825}).wait(1).to({graphics:mask_1_graphics_108,x:-46.4556,y:-81.4148}).wait(1).to({graphics:mask_1_graphics_109,x:-50.5117,y:-83.8128}).wait(1).to({graphics:mask_1_graphics_110,x:-54.2434,y:-86.0189}).wait(1).to({graphics:mask_1_graphics_111,x:-57.6505,y:-88.0332}).wait(1).to({graphics:mask_1_graphics_112,x:-60.7332,y:-89.8556}).wait(1).to({graphics:mask_1_graphics_113,x:-63.4913,y:-91.4862}).wait(1).to({graphics:mask_1_graphics_114,x:-65.925,y:-92.925}).wait(1).to({graphics:mask_1_graphics_115,x:-68.0342,y:-94.1719}).wait(1).to({graphics:mask_1_graphics_116,x:-69.8189,y:-95.227}).wait(1).to({graphics:mask_1_graphics_117,x:-71.2791,y:-96.0903}).wait(1).to({graphics:mask_1_graphics_118,x:-72.4148,y:-96.7617}).wait(1).to({graphics:mask_1_graphics_119,x:-73.226,y:-97.2413}).wait(1).to({graphics:mask_1_graphics_120,x:-73.7128,y:-97.5291}).wait(1).to({graphics:mask_1_graphics_121,x:-73.875,y:-97.625}).wait(127).to({graphics:mask_1_graphics_248,x:-73.875,y:-97.625}).wait(1).to({graphics:mask_1_graphics_249,x:-73.3525,y:-97.3494}).wait(1).to({graphics:mask_1_graphics_250,x:-71.785,y:-96.5226}).wait(1).to({graphics:mask_1_graphics_251,x:-69.1726,y:-95.1446}).wait(1).to({graphics:mask_1_graphics_252,x:-65.5151,y:-93.2153}).wait(1).to({graphics:mask_1_graphics_253,x:-60.8127,y:-90.7349}).wait(1).to({graphics:mask_1_graphics_254,x:-55.0653,y:-87.7032}).wait(1).to({graphics:mask_1_graphics_255,x:-48.2729,y:-84.1203}).wait(1).to({graphics:mask_1_graphics_256,x:-40.4356,y:-79.9862}).wait(1).to({graphics:mask_1_graphics_257,x:-31.8144,y:-75.4388}).wait(1).to({graphics:mask_1_graphics_258,x:-23.9771,y:-71.3047}).wait(1).to({graphics:mask_1_graphics_259,x:-17.1847,y:-67.7218}).wait(1).to({graphics:mask_1_graphics_260,x:-11.4373,y:-64.6901}).wait(1).to({graphics:mask_1_graphics_261,x:-6.7349,y:-62.2097}).wait(1).to({graphics:mask_1_graphics_262,x:-3.0774,y:-60.2804}).wait(1).to({graphics:mask_1_graphics_263,x:-0.465,y:-58.9024}).wait(1).to({graphics:mask_1_graphics_264,x:1.1025,y:-58.0756}).wait(1).to({graphics:mask_1_graphics_265,x:1.625,y:-57.8}).wait(224));

	// HeadLine2
	this.instance_15 = new lib.Символ3("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(-11.9,-78.7);
	this.instance_15._off = true;

	var maskedShapeInstanceList = [this.instance_15];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(13).to({_off:false},0).to({y:-102.7},11,cjs.Ease.quadInOut).wait(69).to({startPosition:0},0).to({x:-75.5,y:-177.9},28,cjs.Ease.quadInOut).wait(127).to({startPosition:0},0).to({x:0,y:-98.25,alpha:0},17,cjs.Ease.quadInOut).to({_off:true},219).wait(5));

	// Mask1 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_11 = new cjs.Graphics().p("Auhm9IAAkeIdDAAIAAEeg");
	var mask_2_graphics_93 = new cjs.Graphics().p("Auhm9IAAkeIdDAAIAAEeg");
	var mask_2_graphics_94 = new cjs.Graphics().p("Auhm+IAAkeIdDAAIAAEeg");
	var mask_2_graphics_95 = new cjs.Graphics().p("AuhnBIAAkeIdDAAIAAEeg");
	var mask_2_graphics_96 = new cjs.Graphics().p("AuhnFIAAkfIdDAAIAAEfg");
	var mask_2_graphics_97 = new cjs.Graphics().p("AuhnMIAAkfIdDAAIAAEfg");
	var mask_2_graphics_98 = new cjs.Graphics().p("AuhnVIAAkeIdDAAIAAEeg");
	var mask_2_graphics_99 = new cjs.Graphics().p("AuhnfIAAkfIdDAAIAAEfg");
	var mask_2_graphics_100 = new cjs.Graphics().p("AuhnsIAAkeIdDAAIAAEeg");
	var mask_2_graphics_101 = new cjs.Graphics().p("Auhn6IAAkfIdDAAIAAEfg");
	var mask_2_graphics_102 = new cjs.Graphics().p("AuhoKIAAkfIdDAAIAAEfg");
	var mask_2_graphics_103 = new cjs.Graphics().p("AuhodIAAkeIdDAAIAAEeg");
	var mask_2_graphics_104 = new cjs.Graphics().p("AuhoxIAAkeIdDAAIAAEeg");
	var mask_2_graphics_105 = new cjs.Graphics().p("AuhpHIAAkeIdDAAIAAEeg");
	var mask_2_graphics_106 = new cjs.Graphics().p("AuhpfIAAkeIdDAAIAAEeg");
	var mask_2_graphics_107 = new cjs.Graphics().p("Auhp5IAAkeIdDAAIAAEeg");
	var mask_2_graphics_108 = new cjs.Graphics().p("AuhqTIAAkeIdDAAIAAEeg");
	var mask_2_graphics_109 = new cjs.Graphics().p("AuhqrIAAkeIdDAAIAAEeg");
	var mask_2_graphics_110 = new cjs.Graphics().p("AuhrBIAAkeIdDAAIAAEeg");
	var mask_2_graphics_111 = new cjs.Graphics().p("AuhrVIAAkeIdDAAIAAEeg");
	var mask_2_graphics_112 = new cjs.Graphics().p("AuhrnIAAkfIdDAAIAAEfg");
	var mask_2_graphics_113 = new cjs.Graphics().p("Auhr3IAAkfIdDAAIAAEfg");
	var mask_2_graphics_114 = new cjs.Graphics().p("AuhsGIAAkeIdDAAIAAEeg");
	var mask_2_graphics_115 = new cjs.Graphics().p("AuhsSIAAkfIdDAAIAAEfg");
	var mask_2_graphics_116 = new cjs.Graphics().p("AuhsdIAAkeIdDAAIAAEeg");
	var mask_2_graphics_117 = new cjs.Graphics().p("AuhslIAAkfIdDAAIAAEfg");
	var mask_2_graphics_118 = new cjs.Graphics().p("AuhssIAAkfIdDAAIAAEfg");
	var mask_2_graphics_119 = new cjs.Graphics().p("AuhsxIAAkeIdDAAIAAEeg");
	var mask_2_graphics_120 = new cjs.Graphics().p("Auhs0IAAkeIdDAAIAAEeg");
	var mask_2_graphics_121 = new cjs.Graphics().p("Auhs1IAAkeIdDAAIAAEeg");
	var mask_2_graphics_248 = new cjs.Graphics().p("Auhs1IAAkeIdDAAIAAEeg");
	var mask_2_graphics_249 = new cjs.Graphics().p("AuhsyIAAkeIdDAAIAAEeg");
	var mask_2_graphics_250 = new cjs.Graphics().p("AuhsqIAAkeIdDAAIAAEeg");
	var mask_2_graphics_251 = new cjs.Graphics().p("AuhscIAAkeIdDAAIAAEeg");
	var mask_2_graphics_252 = new cjs.Graphics().p("AuhsJIAAkeIdDAAIAAEeg");
	var mask_2_graphics_253 = new cjs.Graphics().p("AuhrwIAAkeIdDAAIAAEeg");
	var mask_2_graphics_254 = new cjs.Graphics().p("AuhrSIAAkeIdDAAIAAEeg");
	var mask_2_graphics_255 = new cjs.Graphics().p("AuhquIAAkeIdDAAIAAEeg");
	var mask_2_graphics_256 = new cjs.Graphics().p("AuhqEIAAkfIdDAAIAAEfg");
	var mask_2_graphics_257 = new cjs.Graphics().p("AuhpXIAAkeIdDAAIAAEeg");
	var mask_2_graphics_258 = new cjs.Graphics().p("AuhouIAAkeIdDAAIAAEeg");
	var mask_2_graphics_259 = new cjs.Graphics().p("AuhoKIAAkeIdDAAIAAEeg");
	var mask_2_graphics_260 = new cjs.Graphics().p("AuhnrIAAkfIdDAAIAAEfg");
	var mask_2_graphics_261 = new cjs.Graphics().p("AuhnTIAAkeIdDAAIAAEeg");
	var mask_2_graphics_262 = new cjs.Graphics().p("Auhm/IAAkfIdDAAIAAEfg");
	var mask_2_graphics_263 = new cjs.Graphics().p("AuhmyIAAkeIdDAAIAAEeg");
	var mask_2_graphics_264 = new cjs.Graphics().p("AuhmpIAAkfIdDAAIAAEfg");
	var mask_2_graphics_265 = new cjs.Graphics().p("AuhmmIAAkfIdDAAIAAEfg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(11).to({graphics:mask_2_graphics_11,x:-10.275,y:-73.225}).wait(82).to({graphics:mask_2_graphics_93,x:-10.275,y:-73.225}).wait(1).to({graphics:mask_2_graphics_94,x:-10.4372,y:-73.3209}).wait(1).to({graphics:mask_2_graphics_95,x:-10.924,y:-73.6087}).wait(1).to({graphics:mask_2_graphics_96,x:-11.7352,y:-74.0883}).wait(1).to({graphics:mask_2_graphics_97,x:-12.8709,y:-74.7597}).wait(1).to({graphics:mask_2_graphics_98,x:-14.3311,y:-75.623}).wait(1).to({graphics:mask_2_graphics_99,x:-16.1158,y:-76.6781}).wait(1).to({graphics:mask_2_graphics_100,x:-18.225,y:-77.925}).wait(1).to({graphics:mask_2_graphics_101,x:-20.6587,y:-79.3638}).wait(1).to({graphics:mask_2_graphics_102,x:-23.4168,y:-80.9944}).wait(1).to({graphics:mask_2_graphics_103,x:-26.4995,y:-82.8168}).wait(1).to({graphics:mask_2_graphics_104,x:-29.9066,y:-84.8311}).wait(1).to({graphics:mask_2_graphics_105,x:-33.6383,y:-87.0372}).wait(1).to({graphics:mask_2_graphics_106,x:-37.6944,y:-89.4352}).wait(1).to({graphics:mask_2_graphics_107,x:-42.075,y:-92.025}).wait(1).to({graphics:mask_2_graphics_108,x:-46.4556,y:-94.6148}).wait(1).to({graphics:mask_2_graphics_109,x:-50.5117,y:-97.0128}).wait(1).to({graphics:mask_2_graphics_110,x:-54.2434,y:-99.2189}).wait(1).to({graphics:mask_2_graphics_111,x:-57.6505,y:-101.2332}).wait(1).to({graphics:mask_2_graphics_112,x:-60.7332,y:-103.0556}).wait(1).to({graphics:mask_2_graphics_113,x:-63.4913,y:-104.6862}).wait(1).to({graphics:mask_2_graphics_114,x:-65.925,y:-106.125}).wait(1).to({graphics:mask_2_graphics_115,x:-68.0342,y:-107.3719}).wait(1).to({graphics:mask_2_graphics_116,x:-69.8189,y:-108.427}).wait(1).to({graphics:mask_2_graphics_117,x:-71.2791,y:-109.2903}).wait(1).to({graphics:mask_2_graphics_118,x:-72.4148,y:-109.9617}).wait(1).to({graphics:mask_2_graphics_119,x:-73.226,y:-110.4413}).wait(1).to({graphics:mask_2_graphics_120,x:-73.7128,y:-110.7291}).wait(1).to({graphics:mask_2_graphics_121,x:-73.875,y:-110.825}).wait(127).to({graphics:mask_2_graphics_248,x:-73.875,y:-110.825}).wait(1).to({graphics:mask_2_graphics_249,x:-73.3525,y:-110.5494}).wait(1).to({graphics:mask_2_graphics_250,x:-71.785,y:-109.7226}).wait(1).to({graphics:mask_2_graphics_251,x:-69.1726,y:-108.3446}).wait(1).to({graphics:mask_2_graphics_252,x:-65.5151,y:-106.4153}).wait(1).to({graphics:mask_2_graphics_253,x:-60.8127,y:-103.9349}).wait(1).to({graphics:mask_2_graphics_254,x:-55.0653,y:-100.9032}).wait(1).to({graphics:mask_2_graphics_255,x:-48.2729,y:-97.3203}).wait(1).to({graphics:mask_2_graphics_256,x:-40.4356,y:-93.1862}).wait(1).to({graphics:mask_2_graphics_257,x:-31.8144,y:-88.6388}).wait(1).to({graphics:mask_2_graphics_258,x:-23.9771,y:-84.5047}).wait(1).to({graphics:mask_2_graphics_259,x:-17.1847,y:-80.9218}).wait(1).to({graphics:mask_2_graphics_260,x:-11.4373,y:-77.8901}).wait(1).to({graphics:mask_2_graphics_261,x:-6.7349,y:-75.4097}).wait(1).to({graphics:mask_2_graphics_262,x:-3.0774,y:-73.4804}).wait(1).to({graphics:mask_2_graphics_263,x:-0.465,y:-72.1024}).wait(1).to({graphics:mask_2_graphics_264,x:1.1025,y:-71.2756}).wait(1).to({graphics:mask_2_graphics_265,x:1.625,y:-71}).wait(224));

	// HeadLine1
	this.instance_16 = new lib.Символ5("synched",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(-11.9,-105.5);
	this.instance_16._off = true;

	var maskedShapeInstanceList = [this.instance_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(11).to({_off:false},0).to({y:-132.7},11,cjs.Ease.quadInOut).wait(71).to({startPosition:0},0).to({x:-75.5,y:-207.9},28,cjs.Ease.quadInOut).wait(127).to({startPosition:0},0).to({x:0,y:-128.25,alpha:0},17,cjs.Ease.quadInOut).to({_off:true},219).wait(5));

	// SubLogo
	this.instance_17 = new lib.Символ27("synched",0);
	this.instance_17.parent = this;
	this.instance_17.setTransform(68.1,-11.1,0.7924,0.7924);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(394).to({_off:false},0).to({regY:-0.2,scaleX:2.0869,scaleY:2.0869,x:-0.05,y:-61.3,alpha:1},22,cjs.Ease.quadInOut).to({_off:true},72).wait(1));

	// Logo
	this.instance_18 = new lib.Символ8("synched",0);
	this.instance_18.parent = this;
	this.instance_18.setTransform(98.4,-19.65,0.8146,0.8146,0,0,0,35.1,12.2);
	this.instance_18.alpha = 0;
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(13).to({_off:false},0).to({scaleX:1.0609,scaleY:1.0609,x:98.45,y:-19.6,alpha:1},12,cjs.Ease.quadInOut).to({regY:12.1,scaleX:1,scaleY:1,x:98.4,y:-19.75},5,cjs.Ease.quadInOut).wait(63).to({startPosition:0},0).to({x:344.6,y:43.5},28,cjs.Ease.quadInOut).wait(127).to({startPosition:0},0).to({scaleX:0.8613,scaleY:0.8613,x:99.9,y:-18},17,cjs.Ease.quadInOut).wait(129).to({startPosition:0},0).to({regX:34.8,regY:12,scaleX:2.0971,scaleY:2.0971,x:72.9,y:-77.8},22,cjs.Ease.quadInOut).to({_off:true},72).wait(1));

	// Black
	this.instance_19 = new lib.Символ2("synched",0);
	this.instance_19.parent = this;
	this.instance_19.setTransform(0,-104.5,1,0.0613);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).to({regY:0.2,scaleY:0.755,y:-80.55},15,cjs.Ease.quadInOut).wait(74).to({startPosition:0},0).to({regY:-0.1,scaleX:2.444,scaleY:1.4897,x:90,y:-87.5},28,cjs.Ease.quadInOut).wait(127).to({startPosition:0},0).to({regY:0.2,scaleX:1,scaleY:0.755,x:0,y:-80.55},17,cjs.Ease.quadInOut).wait(129).to({startPosition:0},0).to({regY:-0.6,scaleX:4.8707,scaleY:3.1086,x:0.05,y:-87.35},22,cjs.Ease.quadInOut).to({_off:true},72).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-534.2,-388.9,1068.6,605.4);


(lib.visualкопия2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// boss_2
	this.instance = new lib.boss_2копия2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(984.4,1264.45,1.039,1.039,0,0,0,960,1279.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(284).to({_off:false},0).wait(378));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.6,-108,1200.6999999999998,888);


(lib.visual = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// boss_2
	this.instance = new lib.boss_2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(984.4,1264.45,1.039,1.039,0,0,0,960,1279.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(284).to({_off:false},0).wait(378));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.1,-107.7,1399.3,887.7);


// stage content:
(lib.Tele2_Flight8_640x360 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// white_2
	this.instance = new lib.Символ28("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(488.1,643.3,3.5473,3.2274,0,0,0,0.3,0.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(462).to({_off:false},0).to({regX:0.1,scaleX:5.4987,scaleY:32.0632,x:506.05,y:519.55,alpha:1},14,cjs.Ease.quadInOut).wait(1));

	// Plashka
	this.instance_1 = new lib.Символ1копия3("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(772.05,667.4,1.1326,1.1326,4.9983,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:1,regY:0.7,scaleX:1.1525,scaleY:1.1525,rotation:4.9987,x:757.9,y:494.1,startPosition:17},17,cjs.Ease.quadInOut).to({scaleX:1.1522,scaleY:1.1522,rotation:5.0001,startPosition:93},76,cjs.Ease.quadInOut).to({regX:0.7,regY:0.5,scaleX:1.11,scaleY:1.11,rotation:0,x:501.4,y:436.45,startPosition:121},28,cjs.Ease.quadInOut).to({regX:0.9,x:501.8,y:436.2,startPosition:248},127).to({regY:0.8,scaleX:1.1525,scaleY:1.1525,rotation:5.0002,x:759.3,y:494.65,startPosition:265},17,cjs.Ease.quadInOut).to({regX:0.8,regY:0.7,rotation:4.9987,x:759.25,y:494.7,startPosition:394},129,cjs.Ease.quadInOut).to({regY:0.6,scaleX:1.1325,scaleY:1.1325,rotation:0,x:600.6,y:435.15,startPosition:412},18,cjs.Ease.quadInOut).wait(65));

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","#FFFFFF"],[0,1],-8.5,1.1,30.4,1.1).s().p("EgGFA4RMAAAhwgIMLAAMAAABwgg");
	this.shape.setTransform(1166.65,333.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(477));

	// Gil_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EhYQBhHMhBsgP6ME7XisSMARtDMcg");
	var mask_graphics_1 = new cjs.Graphics().p("EhYQBg6MhBngP7ME7Cir9MARnDMMg");
	var mask_graphics_2 = new cjs.Graphics().p("EhY7BgpMhBngP6ME7Dir9MARmDMMg");
	var mask_graphics_3 = new cjs.Graphics().p("EhaBBgOMhBngP7ME7Cir9MARnDMMg");
	var mask_graphics_4 = new cjs.Graphics().p("EhbkBfoMhBngP7ME7Cir9MARnDMMg");
	var mask_graphics_5 = new cjs.Graphics().p("EhdjBe2MhBngP6ME7Cir9MARnDMMg");
	var mask_graphics_6 = new cjs.Graphics().p("Ehf+Bd6MhBngP7ME7Cir9MARnDMMg");
	var mask_graphics_7 = new cjs.Graphics().p("Ehi2BczMhBngP7ME7Dir9MARmDMMg");
	var mask_graphics_8 = new cjs.Graphics().p("EhktBbhMhBngP7ME7Cir9MARnDMMg");
	var mask_graphics_9 = new cjs.Graphics().p("EhktBaDMhBngP6ME7Cir9MARnDMMg");
	var mask_graphics_10 = new cjs.Graphics().p("EhktBYbMhBngP6ME7Cir9MARnDMMg");
	var mask_graphics_11 = new cjs.Graphics().p("EhktBWoMhBngP6ME7Cir9MARnDMMg");
	var mask_graphics_12 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_13 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_14 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_15 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_16 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_17 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_18 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_19 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_20 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_21 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_22 = new cjs.Graphics().p("Ehk1BV/MhBtgP7ME7YisRMARtDMbg");
	var mask_graphics_23 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_24 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_25 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_26 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_27 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_28 = new cjs.Graphics().p("EhktBVyMhBngP7ME7Cir8MARnDMLg");
	var mask_graphics_29 = new cjs.Graphics().p("Ehk1BV/MhBtgP7ME7YisRMARtDMbg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:1146.3782,y:725.4673}).wait(1).to({graphics:mask_graphics_1,x:1144.1612,y:724.6137}).wait(1).to({graphics:mask_graphics_2,x:1139.9112,y:722.9637}).wait(1).to({graphics:mask_graphics_3,x:1132.8612,y:720.2387}).wait(1).to({graphics:mask_graphics_4,x:1122.9862,y:716.3887}).wait(1).to({graphics:mask_graphics_5,x:1110.2862,y:711.4637}).wait(1).to({graphics:mask_graphics_6,x:1094.7612,y:705.4387}).wait(1).to({graphics:mask_graphics_7,x:1076.4112,y:698.3137}).wait(1).to({graphics:mask_graphics_8,x:1045.9744,y:690.0887}).wait(1).to({graphics:mask_graphics_9,x:998.0244,y:680.7637}).wait(1).to({graphics:mask_graphics_10,x:944.3744,y:670.3637}).wait(1).to({graphics:mask_graphics_11,x:885.1244,y:658.8637}).wait(1).to({graphics:mask_graphics_12,x:825.8244,y:641.2306}).wait(1).to({graphics:mask_graphics_13,x:772.2244,y:620.4306}).wait(1).to({graphics:mask_graphics_14,x:724.2244,y:601.7806}).wait(1).to({graphics:mask_graphics_15,x:681.8744,y:585.3306}).wait(1).to({graphics:mask_graphics_16,x:645.1744,y:571.0806}).wait(1).to({graphics:mask_graphics_17,x:614.1244,y:559.0306}).wait(1).to({graphics:mask_graphics_18,x:588.7244,y:549.1806}).wait(1).to({graphics:mask_graphics_19,x:568.9744,y:541.4806}).wait(1).to({graphics:mask_graphics_20,x:554.8744,y:536.0306}).wait(1).to({graphics:mask_graphics_21,x:546.3744,y:532.7306}).wait(1).to({graphics:mask_graphics_22,x:543.8455,y:531.4437}).wait(1).to({graphics:mask_graphics_23,x:544.4244,y:531.9806}).wait(1).to({graphics:mask_graphics_24,x:546.8244,y:532.9306}).wait(1).to({graphics:mask_graphics_25,x:550.7744,y:534.5306}).wait(1).to({graphics:mask_graphics_26,x:555.9744,y:536.6306}).wait(1).to({graphics:mask_graphics_27,x:559.9244,y:538.2306}).wait(1).to({graphics:mask_graphics_28,x:562.3244,y:539.1806}).wait(1).to({graphics:mask_graphics_29,x:563.3455,y:539.2437}).wait(448));

	// purple
	this.instance_2 = new lib.Символ34("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(482.25,446.2,1.7648,1.44);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({alpha:0},18,cjs.Ease.quadInOut).wait(84).to({startPosition:0},0).to({alpha:1},15,cjs.Ease.quadInOut).wait(137).to({startPosition:0},0).to({alpha:0},12,cjs.Ease.quadInOut).to({_off:true},182).wait(29));

	// vis___копия
	this.instance_3 = new lib.visualкопия2("synched",283);
	this.instance_3.parent = this;
	this.instance_3.setTransform(380.5,515.6,0.942,0.942,0,0,0,419.3,478.7);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(231).to({_off:false},0).to({regX:419.2,scaleX:0.9626,scaleY:0.9626,x:380.45,y:515.65,startPosition:451},168,cjs.Ease.none).to({_off:true},49).wait(29));

	// Ded_1___копия
	this.instance_4 = new lib.Символ30копия("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(579.9,453.35,1.935,1.935,0,0,0,0.2,0.5);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({regX:0.5,scaleX:1.9734,scaleY:1.9734,x:580.5,y:453.4},126,cjs.Ease.quadInOut).to({_off:true},1).wait(350));

	// Gil_3
	this.Gill = new lib.Символ33();
	this.Gill.name = "Gill";
	this.Gill.parent = this;
	this.Gill.setTransform(1206.55,654.15,1.7999,1.7999,65.9306,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.Gill).to({x:523.5,y:388.9},22,cjs.Ease.quadInOut).to({x:543,y:396.7},7,cjs.Ease.quadInOut).to({_off:true},419).wait(29));

	// white
	this.instance_5 = new lib.Символ29("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(492.95,527.75,1.8,1.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:495.95,alpha:0},18,cjs.Ease.quadInOut).wait(84).to({startPosition:0},0).to({x:492.95,alpha:1},15,cjs.Ease.quadInOut).wait(137).to({startPosition:0},0).to({x:495.95,alpha:0},12,cjs.Ease.quadInOut).to({_off:true},182).wait(29));

	// six
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("AgOA8IAAgvIgpAAIAAgdIApAAIAAgrIAdAAIAAArIApAAIAAAdIgpAAIAAAvg");
	this.shape_1.setTransform(321.375,188.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#999999").s().p("AgvBOQgSgWAAgtQAAg1AQgbQAQgdAkAAQAbAAAQAPQARAPAAAbIglAAQgBgYgYAAQgcAAgBA4IADAAQAMgQAVAAQAbAAAQARQAPAQAAAcQAAAdgRARQgSARgfAAQgeAAgRgVgAgTANQgGAIgBAQQABANAGAJQAIAJALAAQANAAAGgIQAIgJAAgPQAAgPgIgIQgGgIgNAAQgLAAgIAIg");
	this.shape_2.setTransform(306.7,188.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[]},130).to({state:[]},318).wait(29));

	// vis
	this.instance_6 = new lib.visual("synched",283);
	this.instance_6.parent = this;
	this.instance_6.setTransform(380.5,515.6,0.942,0.942,0,0,0,419.3,478.7);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(231).to({_off:false},0).to({regX:419.2,scaleX:0.9626,scaleY:0.9626,x:380.45,y:515.65,startPosition:451},168,cjs.Ease.none).to({_off:true},49).wait(29));

	// Ded_1
	this.instance_7 = new lib.Символ30копия4("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(579.9,453.35,1.935,1.935,0,0,0,0.2,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1).to({regX:4.2,regY:-79.2,x:587.65,y:299.15},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({scaleX:1.9351,scaleY:1.9351},0).wait(1).to({startPosition:0},0).wait(1).to({scaleX:1.9352,scaleY:1.9352},0).wait(1).to({scaleX:1.9353,scaleY:1.9353},0).wait(1).to({scaleX:1.9354,scaleY:1.9354,y:299.1},0).wait(1).to({startPosition:0},0).wait(1).to({scaleX:1.9355,scaleY:1.9355},0).wait(1).to({scaleX:1.9356,scaleY:1.9356},0).wait(1).to({scaleX:1.9357,scaleY:1.9357},0).wait(1).to({scaleX:1.9359,scaleY:1.9359},0).wait(1).to({scaleX:1.936,scaleY:1.936,y:299.05},0).wait(1).to({scaleX:1.9361,scaleY:1.9361},0).wait(1).to({scaleX:1.9363,scaleY:1.9363},0).wait(1).to({scaleX:1.9364,scaleY:1.9364},0).wait(1).to({scaleX:1.9366,scaleY:1.9366,y:299},0).wait(1).to({scaleX:1.9368,scaleY:1.9368},0).wait(1).to({scaleX:1.937,scaleY:1.937},0).wait(1).to({scaleX:1.9372,scaleY:1.9372},0).wait(1).to({scaleX:1.9374,scaleY:1.9374,y:298.95},0).wait(1).to({scaleX:1.9376,scaleY:1.9376},0).wait(1).to({scaleX:1.9378,scaleY:1.9378,y:298.9},0).wait(1).to({scaleX:1.9381,scaleY:1.9381},0).wait(1).to({scaleX:1.9383,scaleY:1.9383},0).wait(1).to({scaleX:1.9386,scaleY:1.9386,y:298.85},0).wait(1).to({scaleX:1.9388,scaleY:1.9388},0).wait(1).to({scaleX:1.9391,scaleY:1.9391,x:587.7,y:298.8},0).wait(1).to({scaleX:1.9394,scaleY:1.9394},0).wait(1).to({scaleX:1.9397,scaleY:1.9397,y:298.75},0).wait(1).to({scaleX:1.94,scaleY:1.94},0).wait(1).to({scaleX:1.9404,scaleY:1.9404,y:298.7},0).wait(1).to({scaleX:1.9407,scaleY:1.9407},0).wait(1).to({scaleX:1.9411,scaleY:1.9411,y:298.65},0).wait(1).to({scaleX:1.9414,scaleY:1.9414},0).wait(1).to({scaleX:1.9418,scaleY:1.9418,y:298.6},0).wait(1).to({scaleX:1.9422,scaleY:1.9422},0).wait(1).to({scaleX:1.9426,scaleY:1.9426,y:298.55},0).wait(1).to({scaleX:1.943,scaleY:1.943,y:298.5},0).wait(1).to({scaleX:1.9434,scaleY:1.9434,x:587.75},0).wait(1).to({scaleX:1.9438,scaleY:1.9438,y:298.45},0).wait(1).to({scaleX:1.9443,scaleY:1.9443,y:298.4},0).wait(1).to({scaleX:1.9447,scaleY:1.9447},0).wait(1).to({scaleX:1.9452,scaleY:1.9452,y:298.35},0).wait(1).to({scaleX:1.9457,scaleY:1.9457,y:298.3},0).wait(1).to({scaleX:1.9461,scaleY:1.9461,y:298.25},0).wait(1).to({scaleX:1.9466,scaleY:1.9466,x:587.8},0).wait(1).to({scaleX:1.9471,scaleY:1.9471,y:298.2},0).wait(1).to({scaleX:1.9476,scaleY:1.9476,x:587.85,y:298.15},0).wait(1).to({scaleX:1.9481,scaleY:1.9481,y:298.1},0).wait(1).to({scaleX:1.9487,scaleY:1.9487,y:298.05},0).wait(1).to({scaleX:1.9492,scaleY:1.9492},0).wait(1).to({scaleX:1.9497,scaleY:1.9497,y:298},0).wait(1).to({scaleX:1.9502,scaleY:1.9502,y:297.95},0).wait(1).to({scaleX:1.9508,scaleY:1.9508,y:297.9},0).wait(1).to({scaleX:1.9513,scaleY:1.9513,y:297.85},0).wait(1).to({scaleX:1.9519,scaleY:1.9519,x:587.9,y:297.8},0).wait(1).to({scaleX:1.9524,scaleY:1.9524,y:297.75},0).wait(1).to({scaleX:1.953,scaleY:1.953,y:297.7},0).wait(1).to({scaleX:1.9535,scaleY:1.9535},0).wait(1).to({scaleX:1.9541,scaleY:1.9541,y:297.65},0).wait(1).to({scaleX:1.9546,scaleY:1.9546,y:297.6},0).wait(1).to({scaleX:1.9552,scaleY:1.9552,y:297.55},0).wait(1).to({scaleX:1.9557,scaleY:1.9557,y:297.5},0).wait(1).to({scaleX:1.9563,scaleY:1.9563,x:587.95,y:297.45},0).wait(1).to({scaleX:1.9568,scaleY:1.9568,y:297.4},0).wait(1).to({scaleX:1.9573,scaleY:1.9573},0).wait(1).to({scaleX:1.9579,scaleY:1.9579,y:297.35},0).wait(1).to({scaleX:1.9584,scaleY:1.9584,x:588,y:297.3},0).wait(1).to({scaleX:1.9589,scaleY:1.9589,y:297.25},0).wait(1).to({scaleX:1.9594,scaleY:1.9594,y:297.2},0).wait(1).to({scaleX:1.9599,scaleY:1.9599,x:588.05,y:297.15},0).wait(1).to({scaleX:1.9604,scaleY:1.9604},0).wait(1).to({scaleX:1.9609,scaleY:1.9609,y:297.1},0).wait(1).to({scaleX:1.9614,scaleY:1.9614,y:297.05},0).wait(1).to({scaleX:1.9619,scaleY:1.9619,y:297},0).wait(1).to({scaleX:1.9623,scaleY:1.9623},0).wait(1).to({scaleX:1.9628,scaleY:1.9628,y:296.95},0).wait(1).to({scaleX:1.9632,scaleY:1.9632,y:296.9},0).wait(1).to({scaleX:1.9637,scaleY:1.9637},0).wait(1).to({scaleX:1.9641,scaleY:1.9641,x:588.1,y:296.85},0).wait(1).to({scaleX:1.9645,scaleY:1.9645,y:296.8},0).wait(1).to({scaleX:1.9649,scaleY:1.9649},0).wait(1).to({scaleX:1.9653,scaleY:1.9653,y:296.75},0).wait(1).to({scaleX:1.9657,scaleY:1.9657,y:296.7},0).wait(1).to({scaleX:1.9661,scaleY:1.9661},0).wait(1).to({scaleX:1.9664,scaleY:1.9664,y:296.65},0).wait(1).to({scaleX:1.9668,scaleY:1.9668},0).wait(1).to({scaleX:1.9671,scaleY:1.9671,y:296.6},0).wait(1).to({scaleX:1.9674,scaleY:1.9674},0).wait(1).to({scaleX:1.9678,scaleY:1.9678,y:296.55},0).wait(1).to({regX:0.3,regY:0.5,scaleX:1.9681,scaleY:1.9681,x:580.4,y:453.45},0).wait(1).to({regX:4.2,regY:-79.2,scaleX:1.9684,scaleY:1.9684,x:588,y:296.5},0).wait(1).to({scaleX:1.9687,scaleY:1.9687},0).wait(1).to({scaleX:1.969,scaleY:1.969,y:296.45},0).wait(1).to({scaleX:1.9693,scaleY:1.9693},0).wait(1).to({scaleX:1.9695,scaleY:1.9695,y:296.4},0).wait(1).to({scaleX:1.9698,scaleY:1.9698},0).wait(1).to({scaleX:1.9701,scaleY:1.9701,y:296.35},0).wait(1).to({scaleX:1.9703,scaleY:1.9703,x:588.05},0).wait(1).to({scaleX:1.9705,scaleY:1.9705},0).wait(1).to({scaleX:1.9707,scaleY:1.9707,y:296.3},0).wait(1).to({scaleX:1.971,scaleY:1.971},0).wait(1).to({scaleX:1.9712,scaleY:1.9712},0).wait(1).to({scaleX:1.9714,scaleY:1.9714,y:296.25},0).wait(1).to({scaleX:1.9715,scaleY:1.9715},0).wait(1).to({scaleX:1.9717,scaleY:1.9717},0).wait(1).to({scaleX:1.9719,scaleY:1.9719},0).wait(1).to({scaleX:1.972,scaleY:1.972,y:296.2},0).wait(1).to({scaleX:1.9722,scaleY:1.9722},0).wait(1).to({scaleX:1.9723,scaleY:1.9723},0).wait(1).to({scaleX:1.9724,scaleY:1.9724},0).wait(1).to({scaleX:1.9726,scaleY:1.9726,y:296.15},0).wait(1).to({scaleX:1.9727,scaleY:1.9727},0).wait(1).to({scaleX:1.9728,scaleY:1.9728},0).wait(1).to({scaleX:1.9729,scaleY:1.9729},0).wait(1).to({scaleX:1.973,scaleY:1.973},0).wait(1).to({scaleX:1.9731,scaleY:1.9731},0).wait(1).to({startPosition:0},0).wait(1).to({scaleX:1.9732,scaleY:1.9732,y:296.1},0).wait(1).to({scaleX:1.9733,scaleY:1.9733},0).wait(1).to({startPosition:0},0).wait(1).to({scaleX:1.9734,scaleY:1.9734},0).wait(1).to({startPosition:0},0).wait(1).to({regX:0.5,regY:0.5,x:580.5,y:453.4},0).to({_off:true},1).wait(350));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(78,-5967.6,2534.2,7759.400000000001);
// library properties:
lib.properties = {
	id: '6A21D8D36E124A94A4FEABBFEEACFC41',
	width: 1200,
	height: 675,
	fps: 33,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"Tele2_Flight8_640x360_atlas_NP_.jpg", id:"Tele2_Flight8_640x360_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['6A21D8D36E124A94A4FEABBFEEACFC41'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;