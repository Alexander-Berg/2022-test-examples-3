(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Tele2_Flight8_1456x180_atlas_P_", frames: [[0,0,163,73]]},
		{name:"Tele2_Flight8_1456x180_atlas_NP_", frames: [[0,305,515,294],[0,0,515,303],[0,865,515,262],[0,601,515,262]]}
];


// symbols:



(lib._DedNEW_728x90 = function() {
	this.initialize(ss["Tele2_Flight8_1456x180_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._dedNew_728x90_Gil = function() {
	this.initialize(ss["Tele2_Flight8_1456x180_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.brovka = function() {
	this.initialize(ss["Tele2_Flight8_1456x180_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ded1 = function() {
	this.initialize(ss["Tele2_Flight8_1456x180_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.ded1_Gil = function() {
	this.initialize(ss["Tele2_Flight8_1456x180_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Символ34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CD1277").s().p("EgVFAiJMAAAhERMAqLAAAMAAABERg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-218.4,270,436.9);


(lib.Символ31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AgKArIAAghIgdAAIAAgVIAdAAIAAgfIAVAAIAAAfIAdAAIAAAVIgdAAIAAAhg");
	this.shape.setTransform(-314.925,36.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("AghA4QgNgQAAggQAAgmALgUQAMgUAZAAQATAAAMALQALALABATIgaAAQgBgSgRABQgUAAAAAoIABAAQAJgMAPAAQATAAALAMQALALAAAVQAAAVgMALQgNANgWAAQgVAAgMgPgAgNAJQgFAGAAALQAAAKAFAGQAFAHAIgBQAJABAFgGQAFgGAAgLQAAgLgFgGQgFgGgJAAQgIABgFAFg");
	this.shape_1.setTransform(-325.4,36.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-333.8,19.7,27.400000000000034,32);


(lib.Символ29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgVUAhSMAAAhCjMAqpAAAMAAABCjg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-136.5,-213,273.1,426);


(lib.Символ28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CD1277").s().p("EhAOgF+MCAdgbnMAAABDLg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-411.1,-214.9,822.3,429.9);


(lib.Символ27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAUAqIgdhTIASAAIAdBTgAglAqIAbhOIAHAZIgIAbIASAAIAEANIgaAAIgEANg");
	this.shape.setTransform(67.8,0.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AATAqIAAhEIgLAAIAAgPIAcAAIAABTgAgjAbQAJAAACgKQACgFAAgVIAAggIAbAAIAAAPIgKAAIAAASIgBAZQgBAJgEAFQgIALgQAAg");
	this.shape_1.setTransform(59.575,0.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AARAqIAAhTIARAAIAABTgAghAqIAAhTIASAAIAABTgAgMAIIAZgrIAAAdIgZAqg");
	this.shape_2.setTransform(51.6,0.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgLAqIAAgPIAOAAQAGAAADgDQAEgDAAgEQAAgMgOAAIgNAAIAAgNIALAAQANAAAAgKQAAgIgLgBIgNAAIAAgOIAQAAQALAAAHAFQAHAGAAALQAAANgLAEIAAABQAGAAAEAGQAEAFAAAHQAAAMgHAGQgIAHgNAAgAggAqIAAhTIARAAIAABTg");
	this.shape_3.setTransform(43.825,0.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAUAqIgdhTIARAAIAeBTgAglAqIAahOIAIAZIgIAbIARAAIAGANIgbAAIgFANg");
	this.shape_4.setTransform(35.9,0.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgeAqIAAhTIARAAIAABTgAgJAOIAAgOIAJAAQAOAAAAgOQAAgGgEgDQgDgDgHgBIgJAAIAAgOIAKAAQAPAAAJAIQAGAIABALQgBAOgGAGQgJAIgPAAg");
	this.shape_5.setTransform(28.5,0.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAQAqIAAhEIgOAAIAAgPIAfAAIAABTgAggAqIAAhTIAfAAIAAAPIgOAAIAABEg");
	this.shape_6.setTransform(20.6,0.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgHAqIAAgPIAkAAIAAAPgAgcAqIAAhTIARAAIAABTgAgHAHIAAgPIAhAAIAAAPgAgHgaIAAgPIAjAAIAAAPg");
	this.shape_7.setTransform(10.425,0.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAQAqIAAhTIASAAIAABTgAghAqIAAhTIASAAIAABTgAgMAIIAZgrIAAAdIgZAqg");
	this.shape_8.setTransform(2.7,0.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgbAqIAAhTIASAAIAABTgAgFgaIAAgPIAhAAIAAAPg");
	this.shape_9.setTransform(-4.375,0.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgdAqIAAgPIAEAAQAKgBADgBQAEgBACgFIAZg8IATAAIgdBEQgFAJgFADQgFADgNAAgAglgpIAUAAIARAkIgIAUg");
	this.shape_10.setTransform(-11.6,0.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgeAqIAAhTIARAAIAABTgAgJAOIAAgOIAJAAQAOAAAAgOQAAgGgEgDQgEgDgGgBIgJAAIAAgOIAKAAQAQAAAHAIQAIAIAAALQAAAOgIAGQgHAIgPAAg");
	this.shape_11.setTransform(-19,0.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAYA0IAAgUIgWAAIAAgQIALAAIAAg0IgLAAIAAgPIAcAAIAABDIAMAAIAAAkgAgpA0IAAgkQAJgBACgIQACgHAAgUIAAgfIAcAAIAAAPIgLAAIAAASQAAAXgEALIAPAAIAAAQIgYAAIAAAUg");
	this.shape_12.setTransform(-27.25,1.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgIAJIAAgRIAQAAIAAARg");
	this.shape_13.setTransform(-35.95,3.375);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgTArIATgPIAfAAIAAAPgAgeArIAAgPIAZgTQALgIAEgFQADgEAAgHQAAgEgDgEQgDgEgFgBIAAgOQANABAIAHQAIAIAAAMQAAAJgHAHQgEAGgKAIIgjAbgAgdgIIAAgHQAAgKAHgIQAIgIANgBIAAAOQgFABgDAEQgEAEAAAFIAAAIg");
	this.shape_14.setTransform(-41.075,-0.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgHAqIAAgPIAkAAIAAAPgAgcAqIAAhTIARAAIAABTgAgHAHIAAgPIAhAAIAAAPgAgHgaIAAgPIAjAAIAAAPg");
	this.shape_15.setTransform(-48.025,0.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgEAqIAAgPIAfAAIAAAPgAgaAqIAAhTIASAAIAABTg");
	this.shape_16.setTransform(-54.575,0.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgHAqIAAgPIAkAAIAAAPgAgcAqIAAhTIARAAIAABTgAgHAHIAAgPIAhAAIAAAPgAgHgaIAAgPIAjAAIAAAPg");
	this.shape_17.setTransform(-61.375,0.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgIAqIAAhTIARAAIAABTgAAMgaIAAgPIAUAAIAAAPgAgfgaIAAgPIAUAAIAAAPg");
	this.shape_18.setTransform(-68.425,0.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-73.9,-9.1,147.8,18.299999999999997);


(lib.Символ26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAAAYIAVgXIgVgWIAAgWIAkAnIAAAJIgkAngAgiAXIAUgXIgVgWIAAgUIAkAmIAAAJIgjAmg");
	this.shape.setTransform(182.45,19.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAjAwIAAhJIgBAAIgcBJIgNAAIgchJIgCAAIAABJIgPAAIAAhfIAaAAIAaBIIAAAAIAchIIAaAAIAABfg");
	this.shape_1.setTransform(171.4,19.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgXBIIARgvIgmhgIATAAIAaBGIACAAIAZhGIARAAIgzCPg");
	this.shape_2.setTransform(160.175,21.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAVAwIAAhBIgCAAIgpBBIgQAAIAAhfIASAAIAABBIABAAIAphBIARAAIAABfg");
	this.shape_3.setTransform(150.4,19.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAjAwIAAhJIgCAAIgbBJIgOAAIgbhJIgCAAIAABJIgQAAIAAhfIAaAAIAbBIIAAAAIAchIIAZAAIAABfg");
	this.shape_4.setTransform(138.5,19.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcAmQgNgNAAgZQAAgWANgNQALgOATAAQASAAAKAJQAMALAAAUQAAAHgCADIg9AAQAAAQAIAJQAIAIANAAQATAAALgKIAAARQgKAJgWAAQgWAAgMgMgAAXgLQgBgXgVAAQgTAAgDAXIAsAAIAAAAg");
	this.shape_5.setTransform(126.975,19.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgsBJIAAiPIASAAIAAAOIABAAQAJgQAUAAQASAAALAOQAMANAAAXQAAAWgMAOQgLANgSAAQgTAAgKgPIgBAAIABAPIAAAugAgSgxQgHAGAAANIAAANQAAAOAHAHQAHAHALAAQAKAAAHgIQAIgIAAgRQAAgRgIgJQgHgIgKAAQgMAAgGAHg");
	this.shape_6.setTransform(116.925,21.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAcBIIAAh+Ig3AAIAAB+IgUAAIAAiPIBfAAIAACPg");
	this.shape_7.setTransform(104.8,17.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgjAFIAAgJIAkgnIAAAVIgVAWIAVAWIAAAWgAAAAFIAAgJIAkgmIAAAUIgVAWIAVAXIAAAUg");
	this.shape_8.setTransform(94.125,19.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgcAmQgNgNAAgZQAAgWANgNQALgOATAAQASAAAKAJQAMALAAAUQAAAHgCADIg9AAQAAAQAIAJQAIAIANAAQATAAALgKIAAARQgKAJgWAAQgWAAgMgMgAAXgLQgBgXgVAAQgTAAgDAXIAsAAIAAAAg");
	this.shape_9.setTransform(80.775,19.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgIBgIAAgvQgYAAgNgOQgNgNAAgWQAAgVANgOQANgOAYAAIAAguIARAAIAAAuQAYAAANAOQANANAAAWQAAAWgNANQgNAOgYAAIAAAvgAAJAjQAPAAAIgKQAIgJAAgQQAAgQgIgJQgIgJgPAAgAgfgZQgIAKAAAPQAAAQAIAJQAIAKAPAAIAAhFQgPAAgIAJg");
	this.shape_10.setTransform(69.375,19.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAUAwIAAhBIgBAAIgpBBIgQAAIAAhfIATAAIAABBIABAAIAphBIAQAAIAABfg");
	this.shape_11.setTransform(57.65,19.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgsBJIAAiPIASAAIAAAOIABAAQAJgQAUAAQASAAALAOQAMANAAAXQAAAWgMAOQgLANgSAAQgTAAgKgPIgBAAIABAPIAAAugAgSgxQgHAGAAANIAAANQAAAOAHAHQAHAHALAAQAKAAAHgIQAIgIAAgRQAAgRgIgJQgHgIgKAAQgMAAgGAHg");
	this.shape_12.setTransform(47.275,21.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgfAqQgHgHAAgMQAAgRAOgGQANgIAgAAIAAgFQgBgUgWAAQgRAAgNAIIAAgRQAMgHAUAAQAnAAAAAkIAAA9IgRAAIAAgPIgCAAQgKARgTAAQgOAAgIgIgAgKAGQgIAFgBAKQAAAOARAAQAIAAAHgHQAIgHAAgNIAAgFQgVAAgKADg");
	this.shape_13.setTransform(36.35,19.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgIAwIAAhPIgcAAIAAgQIBKAAIAAAQIgdAAIAABPg");
	this.shape_14.setTransform(27.65,19.55);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAVAwIAAhBIgCAAIgpBBIgQAAIAAhfIASAAIAABBIABAAIAphBIARAAIAABfg");
	this.shape_15.setTransform(14.05,19.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAAAYIAVgXIgVgWIAAgWIAkAnIAAAJIgkAngAgiAXIAUgXIgVgWIAAgUIAkAmIAAAJIgjAmg");
	this.shape_16.setTransform(0.3,19.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgqBJIAAgQIAqg0QARgWAAgQQAAgWgVAAQgSAAgOAMIAAgTQAMgKAYAAQAlAAAAAmQAAAMgHAMQgEAKgNAPIgfAoIA8AAIAAASg");
	this.shape_17.setTransform(-8.8,17.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgcAmQgNgNAAgZQAAgWANgNQALgOATAAQASAAAKAJQAMALAAAUQAAAHgCADIg9AAQAAAQAIAJQAIAIANAAQATAAALgKIAAARQgKAJgWAAQgWAAgMgMgAAXgLQgBgXgVAAQgTAAgDAXIAsAAIAAAAg");
	this.shape_18.setTransform(-18.475,19.55);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgSAxIAAh5IASAAIAAB2QAAAKAJAAQAFAAAFgCIAAAQQgFADgJAAQgXAAAAgYg");
	this.shape_19.setTransform(-25.425,17.275);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgcAmQgNgNAAgZQAAgWANgNQALgOATAAQASAAAKAJQAMALAAAUQAAAHgCADIg9AAQAAAQAIAJQAIAIANAAQATAAALgKIAAARQgKAJgWAAQgWAAgMgMgAAXgLQgBgXgVAAQgTAAgDAXIAsAAIAAAAg");
	this.shape_20.setTransform(-33.375,19.55);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgJBIIAAh+IgnAAIAAgRIBhAAIAAARIgnAAIAAB+g");
	this.shape_21.setTransform(-43.525,17.175);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAVBFIAAhCIgCAAIgpBCIgQAAIAAhfIASAAIAABBIABAAIAphBIARAAIAABfgAgVguQgIgIAAgOIAQAAQAAAPANAAQAOAAAAgPIARAAQAAAOgJAIQgJAHgNAAQgMAAgJgHg");
	this.shape_22.setTransform(-58.5,17.45);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgfAlQgNgOAAgXQAAgWANgNQAMgOATAAQAUAAAMANQANAOAAAWQAAAXgNAOQgMANgUAAQgTAAgMgNgAgRgZQgHAJgBAQQABARAHAJQAHAIAKAAQALAAAHgIQAIgJAAgRQAAgPgIgKQgHgIgLAAQgKAAgHAIg");
	this.shape_23.setTransform(-68.9,19.55);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AArBIIAAhyIgBAAIglByIgMAAIglhyIgCAAIAAByIgQAAIAAiPIAZAAIAlByIABAAIAlhyIAZAAIAACPg");
	this.shape_24.setTransform(-81.8,17.175);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgjAFIAAgJIAkgnIAAAVIgVAWIAVAWIAAAWgAAAAFIAAgJIAkgmIAAAUIgVAWIAVAXIAAAUg");
	this.shape_25.setTransform(-94.025,19.225);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAUAwIAAhBIgBAAIgpBBIgQAAIAAhfIATAAIAABBIABAAIAphBIAQAAIAABfg");
	this.shape_26.setTransform(157.2,-0.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAQAwIgcgqIgIACIAAAoIgSAAIAAhfIASAAIAAAqIAIgCIAdgoIATAAIghArIAkA0g");
	this.shape_27.setTransform(147.95,-0.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAVBFIAAhCIgCAAIgpBCIgQAAIAAhfIASAAIAABBIABAAIAqhBIAQAAIAABfgAgUguQgJgHAAgPIAQAAQAAAPANAAQAOAAAAgPIARAAQgBAPgIAHQgJAHgNAAQgNAAgHgHg");
	this.shape_28.setTransform(137.5,-3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgcAmQgNgNAAgZQAAgWANgOQALgNATAAQASAAAKAJQAMALAAATQAAAJgCACIg9AAQAAAQAIAIQAIAJANAAQATAAALgKIAAARQgKAJgWAAQgWAAgMgMgAAXgLQgBgYgVABQgTgBgDAYIAsAAIAAAAg");
	this.shape_29.setTransform(127.425,-0.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AAUAwIAAgqIgnAAIAAAqIgTAAIAAhfIATAAIAAAmIAnAAIAAgmIATAAIAABfg");
	this.shape_30.setTransform(117.4,-0.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAUAwIAAhBIgBAAIgpBBIgQAAIAAhfIATAAIAABBIABAAIAohBIARAAIAABfg");
	this.shape_31.setTransform(106.95,-0.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgpAwIAAgRIAEAAQALAAAEgXQADgQgBgoIA+AAIAABfIgSAAIAAhPIgcAAQAAAlgFATQgHAZgTAAIgGgBg");
	this.shape_32.setTransform(96.2,-0.825);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAWAwIgXgjIgXAjIgSAAIAggwIghgvIAWAAIAWAiIAWgiIASAAIgfAuIAiAxg");
	this.shape_33.setTransform(82.475,-0.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgfAqQgHgHAAgMQAAgRANgHQAOgHAfAAIAAgFQAAgVgWABQgRgBgNAJIAAgRQAMgHAUAAQAnAAAAAkIAAA9IgSAAIAAgPIgBAAQgKARgTAAQgOAAgIgIgAgJAGQgKAFABAKQAAAOAQAAQAJAAAGgHQAIgHgBgNIAAgFQgUAAgJADg");
	this.shape_34.setTransform(72.5,-0.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgIBgIAAgvQgYAAgNgOQgNgNAAgWQAAgVANgOQANgOAYAAIAAguIARAAIAAAuQAYAAANAOQANANAAAWQAAAWgNANQgNAOgYAAIAAAvgAAJAjQAPAAAIgKQAIgJAAgQQAAgQgIgJQgIgJgPAAgAgfgZQgIAKAAAPQAAAQAIAJQAIAKAPAAIAAhFQgPAAgIAJg");
	this.shape_35.setTransform(61.175,-0.875);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAUAwIAAhBIgBAAIgpBBIgQAAIAAhfIATAAIAABBIABAAIAohBIARAAIAABfg");
	this.shape_36.setTransform(49.45,-0.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgsBJIAAiPIASAAIAAAOIABAAQAJgQAUAAQASAAALANQAMAOAAAWQAAAXgMAOQgLANgSAAQgTAAgKgQIgBAAIABAQIAAAugAgSgyQgHAIAAAMIAAANQAAAOAHAGQAHAIALAAQAKAAAHgIQAIgIAAgSQAAgQgIgJQgHgIgKAAQgMAAgGAGg");
	this.shape_37.setTransform(39.075,1.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgfAqQgHgHAAgMQAAgRANgHQAOgHAgAAIAAgFQAAgVgXABQgRgBgNAJIAAgRQAMgHAUAAQAnAAAAAkIAAA9IgRAAIAAgPIgCAAQgKARgTAAQgOAAgIgIgAgKAGQgJAFAAAKQAAAOARAAQAJAAAGgHQAIgHAAgNIAAgFQgVAAgKADg");
	this.shape_38.setTransform(28.15,-0.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgIAwIAAhPIgdAAIAAgQIBLAAIAAAQIgdAAIAABPg");
	this.shape_39.setTransform(19.45,-0.9);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AAWAwIgXgjIgXAjIgSAAIAggwIghgvIAWAAIAWAiIAWgiIASAAIgfAuIAiAxg");
	this.shape_40.setTransform(6.325,-0.9);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AAhAwIAAhfIATAAIAABfgAgzAwIAAhfIATAAIAAAgIANAAQAVAAAKAKQAJAHAAANQAAAPgJAIQgKAKgVAAgAggAhIAPAAQATAAAAgSQAAgPgTAAIgPAAg");
	this.shape_41.setTransform(-5,-0.9);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgIAwIAAhPIgcAAIAAgQIBJAAIAAAQIgcAAIAABPg");
	this.shape_42.setTransform(-15.45,-0.9);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAhAwIAAhfIASAAIAABfgAgyAwIAAhfIASAAIAAAgIAMAAQAWAAALAKQAIAHABANQgBAPgIAIQgLAKgWAAgAggAhIAOAAQAVAAAAgSQAAgPgVAAIgOAAg");
	this.shape_43.setTransform(-25.85,-0.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgsBJIAAiPIASAAIAAAOIABAAQAJgQAUAAQASAAALANQAMAOAAAWQAAAXgMAOQgLANgSAAQgTAAgKgQIgBAAIABAQIAAAugAgSgyQgHAIAAAMIAAANQAAAOAHAGQAHAIALAAQAKAAAHgIQAIgIAAgSQAAgQgIgJQgHgIgKAAQgMAAgGAGg");
	this.shape_44.setTransform(-37.525,1.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AAQAwIgcgqIgIACIAAAoIgSAAIAAhfIASAAIAAAqIAIgCIAdgoIATAAIghArIAkA0g");
	this.shape_45.setTransform(-47.35,-0.9);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgIAwIAAhPIgcAAIAAgQIBKAAIAAAQIgdAAIAABPg");
	this.shape_46.setTransform(-56.5,-0.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgfAlQgNgNAAgYQAAgWANgOQAMgNATAAQAUAAAMANQANAOAAAWQAAAYgNANQgMANgUAAQgTAAgMgNgAgRgZQgHAJAAAQQAAARAHAJQAHAIAKAAQALAAAHgIQAIgJgBgRQABgPgIgKQgHgIgLAAQgKAAgHAIg");
	this.shape_47.setTransform(-65.6,-0.9);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgfAqQgHgHAAgMQAAgRAOgHQAOgHAeAAIAAgFQABgVgXABQgRgBgNAJIAAgRQAMgHAUAAQAnAAAAAkIAAA9IgSAAIAAgPIgBAAQgKARgTAAQgOAAgIgIgAgJAGQgJAFAAAKQAAAOAQAAQAJAAAGgHQAHgHAAgNIAAgFQgVAAgIADg");
	this.shape_48.setTransform(-80.35,-0.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AAeBIIAAhBIg7AAIAABBIgUAAIAAiPIAUAAIAAA+IA7AAIAAg+IATAAIAACPg");
	this.shape_49.setTransform(-91.6,-3.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101.2,-20.6,304.6,53.7);


(lib.Символ24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhBBVIAAgbIAUAAIAAhzIgUAAIAAgbIB5AAIAAAzIgcAAIAAgVIgoAAIAAAkIAQAAQAeAAARAPQAPAMAAAWQAAAWgPAPQgRARgfAAgAgMA3IAOAAQAdAAAAgWQAAgWgdAAIgOAAg");
	this.shape.setTransform(191.275,0.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag7BVIAAgbIAUAAIAAhzIgUAAIAAgbIB3AAIAAAzIgcAAIAAgVIgmAAIAABwIAWAAIAAAbg");
	this.shape_1.setTransform(177.425,0.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAGA6IAAgaIANAAIAAgpIgBAAIgmBDIgtAAIAAgaIAQAAIAAg/IgQAAIAAgaIA9AAIAAAaIgPAAIAAApIABAAIAnhDIAuAAIAAAaIgRAAIAAA/IARAAIAAAag");
	this.shape_2.setTransform(156.85,3.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgiA6IAAgaIATAAIAAg+IgPAAIAAAVIgaAAIAAgwIBxAAIAAAwIgbAAIAAgVIgOAAIAAA+IATAAIAAAag");
	this.shape_3.setTransform(137.1,3.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgpBWIAAgZIASAAIAKgeIgjhbIgMAAIAAgZIAkAAIAZBKIACAAIAQgxIgLAAIAAgZIA1AAIAAAZIgMAAIgrB5IANAAIAAAZg");
	this.shape_4.setTransform(124.825,6.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAPA6IAAguIgdAAIAAAUIANAAIAAAaIg9AAIAAgaIAQAAIAAg/IgQAAIAAgaIAwAAIAAArIAdAAIAAgRIgNAAIAAgaIA9AAIAAAaIgQAAIAAA/IAQAAIAAAag");
	this.shape_5.setTransform(111.575,3.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAGA6IAAgaIANAAIAAgpIgBAAIgmBDIgtAAIAAgaIAQAAIAAg/IgQAAIAAgaIA9AAIAAAaIgPAAIAAApIABAAIAnhDIAuAAIAAAaIgRAAIAAA/IARAAIAAAag");
	this.shape_6.setTransform(97,3.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAmA6IAAhPIgBAAIgZBPIgbAAIgZhPIgBAAIAABPIgtAAIAAgaIAQAAIAAg/IgQAAIAAgaIBBAAIAVBJIABAAIAXhJIA/AAIAAAaIgQAAIAAA/IAQAAIAAAag");
	this.shape_7.setTransform(80.175,3.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgyAAQABgbAOgQQAOgQAYAAQAWAAAMAMQANAMAAAYQAAAMgCAHIg+AAQABAYAaAAQAUAAANgIIAAAcQgNAIgYAAQg6AAgBg8gAATgOQgBgTgQAAQgPAAgCATIAiAAIAAAAg");
	this.shape_8.setTransform(58.7,3.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AA3A6IgegvIgJACIAAATIALAAIAAAaIg1AAIAAgaIALAAIAAgTIgJgCIgfAvIghAAIAAgaIANAAIAagkIgXgbIgOAAIAAgaIA0AAIAAAaIgEAAIAPAUIAIACIAAgWIgJAAIAAgaIAxAAIAAAaIgJAAIAAAWIAIgCIAPgUIgFAAIAAgaIA0AAIAAAaIgOAAIgWAaIAbAlIAMAAIAAAag");
	this.shape_9.setTransform(43.7,3.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgvAzQgJgJAAgPQAAgoBAAAIAAgDQAAgPgVAAQgTAAgPAKIAAgdQAPgJAXAAQAxAAAAAsIAAAwIARAAIAAAZIgwAAIAAgSIgBAAQgGAKgFAEQgIAGgMAAQgPAAgJgJgAgWAWQAAAKAMAAQAIAAAEgFQAGgHAAgKIAAgDQgeAAAAAPg");
	this.shape_10.setTransform(28.425,3.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAiBJIgCgeIg/AAIgCAeIgdAAIAAg5IAKAAQAOgOADgwIgPAAIAAgaIBwAAIAAAaIgQAAIAAA+IARAAIAAA5gAgLgNQgEAUgGAJIAiAAIAAg9IgVAAQAAAQgDAQg");
	this.shape_11.setTransform(14.85,5.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgnAtQgQgQAAgdQAAgaAQgRQAPgQAYAAQAYAAAPAQQARARAAAaQAAAdgQAQQgQAPgYAAQgYAAgPgPgAgWAAQAAAfAWAAQAWAAAAgfQAAgdgWAAQgWAAAAAdg");
	this.shape_12.setTransform(2.125,3.55);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag+BXIAAgZIAQAAIAAh4IgQAAIAAgaIAvAAIAAAQIACAAQAKgSAWAAQAUgBAMASQAMAPAAAaQAAAcgMAQQgMAQgVAAQgVAAgKgRIgCAAIACARIAAAeIARAAIAAAZgAgNgfIAAAIQAAAbAUAAQAXAAAAgfQAAgegWAAQgVAAAAAag");
	this.shape_13.setTransform(-11.225,6.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAOA6IAAhYIgbAAIAAA+IANAAIAAAaIg9AAIAAgaIAQAAIAAg/IgQAAIAAgaIB7AAIAAAaIgRAAIAAA/IARAAIAAAag");
	this.shape_14.setTransform(-25.15,3.575);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgnAtQgQgQAAgdQAAgaAQgRQAPgQAYAAQAYAAAPAQQARARAAAaQAAAdgQAQQgQAPgYAAQgYAAgPgPgAgWAAQAAAfAWAAQAWAAAAgfQAAgdgWAAQgWAAAAAdg");
	this.shape_15.setTransform(-44.675,3.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAOA6IAAhYIgbAAIAAA+IANAAIAAAaIg9AAIAAgaIAQAAIAAg/IgQAAIAAgaIB7AAIAAAaIgRAAIAAA/IARAAIAAAag");
	this.shape_16.setTransform(-57.9,3.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68.7,-46,276.6,92);


(lib.Символ23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgdAtQgPgQAAgdQAAgaAPgRQAQgQAaAAQASAAAOAHIAAAqIgaAAIAAgTIgFgBQgMAAgGAIQgHAIAAAOQAAAfAcAAQASAAAKgJIAAAfQgKAHgWAAQgbAAgPgPg");
	this.shape.setTransform(78.725,-9.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAFA6IAAgaIAPAAIAAgpIgCAAIgmBDIguAAIAAgaIARAAIAAg/IgRAAIAAgaIA+AAIAAAaIgPAAIAAApIABAAIAnhDIAuAAIAAAaIgRAAIAAA/IARAAIAAAag");
	this.shape_1.setTransform(66.05,-9.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag2A6IAAgaIARAAIAAg/IgRAAIAAgaIA9AAQAsAAAAAeQAAAUgUAFIAAABQAYADgBAXQAAAhgsAAgAgGAjIALAAQAQAAAAgMQAAgNgQAAIgLAAgAgGgLIAIAAQAPAAABgMQgBgLgPAAIgIAAg");
	this.shape_2.setTransform(52.25,-9.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag+BXIAAgZIAQAAIAAh4IgQAAIAAgaIAvAAIAAAQIACAAQAKgSAWAAQAUgBAMASQAMAPAAAaQAAAcgMAQQgMAQgVAAQgVAAgKgRIgCAAIACARIAAAeIARAAIAAAZgAgNgfIAAAIQAAAbAUAAQAXAAAAgfQAAgegWAAQgVAAAAAag");
	this.shape_3.setTransform(38.975,-6.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgxAAQAAgbANgQQAPgQAXAAQAXAAAMAMQAOAMAAAYQgBAMgCAHIg+AAQABAYAbAAQATAAANgIIAAAcQgNAIgYAAQg7AAABg8gAASgOQAAgTgRAAQgPAAgBATIAhAAIAAAAg");
	this.shape_4.setTransform(26.25,-9.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdAtQgPgQAAgdQAAgaAPgRQAQgQAaAAQASAAAOAHIAAAqIgaAAIAAgTIgFgBQgMAAgGAIQgHAIAAAOQAAAfAcAAQASAAAKgJIAAAfQgKAHgWAAQgbAAgPgPg");
	this.shape_5.setTransform(14.925,-9.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAFBRIAAgZIAPAAIAAgqIgCAAIgmBDIguAAIAAgZIARAAIAAhAIgRAAIAAgZIA+AAIAAAZIgPAAIAAApIABAAIAnhCIAuAAIAAAZIgRAAIAABAIARAAIAAAZgAgbgzQgMgKAAgTIAcAAQAAAOALAAQAMAAAAgOIAcAAQAAATgNAKQgLAIgQAAQgQAAgLgIg");
	this.shape_6.setTransform(-4.05,-11.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAiA6IAAhZIgRAAIAAgaIBBAAIAAAaIgQAAIAAA/IAQAAIAAAagAhRA6IAAgaIAQAAIAAg/IgQAAIAAgaIBAAAIAAAaIgQAAIAAAPIALAAQAXAAANAKQAMAJAAAQQAAASgMAKQgNALgXAAgAghAhIAKAAQARAAAAgNQAAgMgRAAIgKAAg");
	this.shape_7.setTransform(-20.475,-9.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag2A6IAAgaIARAAIAAg/IgRAAIAAgaIA9AAQAsAAAAAeQAAAUgUAFIAAABQAYADgBAXQAAAhgsAAgAgGAjIALAAQAQAAABgMQgBgNgQAAIgLAAgAgGgLIAIAAQAQAAgBgMQABgLgQAAIgIAAg");
	this.shape_8.setTransform(-35.85,-9.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag+BXIAAgZIAQAAIAAh4IgQAAIAAgaIAvAAIAAAQIACAAQAKgSAWAAQAUgBAMASQAMAPAAAaQAAAcgMAQQgMAQgVAAQgVAAgKgRIgCAAIACARIAAAeIARAAIAAAZgAgNgfIAAAIQAAAbAUAAQAXAAAAgfQAAgegWAAQgVAAAAAag");
	this.shape_9.setTransform(-49.125,-6.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgxAAQAAgbANgQQAOgQAZAAQAVAAANAMQAOAMAAAYQgBAMgCAHIg+AAQABAYAbAAQATAAANgIIAAAcQgNAIgYAAQg7AAABg8gAASgOQAAgTgRAAQgPAAgBATIAhAAIAAAAg");
	this.shape_10.setTransform(-61.85,-9.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAYBVIAAiLIgvAAIAABwIAUAAIAAAbIhJAAIAAgbIAUAAIAAhzIgUAAIAAgbICZAAIAAAbIgUAAIAABzIAUAAIAAAbg");
	this.shape_11.setTransform(-76.125,-12.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-88.5,-32.9,177,65.8);


(lib.Символ19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUBWIAAggIAWAAQAOAAAHgHQAIgHAAgNQAAgbgdAAIgWAAIAAgeIAaAAQAeAAAPARQANAOAAAaQAAAZgNAPQgQASgeABgAg/BWIAAiqIAkAAIAACqg");
	this.shape.setTransform(48.65,0.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgRBWIAAiqIAjAAIAACqgAAZg1IAAgfIAoAAIAAAfgAhAg1IAAgfIAoAAIAAAfg");
	this.shape_1.setTransform(33.8,0.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAoBWIg7iqIAkAAIA8CqgAhMBWIA1ifIARAwIgSA5IAlAAIAKAcIg4AAIgIAag");
	this.shape_2.setTransform(18.85,0.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAyBqIAAgpIgtAAIAAggIAVAAIAAhqIgVAAIAAggIA5AAIAACKIAYAAIAABJgAhUBqIAAhJQASgCAEgRQAFgNAAgqIAAhAIA4AAIAAAgIgVAAIAAAkQAAAwgIAWIAdAAIAAAgIgwAAIAAApg");
	this.shape_3.setTransform(1.95,2.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AADA5QARgCALgNQANgPAAgbQAAgbgOgQQgKgLgRgCIAAghQAfABAUATQAbAYAAAtQAAArgZAYQgVAVggACgAg4BDQgYgZAAgqQAAgsAagYQAVgUAegBIAAAhQgQACgLAMQgNAPAAAbQAAAaAMAQQALANARACIAAAhQgggCgVgVg");
	this.shape_4.setTransform(-15.925,0.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag/BWIAAiqIAkAAIAACqgAgUAdIAAgdIAUAAQAcAAAAgcQAAgNgIgHQgHgHgNAAIgUAAIAAgdIAWAAQAfAAARARQAOAOAAAZQAAAagPAOQgQARgeAAg");
	this.shape_5.setTransform(-31.9,0.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAgBWIAAiLIgcAAIAAgfIBAAAIAACqgAhDBWIAAiqIBAAAIAAAfIgcAAIAACLg");
	this.shape_6.setTransform(-47.975,0.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.2,-18.6,120.5,37.2);


(lib.Символ18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUBWIAAggIAWAAQANAAAIgHQAIgHAAgMQAAgdgdABIgWAAIAAgeIAaAAQAdAAAQARQANAOAAAbQAAAYgNAQQgQASgfAAgAg/BWIAAirIAjAAIAACrg");
	this.shape.setTransform(62.525,0.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgRBWIAAirIAjAAIAACrgAAZg1IAAggIApAAIAAAggAhBg1IAAggIApAAIAAAgg");
	this.shape_1.setTransform(47.6,0.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAhBWIAAirIAkAAIAACrgAhEBWIAAirIAjAAIAACrgAgZAPIAzhXIAAA6IgzBYg");
	this.shape_2.setTransform(32.125,0.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgRBWIAAirIAjAAIAACrgAAZg1IAAggIApAAIAAAggAhBg1IAAggIApAAIAAAgg");
	this.shape_3.setTransform(16.65,0.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAoBWIg7irIAkAAIA9CrgAhNBWIA2ifIARAwIgSA5IAlAAIAKAcIg4AAIgIAag");
	this.shape_4.setTransform(1.625,0.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag/BWIAAirIAjAAIAACrgAgUAdIAAgdIAUAAQAcAAAAgdQAAgNgIgGQgHgIgNABIgUAAIAAgeIAWAAQAfAAARARQAOAPAAAYQAAAbgPAOQgQARgeAAg");
	this.shape_5.setTransform(-13.525,0.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgRBWIAAirIAjAAIAACrgAAag1IAAggIAoAAIAAAggAhBg1IAAggIAoAAIAAAgg");
	this.shape_6.setTransform(-28.5,0.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAEA5QARgBALgNQAMgQAAgbQAAgcgNgPQgLgMgQgBIAAgiQAeACAVATQAbAYAAAtQAAArgZAZQgVAVggABgAg4BEQgZgZAAgrQAAgtAagYQAVgTAfgCIAAAiQgQABgLAMQgNAQAAAbQAAAbAMAPQALAOARABIAAAhQgggBgVgVg");
	this.shape_7.setTransform(-44.475,0.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAgBWIAAiLIgcAAIAAggIBAAAIAACrgAhDBWIAAirIBAAAIAAAgIgdAAIAACLg");
	this.shape_8.setTransform(-61.7,0.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74.1,-18.7,148.3,37.5);


(lib.Символ17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVBYIAAghIAXAAQAOAAAHgHQAJgHgBgNQAAgdgdAAIgXAAIAAgeIAbAAQAeAAAPARQAOAPABAbQAAAZgOAQQgQASgfABgAhBBYIAAivIAlAAIAACvg");
	this.shape.setTransform(58.5,0.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgRBYIAAivIAjAAIAACvgAAag2IAAghIApAAIAAAhgAhCg2IAAghIApAAIAAAhg");
	this.shape_1.setTransform(43.275,0.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAiBYIAAivIAlAAIAACvgAhGBYIAAivIAlAAIAACvgAgaAPIA1hZIAAA8Ig1BZg");
	this.shape_2.setTransform(27.525,0.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhABYIAAivIAkAAIAACvgAgUAdIAAgdIAUAAQAdAAAAgdQAAgNgIgIQgIgGgNAAIgUAAIAAgfIAWAAQAgAAARASQAOAPAAAZQABAbgPAOQgRARgfAAg");
	this.shape_3.setTransform(11.65,0.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AApBYIg9ivIAlAAIA+CvgAhOBYIA3ijIARAyIgSA5IAlAAIALAdIg5AAIgJAbg");
	this.shape_4.setTransform(-4.5,0.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAzBtIAAgrIguAAIAAggIAWAAIAAhtIgWAAIAAghIA7AAIAACOIAYAAIAABLgAhXBtIAAhLQATgDAFgRQAEgNAAgsIAAhBIA6AAIAAAhIgVAAIAAAkQAAAygJAXIAeAAIAAAgIgxAAIAAArg");
	this.shape_5.setTransform(-21.825,2.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAEA6QARgCALgNQANgPAAgcQAAgcgOgQQgLgMgQgBIAAgiQAfABAVATQAbAZAAAuQAAAsgZAZQgWAWggABgAg5BFQgZgZAAgsQAAgtAagZQAWgUAfgBIAAAiQgQABgLANQgOAPAAAcQAAAbANAQQALAOARABIAAAiQgggCgWgVg");
	this.shape_6.setTransform(-40.175,0.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAhBYIAAiOIgdAAIAAghIBBAAIAACvgAhEBYIAAivIBBAAIAAAhIgdAAIAACOg");
	this.shape_7.setTransform(-57.7,0.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.3,-19.1,140.7,38.2);


(lib.Символ16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUBXIAAggIAWAAQAOAAAIgHQAHgHAAgNQAAgdgdAAIgWAAIAAgeIAaAAQAeAAAQASQANAOAAAbQAAAZgNAPQgQATgfAAgAhABXIAAitIAkAAIAACtg");
	this.shape.setTransform(41.725,0.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgRBXIAAitIAkAAIAACtgAAag2IAAggIApAAIAAAggAhCg2IAAggIAqAAIAAAgg");
	this.shape_1.setTransform(26.55,0.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA4BXIAAitIAkAAIAACtgAgvBXIAAggIAXAAQAOAAAIgHQAGgHAAgNQAAgdgcAAIgXAAIAAgeIAbAAQAdAAAQASQANAOAAAbQAAAZgNAPQgQATgeAAgAhbBXIAAitIAkAAIAACtg");
	this.shape_2.setTransform(8.675,0.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgUBXIAAggIAWAAQAOAAAIgHQAHgHAAgNQAAgagdAAIgWAAIAAgdIAaAAQA7AAAAA3QAAAZgNAPQgQATgfAAgAhABXIAAitIAkAAIAACtgAgUg2IAAggIBGAAIAAAgg");
	this.shape_3.setTransform(-9.325,0.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AApBXIg9itIAlAAIA+CtgAhOBXIA3iiIARAyIgSA5IAmAAIAKAdIg5AAIgJAag");
	this.shape_4.setTransform(-25.425,0.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAEA+QAMgBAJgGQAKgHAAgMQAAgQgPgHQgJgEgLAAIgPAAIAAgZIAQAAQALAAAIgFQALgGAAgMQAAgKgJgHQgHgGgLAAIAAgdQAdABARAOQASAOAAAVQAAAOgKALQgIAHgMAEQAMADAKAIQANAMgBARQABAZgVAQQgTAPgdABgAgzBMQgQgOgEgeIAigFQADARAGAHQAHAKATABIAAAeQgggBgRgPgAhEgjQAMg2A2gCIAAAdQgQABgIAJQgFAHgDAOg");
	this.shape_5.setTransform(-41.45,0.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53.6,-19,107.2,38);


(lib.Символ12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CD1278").ss(1,1,1).p("Aq+i9IV9AAQBOAAA4A4QA3A3AABOIAAAAQAABPg3A3Qg4A4hOAAI19AAQhPAAg3g4Qg3g3AAhPIAAAAQAAhOA3g3QA3g4BPAAg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.2,-19.9,180.4,39.9);


(lib.Символ11копия2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CD1277").s().p("Aq+C+QhPAAg3g4Qg3g3AAhPIAAAAQAAhOA3g3QA3g4BPAAIV9AAQBOAAA3A4QA4A3AABOIAAAAQAABPg4A3Qg3A4hOAAg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-89.2,-19,178.4,38);


(lib.Символ11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CD1278").ss(1,1,1).p("Aq+i9IV9AAQBOAAA4A4QA3A3AABOIAAAAQAABPg3A3Qg4A4hOAAI19AAQhPAAg3g4Qg3g3AAhPIAAAAQAAhOA3g3QA3g4BPAAg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.2,-20,180.4,40);


(lib.Символ10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CD1278").ss(1,1,1).p("Aq+i9IV9AAQBOAAA4A4QA3A3AABOIAAAAQAABPg3A3Qg4A4hOAAI19AAQhPAAg3g4Qg3g3AAhPIAAAAQAAhOA3g3QA3g4BPAAg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.2,-20,180.4,40);


(lib.Символ9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CD1278").ss(1,1,1).p("Aq+i9IV9AAQBOAAA4A4QA3A3AABOIAAAAQAABPg3A3Qg4A4hOAAI19AAQhPAAg3g4Qg3g3AAhPIAAAAQAAhOA3g3QA3g4BPAAg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.2,-20,180.4,40);


(lib.Символ8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhRhMQBMhxCbgiIAADqQgpARgSAhQgYAwAGBfIjdAUQgIi8BLhwg");
	this.shape.setTransform(21.0846,-8.0044,0.2442,0.2442);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AllB4IAAjZILLgXIAADwg");
	this.shape_1.setTransform(25.9667,9.4489,0.2442,0.2442);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AjDEYQCSiLA5hEQAtg2ARg0QAQg1gSgmQgLgYgZgMQgZgMggACIAAjmQBQgMBGATQBHATAxAvQAuArAWA6QAWA7gGA/QgKB4hEBuQhEBvihCdIlgALg");
	this.shape_2.setTransform(26.3647,-3.7962,0.2442,0.2442);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AiEBjIAAi9IEJgIIAADFg");
	this.shape_3.setTransform(-2.6276,9.9678,0.2442,0.2442);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhaGqIAAs5IC1gaIAANTg");
	this.shape_4.setTransform(-8.9337,1.989,0.2442,0.2442);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AiZBsIAAjOIEygKIAADYg");
	this.shape_5.setTransform(11.8222,9.7419,0.2442,0.2442);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhkhgIDJgRIAADYIjJALg");
	this.shape_6.setTransform(10.528,0.7497,0.2442,0.2442);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AiZhRIEygrIAADYIkyAhg");
	this.shape_7.setTransform(11.8222,-8.4927,0.2442,0.2442);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhoHSIAAuGIDRgdIAAOjg");
	this.shape_8.setTransform(4.5515,1.0122,0.2442,0.2442);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhzBbIAAiuIDngHIAAC1g");
	this.shape_9.setTransform(-15.4901,10.1692,0.2442,0.2442);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhLhRICXgOIAAC2IiXAJg");
	this.shape_10.setTransform(-16.4607,2.6605,0.2442,0.2442);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhzhGIDnghIAAC1IjnAag");
	this.shape_11.setTransform(-15.4901,-5.0497,0.2442,0.2442);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhPGGIAAr1ICfgXIAAMMg");
	this.shape_12.setTransform(-21.0148,2.8558,0.2442,0.2442);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhLEQIAAoQICXgPIAAIfg");
	this.shape_13.setTransform(-29.4026,5.7494,0.2442,0.2442);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AjPgvIGfg6IAACmImfAtg");
	this.shape_14.setTransform(-29.4209,-3.3404,0.2442,0.2442);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.5,-13.7,69.2,26.1);


(lib.Символ6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAvIAAgRIApAAIAAARgAggAvIAAhdIAUAAIAABdgAgIAIIAAgQIAlAAIAAAQgAgIgdIAAgRIAnAAIAAARg");
	this.shape.setTransform(35.475,-0.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgIAvIAAgRIApAAIAAARgAggAvIAAhdIAUAAIAABdgAgIAIIAAgQIAlAAIAAAQgAgIgdIAAgRIAnAAIAAARg");
	this.shape_1.setTransform(27.575,-0.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AASAvIAAgpIgQAAIAAgQIAQAAIAAgkIAUAAIAABdgAglAvIAAhdIAUAAIAAAkIAQAAIAAAQIgQAAIAAApg");
	this.shape_2.setTransform(18.925,-0.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgLAvIAAgRIAMAAQAHAAAFgEQAEgEAAgGQAAgPgQAAIgMAAIAAgOIAOAAQAgAAAAAdQAAAMgHAJQgIAKgRAAgAgiAvIAAhdIAUAAIAABdgAgLgdIAAgRIAmAAIAAARg");
	this.shape_3.setTransform(10.45,-0.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AACAfQAJgBAHgHQAGgIABgPQAAgPgIgIQgGgGgJgBIAAgSQARAAALALQAPANAAAYQAAAYgOANQgMAMgRAAgAgeAlQgOgOAAgXQAAgYAPgNQAMgLAQAAIAAASQgJABgGAGQgHAJAAAOQAAAOAHAJQAGAHAJABIAAASQgRgBgMgLg");
	this.shape_4.setTransform(1.3,-0.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgiAvIAAhdIATAAIAABdgAgLAQIAAgQIALAAQAPAAAAgPQAAgHgEgEQgEgDgHAAIgLAAIAAgRIAMAAQASAAAJAJQAHAJAAANQAAAOgIAHQgIAKgRAAg");
	this.shape_5.setTransform(-7.45,-0.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAbA7IAAgXIgYAAIAAgSIAMAAIAAg6IgMAAIAAgRIAfAAIAABLIANAAIAAApgAguA7IAAgpQAKgBADgJQACgIAAgXIAAgiIAfAAIAAARIgLAAIAAAUQAAAagFAMIAQAAIAAASIgaAAIAAAXg");
	this.shape_6.setTransform(-16.7,0.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AACAfQAJgBAGgHQAIgIAAgPQAAgPgIgIQgGgGgJgBIAAgSQAQAAAMALQAOANAAAYQAAAYgNANQgMAMgRAAgAgeAlQgOgOAAgXQAAgYAPgNQALgLARAAIAAASQgJABgGAGQgHAJAAAOQAAAOAHAJQAGAHAJABIAAASQgRgBgMgLg");
	this.shape_7.setTransform(-26.5,-0.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AASAvIAAhMIgQAAIAAgRIAjAAIAABdgAgkAvIAAhdIAjAAIAAARIgQAAIAABMg");
	this.shape_8.setTransform(-35.875,-0.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CD1277").s().p("AohCHIAAkNIRDAAIAAENg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54.6,-13.5,109.30000000000001,27);


(lib.Символ5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBnIAAgmIAaAAQARAAAJgIQAJgIAAgQQAAgigjAAIgaAAIAAgjIAfAAQAkAAASAUQAQASAAAfQAAAdgQATQgSAWgmAAgAhMBnIAAjNIArAAIAADNg");
	this.shape.setTransform(79.775,0.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgVBnIAAjNIAqAAIAADNgAAehAIAAgmIAxAAIAAAmgAhOhAIAAgmIAxAAIAAAmg");
	this.shape_1.setTransform(61.875,0.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAxBnIhJjNIAsAAIBJDNgAhcBnIBAi/IAUA6IgUBEIAsAAIAMAiIhDAAIgKAfg");
	this.shape_2.setTransform(43.8,0.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAuBnIAAinIgZAAIAAgmIBEAAIAADNgAhYBBQAXAAAFgWQAEgPAAg1IAAhNIBDAAIAAAmIgYAAIAAAsQABAogEAVQgDAVgLAOQgSAbgoAAg");
	this.shape_3.setTransform(23.6,0.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgTBnIAAgmIBbAAIAAAmgAhHBnIAAjNIArAAIAADNgAgTARIAAgkIBSAAIAAAkgAgThAIAAgmIBXAAIAAAmg");
	this.shape_4.setTransform(5.75,0.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AA8CAIAAgyIg2AAIAAgmIAaAAIAAiBIgaAAIAAgmIBFAAIAACnIAcAAIAABYgAhmCAIAAhYQAWgDAGgUQAEgQAAgzIAAhNIBEAAIAAAmIgZAAIAAAsQAAA6gKAbIAjAAIAAAmIg5AAIAAAyg");
	this.shape_5.setTransform(-14.025,2.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAFBEQATgCAOgPQAPgTAAggQAAghgRgSQgMgPgTgCIAAgnQAjABAaAWQAgAeAAA2QAAA0geAeQgaAZglACgAhEBRQgdgeAAgzQAAg2AggdQAZgXAlgBIAAAnQgUACgNAPQgRASAAAhQAAAfAQATQANAQAVACIAAApQgngDgagZg");
	this.shape_6.setTransform(-42.25,0.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgVBnIAAjNIAqAAIAADNgAAehAIAAgmIAxAAIAAAmgAhOhAIAAgmIAxAAIAAAmg");
	this.shape_7.setTransform(-61.325,0.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAkBnIAAjNIArAAIAADNgAhBAOQgOgQAAghIAAhDIArAAIAABDQAAAUAJAHQAGAFARAAQALAAAUgGIAAAmQgWAGgUAAQgkAAgOgVg");
	this.shape_8.setTransform(-79.5,0.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93.8,-22.4,187.6,44.9);


(lib.Символ2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Eg5fAHqIAAvTMBy/AAAIAAPTg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-367.9,-49,735.9,98);


(lib.Символ11копия2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.brovka();
	this.instance.parent = this;
	this.instance.setTransform(0,1.05,0.2509,0.2509,-1.4809);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ11копия2_1, new cjs.Rectangle(0,0,41.4,19.4), null);


(lib.Символ3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgWBpIAAgqIAnAAIAAAqgAgUAwIAAgUQABgPAHgLQAGgGAKgHIARgOQAIgHgBgLQABgMgIgHQgHgGgLgCIAAgiQAiACARAUQAQAPAAAVQAAAUgJANQgGAJgNAIIgTANQgJAIAAALIAAAMgAhFgpQAAgSAMgRQARgaAkgCIAAAiQgdADAAAmg");
	this.shape.setTransform(234.7,-0.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYBnIAAgmIAaAAQARAAAJgIQAJgIAAgQQAAgfgjAAIgaAAIAAgiIAfAAQBGAAAABBQAAAdgQATQgSAWgmAAgAhMBnIAAjNIArAAIAADNgAgYhAIAAgmIBTAAIAAAmg");
	this.shape_1.setTransform(218.375,0.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhDBnIAAjNIArAAIAADNgAgPhAIAAgmIBTAAIAAAmg");
	this.shape_2.setTransform(201.575,0.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAoBnIAAjNIArAAIAADNgAhSBnIAAjNIArAAIAADNgAgeASIA+hpIAABHIg+Bpg");
	this.shape_3.setTransform(176.375,0.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAoBnIAAhZIgkAAIAAglIAkAAIAAhPIArAAIAADNgAhSBnIAAjNIArAAIAABPIAkAAIAAAlIgkAAIAABZg");
	this.shape_4.setTransform(149.625,0.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAoBnIAAjNIArAAIAADNgAhSBnIAAjNIArAAIAADNgAgeASIA+hpIAABHIg+Bpg");
	this.shape_5.setTransform(129.475,0.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AA4BnIAAhIIAphtIAAC1gAgTBnIhNjNIApAAIBLDNgAhgBnIAAi1IApBsIAABJgAAFAlIAziLIApAAIhIDBg");
	this.shape_6.setTransform(108.075,0.075);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAoBnIAAjNIArAAIAADNgAhSBnIAAjNIArAAIAADNgAgeASIA+hpIAABHIg+Bpg");
	this.shape_7.setTransform(79.875,0.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AA4BnIAAhIIAphtIAAC1gAgTBnIhNjNIApAAIBLDNgAhgBnIAAi1IApBsIAABJgAAFAlIAziLIApAAIhIDBg");
	this.shape_8.setTransform(58.475,0.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAoBnIAAjNIArAAIAADNgAhSBnIAAjNIArAAIAADNgAgeASIA+hpIAABHIg+Bpg");
	this.shape_9.setTransform(36.925,0.075);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAoBnIAAhZIgkAAIAAglIAkAAIAAhPIArAAIAADNgAhSBnIAAjNIArAAIAABPIAkAAIAAAlIgkAAIAABZg");
	this.shape_10.setTransform(16.825,0.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AA4BnIAAgmIAaAAIAAinIArAAIAADNgAguBnIAAgmIAaAAIAAinIAqAAIAACnIAZAAIAAAmgAh8BnIAAjNIArAAIAACnIAaAAIAAAmg");
	this.shape_11.setTransform(-7.425,0.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAoBnIAAjNIArAAIAADNgAhSBnIAAjNIArAAIAADNgAgeASIA+hpIAABHIg+Bpg");
	this.shape_12.setTransform(-31.675,0.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAuBnIAAinIgZAAIAAgmIBEAAIAADNgAhYBBQAXAAAGgWQADgPAAg1IAAhNIBEAAIAAAmIgYAAIAAAsQgBAogDAVQgDAVgKAOQgUAbgnAAg");
	this.shape_13.setTransform(-52.4,0.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAIBEQAigCAMglIAoATQgZA6g9ADgAhFBMQgYgeAAguQAAg2AfgdQAZgXAlgBIAAAnQgWACgNARQgOATAAAeQAAAcANATQANATAXACIAAApQgrgCgagfgAAlg3QgMgLgRgCIAAgnQA5ACAaA3IgnASQgEgNgLgKg");
	this.shape_14.setTransform(-78.575,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93.8,-22.4,341.8,44.9);


(lib.boss_2копия4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhPBxIBGgiIBeATIgJAugAhxBqIAKguIBXgqQAqgUAOgMQAOgMAEgUQACgOgGgOQgHgPgPgGIAJgsQAqALASAdQASAcgHAlQgGAdgYAUQgSAPgiARIiAA+gAhQg1IAFgVQAGgfAbgVQAfgXApAIIgJAsQgRgBgMAKQgOALgDAQIgEAYg");
	this.shape.setTransform(329.3853,379.8828);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgwB9IAKgwIByAXIgKAwgAhxBvIA0kCIA2ALIg0ECgAgbAQIAKguIBpAWIgKAugAgFhVIAJgxIBuAXIgJAwg");
	this.shape_1.setTransform(308.5,375.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgWB+IAKgwIBjAVIgKAwgAhWBxIA1kDIA1ALIg0EDg");
	this.shape_2.setTransform(286.3,370.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgxB9IALgwIByAXIgKAwgAhyBvIA1kCIA2ALIg1ECgAgaAQIAJguIBpAWIgKAugAgGhVIAJgxIBwAXIgKAwg");
	this.shape_3.setTransform(267.25,366.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhKCEIA1kDIA1ALIg0EDgAAhhBIAKgxIA+ANIgKAwgAhohdIAKgxIA+ANIgKAwg");
	this.shape_4.setTransform(247.725,361.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AA9CFIgnkVIA5AMIAmEVgAh0BhICBjhIALBPIgrBQIA4ALIAGAvIhVgSIgVAlg");
	this.shape_5.setTransform(346.425,344.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ABXCYIgziBIALgwIBchRIA/AMIh1BhIBDCjgAgzB8IA0kDIA2ALIg1EDgAjJBdIB9h6IhFiIIA/ANIA2BwIgLAwIhgBjg");
	this.shape_6.setTransform(318.625,337.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhzB8IA1kCIA2ALIg1ECgAADA7IgjgHIAJgtIAdAGQAsAJAJgrQAEgTgKgNQgIgMgVgFIgegGIAIgtIAjAHQAwAKATAfQARAbgIAkQgIAngaATQgVAOgcAAQgNAAgOgDg");
	this.shape_7.setTransform(289.0172,330.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAYCMIA1kDIA2AMIg1ECgAiCBsIA1kCIA2ALIg1ECgAgrAPIBph1IgSBZIhpB0g");
	this.shape_8.setTransform(265.2,326.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgHCLIgngIIAKgwIAjAHQAUAEANgIQAOgIAEgTQAIgngsgJIgigHIAJgrIAoAIQBYASgRBSQgIAlgYATQgUARgeAAQgMAAgNgDgAhvB2IA1kDIA2ALIg1EDgAgDhPIAJgwIBqAVIgKAxg");
	this.shape_9.setTransform(240.575,320.9743);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_1
	this.instance = new lib.ded1();
	this.instance.parent = this;
	this.instance.setTransform(87.4,58.35,1.5411,1.5411);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(87.4,58.4,793.7,403.8);


(lib.boss_2копия3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhPBxIBGgiIBeATIgJAugAhxBqIAKguIBXgqQAqgUAOgMQAOgMAEgUQACgOgGgOQgHgPgPgGIAJgsQAqALASAdQASAcgHAlQgGAdgYAUQgSAPgiARIiAA+gAhQg1IAFgVQAGgfAbgVQAfgXApAIIgJAsQgRgBgMAKQgOALgDAQIgEAYg");
	this.shape.setTransform(329.3853,379.8828);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgwB9IAKgwIByAXIgKAwgAhxBvIA0kCIA2ALIg0ECgAgbAQIAKguIBpAWIgKAugAgFhVIAJgxIBuAXIgJAwg");
	this.shape_1.setTransform(308.5,375.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgWB+IAKgwIBjAVIgKAwgAhWBxIA1kDIA1ALIg0EDg");
	this.shape_2.setTransform(286.3,370.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgxB9IALgwIByAXIgKAwgAhyBvIA1kCIA2ALIg1ECgAgaAQIAJguIBpAWIgKAugAgGhVIAJgxIBwAXIgKAwg");
	this.shape_3.setTransform(267.25,366.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhKCEIA1kDIA1ALIg0EDgAAhhBIAKgxIA+ANIgKAwgAhohdIAKgxIA+ANIgKAwg");
	this.shape_4.setTransform(247.725,361.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AA9CFIgnkVIA5AMIAmEVgAh0BhICBjhIALBPIgrBQIA4ALIAGAvIhVgSIgVAlg");
	this.shape_5.setTransform(346.425,344.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ABXCYIgziBIALgwIBchRIA/AMIh1BhIBDCjgAgzB8IA0kDIA2ALIg1EDgAjJBdIB9h6IhFiIIA/ANIA2BwIgLAwIhgBjg");
	this.shape_6.setTransform(318.625,337.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhzB8IA1kCIA2ALIg1ECgAADA7IgjgHIAJgtIAdAGQAsAJAJgrQAEgTgKgNQgIgMgVgFIgegGIAIgtIAjAHQAwAKATAfQARAbgIAkQgIAngaATQgVAOgcAAQgNAAgOgDg");
	this.shape_7.setTransform(289.0172,330.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAYCMIA1kDIA2AMIg1ECgAiCBsIA1kCIA2ALIg1ECgAgrAPIBph1IgSBZIhpB0g");
	this.shape_8.setTransform(265.2,326.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgHCLIgngIIAKgwIAjAHQAUAEANgIQAOgIAEgTQAIgngsgJIgigHIAJgrIAoAIQBYASgRBSQgIAlgYATQgUARgeAAQgMAAgNgDgAhvB2IA1kDIA2ALIg1EDgAgDhPIAJgwIBqAVIgKAxg");
	this.shape_9.setTransform(240.575,320.9743);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_1
	this.instance = new lib.ded1_Gil();
	this.instance.parent = this;
	this.instance.setTransform(87.4,58.35,1.5411,1.5411);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(87.4,58.4,793.7,403.8);


(lib.Символ15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Символ10("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.2,-20,180.4,40);


(lib.Символ14копия2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Символ11копия2("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-89.2,-19,178.4,38);


(lib.Символ14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Символ11("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.2,-20,180.4,40);


(lib.Символ13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Символ12("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.2,-19.9,180.4,39.9);


(lib.Символ30копия4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EAXyAmjIAA/BIh/AAMAAAgtNIFmAAIAABSILMAAMAAABK8gEgmkAbtMAAAhCPIOPAAMAAABCPg");
	this.shape.setTransform(-19.3,20.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// brovka
	this.instance = new lib.Символ11копия2_1();
	this.instance.parent = this;
	this.instance.setTransform(-19.25,-123,0.6122,0.6122,0,0,0,20.4,9.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Слой_1
	this.instance_1 = new lib._DedNEW_728x90();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-177.05,-200.15,0.5593,0.5593);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-266.2,-226.2,493.79999999999995,493.4);


(lib.Символ30копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CD1277").s().p("EAVYAmIIAA/BIh/AAMAAAgtOIFmAAIAABSILMAAMAAABK9gEgkKAhQMAAAhCPIOPAAMAAABCPg");
	this.shape.setTransform(-34.675,-15.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// brovka
	this.instance = new lib.Символ11копия2_1();
	this.instance.parent = this;
	this.instance.setTransform(-19.25,-123,0.6122,0.6122,0,0,0,20.4,9.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Слой_1
	this.instance_1 = new lib._dedNew_728x90_Gil();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-177.05,-200.15,0.5593,0.5593);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-266.2,-259,463.1,487.9);


(lib.visualкопия4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgGTAm3MAAAhNtIMnAAMAAABNtg");
	this.shape.setTransform(907.95,211.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(662));

	// boss_2
	this.instance = new lib.boss_2копия4("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(984.4,1264.45,1.039,1.039,0,0,0,960,1279.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(284).to({_off:false},0).wait(378));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(77.8,-36.9,870.6,497.4);


(lib.visualкопия3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CD1277").s().p("EgFcAswMAAAhZfIK5AAMAAABZfg");
	this.shape.setTransform(920.25,246.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(662));

	// boss_2
	this.instance = new lib.boss_2копия3("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(984.4,1264.45,1.039,1.039,0,0,0,960,1279.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(284).to({_off:false},0).wait(378));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(77.8,-39.7,877.4000000000001,572.8000000000001);


(lib.Символ20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ramka_1
	this.instance = new lib.Символ9("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(99.85,-97.5,0.6802,0.6802);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},16,cjs.Ease.quadInOut).wait(16).to({startPosition:0},0).to({y:-109.4,alpha:0},11,cjs.Ease.quadIn).wait(251).to({startPosition:0},0).to({_off:true},1).wait(88));

	// Zabit
	this.instance_1 = new lib.Символ16("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(99.85,-97.5,0.6802,0.6802);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:1},16,cjs.Ease.quadInOut).wait(16).to({startPosition:0},0).to({y:-109.4,alpha:0},11,cjs.Ease.quadIn).wait(251).to({startPosition:0},0).to({_off:true},1).wait(88));

	// Ramka_2
	this.instance_2 = new lib.Символ15("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(99.85,-86.65,0.6802,0.6802);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(42).to({_off:false},0).to({y:-97.6,alpha:1},11,cjs.Ease.quadOut).wait(19).to({startPosition:0},0).to({regY:-0.1,y:-110.5,alpha:0},10,cjs.Ease.quadIn).wait(212).to({startPosition:0},0).to({_off:true},1).wait(88));

	// Podarit
	this.instance_3 = new lib.Символ17("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(99.85,-86.35,0.6802,0.6802,0,0,0,0,-0.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(42).to({_off:false},0).to({y:-97.3,alpha:1},11,cjs.Ease.quadOut).wait(19).to({startPosition:0},0).to({regY:0,y:-110.15,alpha:0},10,cjs.Ease.quadIn).wait(212).to({startPosition:0},0).to({_off:true},1).wait(88));

	// Prodat
	this.instance_4 = new lib.Символ19("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(99.85,-86.1,0.6802,0.6802);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(81).to({_off:false},0).to({y:-97.5,alpha:1},10,cjs.Ease.quadInOut).wait(58).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(134).to({startPosition:0},0).to({_off:true},1).wait(88));

	// Ramka_3___копия
	this.instance_5 = new lib.Символ14копия2("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(99.85,-97.5,0.6802,0.6802);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(104).to({_off:false},0).to({alpha:1},10,cjs.Ease.quadInOut).wait(35).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(134).to({startPosition:0},0).to({_off:true},1).wait(88));

	// Ramka_3
	this.instance_6 = new lib.Символ14("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(99.85,-86.05,0.6802,0.6802);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(81).to({_off:false},0).to({y:-97.5,alpha:1},10,cjs.Ease.quadInOut).wait(58).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(134).to({startPosition:0},0).to({_off:true},1).wait(88));

	// Ramka_4
	this.instance_7 = new lib.Символ13("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(99.85,2,0.6802,0.6802);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(32).to({_off:false},0).wait(49).to({startPosition:0},0).wait(9).to({startPosition:0},0).wait(204).to({startPosition:0},0).to({_off:true},1).wait(88));

	// Potratit
	this.instance_8 = new lib.Символ18("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(99.85,2.8,0.6802,0.6802);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(32).to({_off:false},0).wait(57).to({startPosition:0},0).to({alpha:0.3594},10,cjs.Ease.quadInOut).wait(195).to({startPosition:0},0).to({_off:true},1).wait(88));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(31,-138.5,140,154.4);


(lib.Символ1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// SubLineLast
	this.instance = new lib.Символ26("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-39.2,-5.25,0.9638,0.9638,0,0,0,-0.1,-0.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(331).to({_off:false},0).to({alpha:1},10,cjs.Ease.quadInOut).wait(36).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(44).to({startPosition:0},0).to({_off:true},1).wait(78));

	// SubLine2
	this.instance_1 = new lib.Символ24("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-70.3,9.9,0.9711,0.9711,0,0,0,-0.1,-0.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(275).to({_off:false},0).to({alpha:1},10,cjs.Ease.quadInOut).wait(42).to({startPosition:0},0).to({alpha:0},10,cjs.Ease.quadInOut).wait(95).to({startPosition:0},0).to({_off:true},1).wait(4).to({_off:false},0).to({_off:true},23).wait(2).to({_off:false},0).to({alpha:1},10,cjs.Ease.quadInOut).wait(17).to({startPosition:0},0).to({_off:true},1).wait(21));

	// SubLine1
	this.instance_2 = new lib.Символ23("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-51.1,1.1,0.9711,0.9711,0,0,0,-0.2,-0.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(273).to({_off:false},0).to({alpha:1},10,cjs.Ease.quadInOut).wait(44).to({startPosition:0},0).to({alpha:0},10,cjs.Ease.quadInOut).wait(95).to({startPosition:0},0).to({_off:true},1).wait(4).to({_off:false},0).wait(23).to({startPosition:0},0).to({alpha:1},10,cjs.Ease.quadInOut).wait(19).to({startPosition:0},0).to({_off:true},1).wait(21));

	// Menu
	this.instance_3 = new lib.Символ20("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(6.55,98.45);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(105).to({_off:false},0).to({_off:true},295).wait(111));

	// Button
	this.instance_4 = new lib.Символ6("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(204,1.7,0.6701,0.6701,0,0,0,0.1,0.1);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(27).to({_off:false},0).to({regX:0,regY:0,scaleX:0.9299,scaleY:0.9299,x:203.95,y:1.65,alpha:1},12,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,scaleX:0.8869,scaleY:0.8869,x:204.05,y:1.75},5,cjs.Ease.quadInOut).wait(37).to({startPosition:0},0).to({alpha:0},13,cjs.Ease.quadInOut).wait(184).to({scaleX:0.6701,scaleY:0.6701,x:208.35,y:1.7},0).to({regX:0,regY:0,scaleX:0.9299,scaleY:0.9299,x:208.3,y:1.65,alpha:1},12,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,scaleX:0.8869,scaleY:0.8869,x:208.4,y:1.75},5,cjs.Ease.quadInOut).wait(82).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(44).to({startPosition:0},0).to({_off:true},1).wait(4).to({_off:false},0).wait(20).to({scaleX:0.6701,scaleY:0.6701,x:204,y:1.7},0).to({regX:0,regY:0,scaleX:0.9299,scaleY:0.9299,x:203.95,y:1.65,alpha:1},12,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,scaleX:0.8869,scaleY:0.8869,x:204.05,y:1.75},5,cjs.Ease.quadInOut).wait(15).to({startPosition:0},0).to({_off:true},1).wait(21));

	// Mask2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_25 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_85 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_86 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_87 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_88 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_89 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_90 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_91 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_92 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_93 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_94 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_95 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_96 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_97 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_98 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_99 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_100 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_101 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_102 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_103 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_104 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_105 = new cjs.Graphics().p("A2uB1IAAjmMArXAAAIAADmg");
	var mask_graphics_106 = new cjs.Graphics().p("A3yB1IAAjmMArXAAAIAADmg");
	var mask_graphics_107 = new cjs.Graphics().p("A4sB1IAAjmMArXAAAIAADmg");
	var mask_graphics_108 = new cjs.Graphics().p("A5eB1IAAjmMArXAAAIAADmg");
	var mask_graphics_109 = new cjs.Graphics().p("A6HB1IAAjmMArYAAAIAADmg");
	var mask_graphics_110 = new cjs.Graphics().p("A6mB1IAAjmMArXAAAIAADmg");
	var mask_graphics_111 = new cjs.Graphics().p("A69B1IAAjmMArXAAAIAADmg");
	var mask_graphics_112 = new cjs.Graphics().p("A7KB1IAAjmMArXAAAIAADmg");
	var mask_graphics_113 = new cjs.Graphics().p("A7PB1IAAjmMArXAAAIAADmg");
	var mask_graphics_256 = new cjs.Graphics().p("A7PB1IAAjmMArXAAAIAADmg");
	var mask_graphics_257 = new cjs.Graphics().p("A7JB1IAAjmMArXAAAIAADmg");
	var mask_graphics_258 = new cjs.Graphics().p("A63B1IAAjmMArXAAAIAADmg");
	var mask_graphics_259 = new cjs.Graphics().p("A6ZB1IAAjmMArXAAAIAADmg");
	var mask_graphics_260 = new cjs.Graphics().p("A5vB1IAAjmMArXAAAIAADmg");
	var mask_graphics_261 = new cjs.Graphics().p("A45B1IAAjmMArXAAAIAADmg");
	var mask_graphics_262 = new cjs.Graphics().p("A33B1IAAjmMArXAAAIAADmg");
	var mask_graphics_263 = new cjs.Graphics().p("A2pB1IAAjmMArXAAAIAADmg");
	var mask_graphics_264 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_265 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_266 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_267 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_268 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_269 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_270 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_271 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_272 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_273 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_274 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_275 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");
	var mask_graphics_432 = new cjs.Graphics().p("A1rB1IAAjmMArXAAAIAADmg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(25).to({graphics:mask_graphics_25,x:3.6127,y:11.7088}).wait(60).to({graphics:mask_graphics_85,x:3.6127,y:11.7088}).wait(1).to({graphics:mask_graphics_86,x:3.871,y:11.7088}).wait(1).to({graphics:mask_graphics_87,x:4.646,y:11.7088}).wait(1).to({graphics:mask_graphics_88,x:5.9377,y:11.7088}).wait(1).to({graphics:mask_graphics_89,x:7.2293,y:11.7088}).wait(1).to({graphics:mask_graphics_90,x:8.0043,y:11.7088}).wait(1).to({graphics:mask_graphics_91,x:8.2627,y:11.7088}).wait(1).to({graphics:mask_graphics_92,x:7.361,y:11.7088}).wait(1).to({graphics:mask_graphics_93,x:4.6561,y:11.7088}).wait(1).to({graphics:mask_graphics_94,x:0.1478,y:11.7088}).wait(1).to({graphics:mask_graphics_95,x:-6.1638,y:11.7088}).wait(1).to({graphics:mask_graphics_96,x:-14.2786,y:11.7088}).wait(1).to({graphics:mask_graphics_97,x:-24.1968,y:11.7088}).wait(1).to({graphics:mask_graphics_98,x:-35.9183,y:11.7088}).wait(1).to({graphics:mask_graphics_99,x:-49.4431,y:11.7088}).wait(1).to({graphics:mask_graphics_100,x:-64.7712,y:11.7088}).wait(1).to({graphics:mask_graphics_101,x:-81.9026,y:11.7088}).wait(1).to({graphics:mask_graphics_102,x:-100.8373,y:11.7088}).wait(1).to({graphics:mask_graphics_103,x:-119.772,y:11.7088}).wait(1).to({graphics:mask_graphics_104,x:-136.9034,y:11.7088}).wait(1).to({graphics:mask_graphics_105,x:-145.5207,y:11.7088}).wait(1).to({graphics:mask_graphics_106,x:-152.2831,y:11.7088}).wait(1).to({graphics:mask_graphics_107,x:-158.1439,y:11.7088}).wait(1).to({graphics:mask_graphics_108,x:-163.103,y:11.7088}).wait(1).to({graphics:mask_graphics_109,x:-167.1604,y:11.7088}).wait(1).to({graphics:mask_graphics_110,x:-170.3162,y:11.7088}).wait(1).to({graphics:mask_graphics_111,x:-172.5703,y:11.7088}).wait(1).to({graphics:mask_graphics_112,x:-173.9228,y:11.7088}).wait(1).to({graphics:mask_graphics_113,x:-174.3736,y:11.7088}).wait(143).to({graphics:mask_graphics_256,x:-174.3736,y:11.7088}).wait(1).to({graphics:mask_graphics_257,x:-173.7744,y:11.7088}).wait(1).to({graphics:mask_graphics_258,x:-171.9769,y:11.7088}).wait(1).to({graphics:mask_graphics_259,x:-168.9811,y:11.7088}).wait(1).to({graphics:mask_graphics_260,x:-164.7869,y:11.7088}).wait(1).to({graphics:mask_graphics_261,x:-159.3944,y:11.7088}).wait(1).to({graphics:mask_graphics_262,x:-152.8035,y:11.7088}).wait(1).to({graphics:mask_graphics_263,x:-145.0143,y:11.7088}).wait(1).to({graphics:mask_graphics_264,x:-133.2437,y:11.7088}).wait(1).to({graphics:mask_graphics_265,x:-112.872,y:11.7088}).wait(1).to({graphics:mask_graphics_266,x:-90.7027,y:11.7088}).wait(1).to({graphics:mask_graphics_267,x:-70.331,y:11.7088}).wait(1).to({graphics:mask_graphics_268,x:-52.3559,y:11.7088}).wait(1).to({graphics:mask_graphics_269,x:-36.7775,y:11.7088}).wait(1).to({graphics:mask_graphics_270,x:-23.5958,y:11.7088}).wait(1).to({graphics:mask_graphics_271,x:-12.8107,y:11.7088}).wait(1).to({graphics:mask_graphics_272,x:-4.4224,y:11.7088}).wait(1).to({graphics:mask_graphics_273,x:1.5693,y:11.7088}).wait(1).to({graphics:mask_graphics_274,x:5.1643,y:11.7088}).wait(1).to({graphics:mask_graphics_275,x:6.3627,y:11.7088}).wait(157).to({graphics:mask_graphics_432,x:6.3627,y:11.7088}).wait(1).to({graphics:null,x:0,y:0}).wait(78));

	// HeadLine2
	this.instance_5 = new lib.Символ3("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(-61.6,33.65,0.8054,0.8054);
	this.instance_5._off = true;

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(25).to({_off:false},0).to({y:14.3},11,cjs.Ease.quadInOut).wait(49).to({startPosition:0},0).to({x:-56.95},6,cjs.Ease.quadInOut).to({x:-275.15},22,cjs.Ease.quadInOut).wait(143).to({startPosition:0},0).to({x:-58.85,alpha:0},19,cjs.Ease.quadInOut).wait(157).to({startPosition:0},0).to({_off:true},1).wait(78));

	// Mask1 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_23 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_85 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_86 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_87 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_88 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_89 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_90 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_91 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_92 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_93 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_94 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_95 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_96 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_97 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_98 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_99 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_100 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_101 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_102 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_103 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_104 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_105 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_106 = new cjs.Graphics().p("A3yBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_107 = new cjs.Graphics().p("A4tBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_108 = new cjs.Graphics().p("A5eBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_109 = new cjs.Graphics().p("A6HBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_110 = new cjs.Graphics().p("A6mBzIAAjlMAusAAAIAADlg");
	var mask_1_graphics_111 = new cjs.Graphics().p("A69BzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_112 = new cjs.Graphics().p("A7KBzIAAjlMAusAAAIAADlg");
	var mask_1_graphics_113 = new cjs.Graphics().p("A7PBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_256 = new cjs.Graphics().p("A7PBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_257 = new cjs.Graphics().p("A7JBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_258 = new cjs.Graphics().p("A63BzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_259 = new cjs.Graphics().p("A6ZBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_260 = new cjs.Graphics().p("A5vBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_261 = new cjs.Graphics().p("A45BzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_262 = new cjs.Graphics().p("A33BzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_263 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_264 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_265 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_266 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_267 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_268 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_269 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_270 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_271 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_272 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_273 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_274 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_275 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");
	var mask_1_graphics_432 = new cjs.Graphics().p("A3WBzIAAjlMAutAAAIAADlg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(23).to({graphics:mask_1_graphics_23,x:14.2598,y:-9.3701}).wait(62).to({graphics:mask_1_graphics_85,x:14.2598,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_86,x:14.5181,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_87,x:15.2931,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_88,x:16.5848,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_89,x:17.8765,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_90,x:18.6515,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_91,x:18.9098,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_92,x:18.0082,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_93,x:15.3032,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_94,x:10.7949,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_95,x:4.4834,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_96,x:-3.6315,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_97,x:-13.5497,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_98,x:-25.2712,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_99,x:-38.796,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_100,x:-54.1241,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_101,x:-71.2555,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_102,x:-90.1902,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_103,x:-109.1249,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_104,x:-126.2563,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_105,x:-141.5844,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_106,x:-152.2967,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_107,x:-158.1574,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_108,x:-163.1165,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_109,x:-167.1739,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_110,x:-170.3297,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_111,x:-172.5838,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_112,x:-173.9363,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_113,x:-174.3871,y:-9.3701}).wait(143).to({graphics:mask_1_graphics_256,x:-174.3871,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_257,x:-173.788,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_258,x:-171.9905,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_259,x:-168.9946,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_260,x:-164.8004,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_261,x:-159.4079,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_262,x:-152.8171,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_263,x:-140.5716,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_264,x:-122.5966,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_265,x:-102.2248,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_266,x:-80.0556,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_267,x:-59.6838,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_268,x:-41.7088,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_269,x:-26.1304,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_270,x:-12.9486,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_271,x:-2.1636,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_272,x:6.2248,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_273,x:12.2165,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_274,x:15.8115,y:-9.3701}).wait(1).to({graphics:mask_1_graphics_275,x:17.0098,y:-9.3701}).wait(157).to({graphics:mask_1_graphics_432,x:17.0098,y:-9.3701}).wait(1).to({graphics:null,x:0,y:0}).wait(78));

	// HeadLine1
	this.instance_6 = new lib.Символ5("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-61.6,12.05,0.8054,0.8054);
	this.instance_6._off = true;

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(23).to({_off:false},0).to({y:-9.85},11,cjs.Ease.quadInOut).wait(51).to({startPosition:0},0).to({x:-56.95},6,cjs.Ease.quadInOut).to({x:-275.15},22,cjs.Ease.quadInOut).wait(143).to({startPosition:0},0).to({x:-58.85,alpha:0},19,cjs.Ease.quadInOut).wait(157).to({startPosition:0},0).to({_off:true},1).wait(78));

	// Logo
	this.instance_7 = new lib.Символ8("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(347.25,11.6,0.718,0.718,0,0,0,35.2,12.2);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(18).to({_off:false},0).to({scaleX:0.935,scaleY:0.935,x:347.35,y:11.7,alpha:1},12,cjs.Ease.quadInOut).to({regX:35.1,scaleX:0.8814,scaleY:0.8814,x:347.2,y:11.65},5,cjs.Ease.quadInOut).wait(50).to({startPosition:0},0).wait(6).to({startPosition:0},0).wait(22).to({startPosition:0},0).wait(264).to({startPosition:0},0).to({alpha:0},11,cjs.Ease.quadInOut).wait(44).to({startPosition:0},0).to({_off:true},1).wait(21).to({_off:false,regX:35.2,scaleX:0.718,scaleY:0.718,x:347.25,y:11.6},0).to({scaleX:0.935,scaleY:0.935,x:347.35,y:11.7,alpha:1},12,cjs.Ease.quadInOut).to({regX:35.1,scaleX:0.8814,scaleY:0.8814,x:347.2,y:11.65},5,cjs.Ease.quadInOut).wait(18).to({startPosition:0},0).to({_off:true},1).wait(21));

	// Black
	this.instance_8 = new lib.Символ2("synched",0);
	this.instance_8.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({regX:0.4,regY:0.1,scaleX:0.6691,scaleY:0.7552,x:106.8,y:1.05},19,cjs.Ease.quadInOut).to({regX:0.3,scaleX:0.6805,x:106.75},9,cjs.Ease.quadInOut).wait(57).to({startPosition:0},0).to({regX:0.4,scaleX:0.6691,x:106.8},6,cjs.Ease.quadInOut).to({scaleX:0.9672,x:1.45},22,cjs.Ease.quadInOut).wait(143).to({startPosition:0},0).to({scaleX:0.6691,x:106.8},19,cjs.Ease.quadInOut).to({regX:0.3,scaleX:0.6805,x:106.75},9,cjs.Ease.quadInOut).wait(98).to({startPosition:0},0).to({regX:0.2,regY:0.3,scaleX:1.0455,scaleY:0.9252,x:-14.75,y:1.15},16,cjs.Ease.quadInOut).wait(34).to({startPosition:0},0).to({_off:true},1).wait(4).to({_off:false,regX:0,regY:0,scaleX:0.9982,scaleY:0.9986,x:0.6,y:0},0).wait(1).to({scaleX:0.9925,scaleY:0.9945,x:2.4253,y:0.0183},0).wait(1).to({scaleX:0.9834,scaleY:0.9877,x:5.3709,y:0.0478},0).wait(1).to({scaleX:0.9704,scaleY:0.9781,x:9.5611,y:0.0897},0).wait(1).to({scaleX:0.9532,scaleY:0.9654,x:15.1005,y:0.1452},0).wait(1).to({scaleX:0.9317,scaleY:0.9495,x:22.0372,y:0.2147},0).wait(1).to({scaleX:0.9061,scaleY:0.9305,x:30.3093,y:0.2975},0).wait(1).to({scaleX:0.877,scaleY:0.909,x:39.6872,y:0.3914},0).wait(1).to({scaleX:0.8459,scaleY:0.886,x:49.7475,y:0.4921},0).wait(1).to({scaleX:0.8143,scaleY:0.8626,x:59.9255,y:0.5941},0).wait(1).to({scaleX:0.7842,scaleY:0.8403,x:69.6438,y:0.6914},0).wait(1).to({scaleX:0.7569,scaleY:0.8201,x:78.4459,y:0.7795},0).wait(1).to({scaleX:0.7333,scaleY:0.8027,x:86.0604,y:0.8558},0).wait(1).to({scaleX:0.7137,scaleY:0.7882,x:92.386,y:0.9191},0).wait(1).to({scaleX:0.6981,scaleY:0.7766,x:97.4379,y:0.9697},0).wait(1).to({scaleX:0.6861,scaleY:0.7678,x:101.2957,y:1.0083},0).wait(1).to({scaleX:0.6775,scaleY:0.7614,x:104.0657,y:1.0361},0).wait(1).to({scaleX:0.672,scaleY:0.7573,x:105.8598,y:1.054},0).wait(1).to({regX:0.4,regY:0.1,scaleX:0.6691,scaleY:0.7552,x:106.8,y:1.05},0).to({regX:0.3,scaleX:0.6805,x:106.75},9,cjs.Ease.quadInOut).wait(25).to({startPosition:0},0).to({_off:true},1).wait(21));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-399.6,-49,769.4000000000001,163.4);


// stage content:
(lib.Tele2_Flight8_728x90 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_2 = function() {
		this.GIL.compositeOperation = 'multiply';
		this.GIL.compositeOperation = 'multiply';
	}
	this.frame_469 = function() {
		this.GIL.compositeOperation = 'multiply';
		this.GIL.compositeOperation = 'multiply';
	}
	this.frame_518 = function() {
		var banner = this;
		function funcPlay() {
		banner.gotoAndPlay();
		}
		banner.stop();
		setTimeout(funcPlay, 60000);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(467).call(this.frame_469).wait(49).call(this.frame_518).wait(1));

	// LogoEnd
	this.instance = new lib.Символ27("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(364.5,45.3,2.9651,2.9651,0,0,0,0,0.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(387).to({_off:false},0).to({alpha:1},13,cjs.Ease.quadInOut).wait(51).to({startPosition:0},0).to({alpha:0},13).wait(55));

	// Plashka
	this.instance_1 = new lib.Символ1("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(362.95,44.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(432).to({mode:"single",startPosition:432},0).wait(34).to({mode:"synched",startPosition:437},0).wait(53));

	// GIl___копия (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_2 = new cjs.Graphics().p("EgyfgF+MCAegbnMAAABDLg");
	var mask_graphics_3 = new cjs.Graphics().p("EgylgF+MCAegbnMAAABDLg");
	var mask_graphics_4 = new cjs.Graphics().p("Egy4gF+MCAegbnMAAABDLg");
	var mask_graphics_5 = new cjs.Graphics().p("EgzXgF+MCAegbnMAAABDLg");
	var mask_graphics_6 = new cjs.Graphics().p("Eg0EgF+MCAfgbnMAAABDLg");
	var mask_graphics_7 = new cjs.Graphics().p("Eg08gF+MCAegbnMAAABDLg");
	var mask_graphics_8 = new cjs.Graphics().p("Eg2CgF+MCAfgbnMAAABDLg");
	var mask_graphics_9 = new cjs.Graphics().p("Eg3TgF+MCAegbnMAAABDLg");
	var mask_graphics_10 = new cjs.Graphics().p("Eg4ygF+MCAegbnMAAABDLg");
	var mask_graphics_11 = new cjs.Graphics().p("Eg6dgF+MCAegbnMAAABDLg");
	var mask_graphics_12 = new cjs.Graphics().p("Eg8VgF+MCAegbnMAAABDLg");
	var mask_graphics_13 = new cjs.Graphics().p("Eg+MgF+MCAegbnMAAABDLg");
	var mask_graphics_14 = new cjs.Graphics().p("Eg/4gF+MCAfgbnMAAABDLg");
	var mask_graphics_15 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_16 = new cjs.Graphics().p("EhAOgF+MCAegbnMAAABDLg");
	var mask_graphics_17 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_18 = new cjs.Graphics().p("EhAOgF+MCAegbnMAAABDLg");
	var mask_graphics_19 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_20 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_21 = new cjs.Graphics().p("EhAOgF+MCAegbnMAAABDLg");
	var mask_graphics_22 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_23 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_24 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_25 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_26 = new cjs.Graphics().p("EhAPgF+MCAegbnMAAABDLg");
	var mask_graphics_27 = new cjs.Graphics().p("EhAOgF+MCAdgbnMAAABDLg");
	var mask_graphics_28 = new cjs.Graphics().p("EhAOgF+MCAdgbnMAAABDLg");
	var mask_graphics_29 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_30 = new cjs.Graphics().p("EhAOgF+MCAdgbnMAAABDLg");
	var mask_graphics_31 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_469 = new cjs.Graphics().p("EgyfgF+MCAegbnMAAABDLg");
	var mask_graphics_470 = new cjs.Graphics().p("EgylgF+MCAegbnMAAABDLg");
	var mask_graphics_471 = new cjs.Graphics().p("Egy4gF+MCAegbnMAAABDLg");
	var mask_graphics_472 = new cjs.Graphics().p("EgzXgF+MCAegbnMAAABDLg");
	var mask_graphics_473 = new cjs.Graphics().p("Eg0EgF+MCAfgbnMAAABDLg");
	var mask_graphics_474 = new cjs.Graphics().p("Eg08gF+MCAegbnMAAABDLg");
	var mask_graphics_475 = new cjs.Graphics().p("Eg2CgF+MCAfgbnMAAABDLg");
	var mask_graphics_476 = new cjs.Graphics().p("Eg3TgF+MCAegbnMAAABDLg");
	var mask_graphics_477 = new cjs.Graphics().p("Eg4ygF+MCAegbnMAAABDLg");
	var mask_graphics_478 = new cjs.Graphics().p("Eg6dgF+MCAegbnMAAABDLg");
	var mask_graphics_479 = new cjs.Graphics().p("Eg8VgF+MCAegbnMAAABDLg");
	var mask_graphics_480 = new cjs.Graphics().p("Eg+MgF+MCAegbnMAAABDLg");
	var mask_graphics_481 = new cjs.Graphics().p("Eg/4gF+MCAfgbnMAAABDLg");
	var mask_graphics_482 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_483 = new cjs.Graphics().p("EhAOgF+MCAegbnMAAABDLg");
	var mask_graphics_484 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_485 = new cjs.Graphics().p("EhAOgF+MCAegbnMAAABDLg");
	var mask_graphics_486 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_487 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_488 = new cjs.Graphics().p("EhAOgF+MCAegbnMAAABDLg");
	var mask_graphics_489 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_490 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_491 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_492 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_493 = new cjs.Graphics().p("EhAPgF+MCAegbnMAAABDLg");
	var mask_graphics_494 = new cjs.Graphics().p("EhAOgF+MCAdgbnMAAABDLg");
	var mask_graphics_495 = new cjs.Graphics().p("EhAOgF+MCAdgbnMAAABDLg");
	var mask_graphics_496 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");
	var mask_graphics_497 = new cjs.Graphics().p("EhAOgF+MCAdgbnMAAABDLg");
	var mask_graphics_498 = new cjs.Graphics().p("EhAPgF+MCAfgbnMAAABDLg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(2).to({graphics:mask_graphics_2,x:499.125,y:157.125}).wait(1).to({graphics:mask_graphics_3,x:498.5,y:157.125}).wait(1).to({graphics:mask_graphics_4,x:496.6,y:157.125}).wait(1).to({graphics:mask_graphics_5,x:493.45,y:157.125}).wait(1).to({graphics:mask_graphics_6,x:489.05,y:157.125}).wait(1).to({graphics:mask_graphics_7,x:483.375,y:157.125}).wait(1).to({graphics:mask_graphics_8,x:476.45,y:157.125}).wait(1).to({graphics:mask_graphics_9,x:468.25,y:157.125}).wait(1).to({graphics:mask_graphics_10,x:458.8,y:157.125}).wait(1).to({graphics:mask_graphics_11,x:448.1,y:157.125}).wait(1).to({graphics:mask_graphics_12,x:436.125,y:157.125}).wait(1).to({graphics:mask_graphics_13,x:424.15,y:157.125}).wait(1).to({graphics:mask_graphics_14,x:413.45,y:157.125}).wait(1).to({graphics:mask_graphics_15,x:396.85,y:157.125}).wait(1).to({graphics:mask_graphics_16,x:380.45,y:157.125}).wait(1).to({graphics:mask_graphics_17,x:366.6,y:157.125}).wait(1).to({graphics:mask_graphics_18,x:355.25,y:157.125}).wait(1).to({graphics:mask_graphics_19,x:346.45,y:157.125}).wait(1).to({graphics:mask_graphics_20,x:340.15,y:157.125}).wait(1).to({graphics:mask_graphics_21,x:336.35,y:157.125}).wait(1).to({graphics:mask_graphics_22,x:335.1,y:157.125}).wait(1).to({graphics:mask_graphics_23,x:335.3,y:157.125}).wait(1).to({graphics:mask_graphics_24,x:336,y:157.125}).wait(1).to({graphics:mask_graphics_25,x:337.1,y:157.125}).wait(1).to({graphics:mask_graphics_26,x:338.65,y:157.125}).wait(1).to({graphics:mask_graphics_27,x:340.55,y:157.125}).wait(1).to({graphics:mask_graphics_28,x:342.1,y:157.125}).wait(1).to({graphics:mask_graphics_29,x:343.2,y:157.125}).wait(1).to({graphics:mask_graphics_30,x:343.9,y:157.125}).wait(1).to({graphics:mask_graphics_31,x:344.1,y:157.125}).wait(438).to({graphics:mask_graphics_469,x:499.125,y:157.125}).wait(1).to({graphics:mask_graphics_470,x:498.5,y:157.125}).wait(1).to({graphics:mask_graphics_471,x:496.6,y:157.125}).wait(1).to({graphics:mask_graphics_472,x:493.45,y:157.125}).wait(1).to({graphics:mask_graphics_473,x:489.05,y:157.125}).wait(1).to({graphics:mask_graphics_474,x:483.375,y:157.125}).wait(1).to({graphics:mask_graphics_475,x:476.45,y:157.125}).wait(1).to({graphics:mask_graphics_476,x:468.25,y:157.125}).wait(1).to({graphics:mask_graphics_477,x:458.8,y:157.125}).wait(1).to({graphics:mask_graphics_478,x:448.1,y:157.125}).wait(1).to({graphics:mask_graphics_479,x:436.125,y:157.125}).wait(1).to({graphics:mask_graphics_480,x:424.15,y:157.125}).wait(1).to({graphics:mask_graphics_481,x:413.45,y:157.125}).wait(1).to({graphics:mask_graphics_482,x:396.85,y:157.125}).wait(1).to({graphics:mask_graphics_483,x:380.45,y:157.125}).wait(1).to({graphics:mask_graphics_484,x:366.6,y:157.125}).wait(1).to({graphics:mask_graphics_485,x:355.25,y:157.125}).wait(1).to({graphics:mask_graphics_486,x:346.45,y:157.125}).wait(1).to({graphics:mask_graphics_487,x:340.15,y:157.125}).wait(1).to({graphics:mask_graphics_488,x:336.35,y:157.125}).wait(1).to({graphics:mask_graphics_489,x:335.1,y:157.125}).wait(1).to({graphics:mask_graphics_490,x:335.3,y:157.125}).wait(1).to({graphics:mask_graphics_491,x:336,y:157.125}).wait(1).to({graphics:mask_graphics_492,x:337.1,y:157.125}).wait(1).to({graphics:mask_graphics_493,x:338.65,y:157.125}).wait(1).to({graphics:mask_graphics_494,x:340.55,y:157.125}).wait(1).to({graphics:mask_graphics_495,x:342.1,y:157.125}).wait(1).to({graphics:mask_graphics_496,x:343.2,y:157.125}).wait(1).to({graphics:mask_graphics_497,x:343.9,y:157.125}).wait(1).to({graphics:mask_graphics_498,x:344.1,y:157.125}).wait(21));

	// Слой_2
	this.instance_2 = new lib.Символ34("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(152,200.5,1.2585,1,0,0,0,0.1,0);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({alpha:0},18,cjs.Ease.quadInOut).wait(75).to({startPosition:0},0).to({alpha:1},15,cjs.Ease.quadInOut).wait(153).to({startPosition:0},0).to({alpha:0},12,cjs.Ease.quadInOut).wait(196).to({alpha:1},0).to({alpha:0},16,cjs.Ease.quadInOut).wait(34));

	// Ded_1___копия
	this.instance_3 = new lib.Символ30копия("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(143.5,137.55,0.9558,0.9558,0,0,0,0.3,0.5);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(126).to({regX:0.5,scaleX:0.9748,scaleY:0.9748,x:143.7},0).to({_off:true},1).wait(392));

	// vis___копия
	this.instance_4 = new lib.visualкопия3("synched",333);
	this.instance_4.parent = this;
	this.instance_4.setTransform(110.9,119,0.3531,0.3531,0,0,0,419.1,478.7);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(231).to({_off:false},0).wait(216).to({regY:478.8,scaleX:0.39,scaleY:0.39,x:108.9,y:118.2,startPosition:499},0).wait(72));

	// GIl
	this.GIL = new lib.Символ28();
	this.GIL.name = "GIL";
	this.GIL.parent = this;
	this.GIL.setTransform(587.1,157.1);
	this.GIL._off = true;

	this.timeline.addTween(cjs.Tween.get(this.GIL).wait(2).to({_off:false},0).to({x:335.1},20,cjs.Ease.quadInOut).to({x:344.1},9,cjs.Ease.quadInOut).wait(438).to({x:587.1},0).to({x:335.1},20,cjs.Ease.quadInOut).to({x:344.1},9,cjs.Ease.quadInOut).wait(21));

	// white
	this.instance_5 = new lib.Символ29();
	this.instance_5.parent = this;
	this.instance_5.setTransform(118.35,205.75);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:120,alpha:0,mode:"synched",startPosition:0},18,cjs.Ease.quadInOut).wait(75).to({startPosition:0},0).to({x:118.35,alpha:1},15,cjs.Ease.quadInOut).wait(153).to({startPosition:0},0).to({x:120,alpha:0},12,cjs.Ease.quadInOut).wait(196).to({x:118.35,alpha:1,mode:"independent"},0).to({x:120,alpha:0,mode:"synched",startPosition:0},16,cjs.Ease.quadInOut).wait(34));

	// Слой_2
	this.instance_6 = new lib.Символ31("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(337.8,-21.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({_off:true},176).wait(343));

	// Ded_1
	this.instance_7 = new lib.Символ30копия4("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(143.5,137.55,0.9558,0.9558,0,0,0,0.3,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(126).to({regX:0.5,scaleX:0.9748,scaleY:0.9748,x:143.7},0).to({_off:true},1).wait(392));

	// vis
	this.instance_8 = new lib.visualкопия4("synched",333);
	this.instance_8.parent = this;
	this.instance_8.setTransform(110.9,119,0.3531,0.3531,0,0,0,419.1,478.7);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(231).to({_off:false},0).wait(216).to({regY:478.8,scaleX:0.39,scaleY:0.39,x:108.9,y:118.2,startPosition:499},0).wait(72));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(247.7,-65.5,750.5999999999999,484.5);
// library properties:
lib.properties = {
	id: '89679F3F6B5640EAB93E90664031D5E7',
	width: 728,
	height: 90,
	fps: 29,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"Tele2_Flight8_1456x180_atlas_P_.png", id:"Tele2_Flight8_1456x180_atlas_P_"},
		{src:"Tele2_Flight8_1456x180_atlas_NP_.jpg", id:"Tele2_Flight8_1456x180_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['89679F3F6B5640EAB93E90664031D5E7'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
