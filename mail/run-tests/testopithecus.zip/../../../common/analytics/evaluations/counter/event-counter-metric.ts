import { TestopithecusEvent } from '../../../code/mail/logging/testopithecus-event';
import { BaseCounterEvaluation } from './base-counter-evaluation';

export class EventCounterMetric extends BaseCounterEvaluation {

  private readonly eventName: string
  private readonly metricName: string

  constructor(metricName: string, targetName: string = '') {
    super()
    this.eventName = targetName
    this.metricName = metricName
  }

  public name(): string {
    return this.metricName === '' ? this.eventName : this.metricName;
  }

  protected matches(event: TestopithecusEvent): boolean {
    return event.name === this.eventName;
  }

}
