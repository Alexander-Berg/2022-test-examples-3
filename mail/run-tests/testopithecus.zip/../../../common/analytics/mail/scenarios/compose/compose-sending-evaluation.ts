import { EventNames } from '../../../../code/mail/logging/events/event-names';
import { TestopithecusEvent } from '../../../../code/mail/logging/testopithecus-event';
import { Nullable } from '../../../../ys/ys';
import { ContextFreeEvaluation } from '../../../evaluations/general-evaluations/context-free/context-free-evaluation';

export class ComposeSendingEvaluation implements ContextFreeEvaluation<boolean> {

  private sending: Nullable<boolean> = null

  public name(): string {
    return 'sending';
  }

  public acceptEvent(event: TestopithecusEvent): any {
    if (this.sending === null) {
      switch (event.name) {
        case EventNames.COMPOSE_BACK:
          this.sending = false
          break
        case EventNames.COMPOSE_SEND_MESSAGE:
          this.sending = true
          break
      }
    }
  }

  public result(): boolean {
    return this.sending === null ? false : this.sending;
  }

}
