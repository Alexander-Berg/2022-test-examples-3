import { TestopithecusEvent } from '../../../../../code/mail/logging/testopithecus-event'
import { Int64, Nullable } from '../../../../../ys/ys'
import { ParsingUtils } from '../../../../processing/parsing-utils'
import { InitiatorEventEvaluation } from '../../context-free/initiator-event-evaluation'
import { ContextFreeWrapEvaluation } from '../wrap-evaluation'

export class FirstEventTimestampEvaluation extends ContextFreeWrapEvaluation<Nullable<Int64>, Nullable<TestopithecusEvent>> {

  public constructor() {
    super(new InitiatorEventEvaluation())
  }

  public name(): string {
    return 'start_timestamp_ms'
  }

  public wrap(value: Nullable<TestopithecusEvent>): Nullable<Int64> {
    return value === null ? null : ParsingUtils.demandTimestamp(value)
  }

}
