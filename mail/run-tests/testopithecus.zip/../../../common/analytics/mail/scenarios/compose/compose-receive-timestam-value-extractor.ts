import { Int64, Nullable } from '../../../../ys/ys';
import { ComposeMessageDtoValueExtractor } from './compose-message-dto-value-extractor';

export class ComposeReceiveTimestamValueExtractor<T> extends ComposeMessageDtoValueExtractor<Nullable<Int64>> {

  public constructor(evaluationName: string = 'receive_timestamp') {
    super(evaluationName, 'timestamp')
  }

}
