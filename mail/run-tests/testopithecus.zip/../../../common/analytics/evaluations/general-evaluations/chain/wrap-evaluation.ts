import { TestopithecusEvent } from '../../../../code/mail/logging/testopithecus-event';
import { Evaluation } from '../../evaluation';
import { ContextFreeEvaluation } from '../context-free/context-free-evaluation';

export abstract class WrapEvaluation<T, U, C> implements Evaluation<T, C> {

  protected constructor(private parentEvaluation: Evaluation<U, C>) { }

  public acceptEvent(event: TestopithecusEvent, context: C): void {
    this.parentEvaluation.acceptEvent(event, context)
  }

  public abstract name(): string

  public abstract wrap(value: U): T

  public result(): T {
    return this.wrap(this.parentEvaluation.result());
  }

}

export abstract class ContextFreeWrapEvaluation<T, U> extends WrapEvaluation<T, U, null> implements ContextFreeEvaluation<T> {

  public acceptEvent(event: TestopithecusEvent): void {
    super.acceptEvent(event, null)
  }

}
