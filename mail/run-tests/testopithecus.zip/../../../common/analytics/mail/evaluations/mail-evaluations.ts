import { TestopithecusEvent } from '../../../code/mail/logging/testopithecus-event';
import { Nullable } from '../../../ys/ys';
import { Evaluation } from '../../evaluations/evaluation';
import { SingleValueEvaluation } from '../../evaluations/general-evaluations/extraction/single-value-evaluation';
import { MailContext } from '../mail-context';

export interface MailEvaluation<T> extends Evaluation<T, MailContext> {

}

export abstract class MailSingleValueEvaluation<T> extends SingleValueEvaluation<Nullable<T>, MailContext> {

  protected constructor(evaluationName: string) {
    super(evaluationName)
  }

  public abstract extractValue(event: TestopithecusEvent, context: MailContext): T

}
