import { EventNames } from '../../code/mail/logging/events/event-names';
import { TestopithecusEvent } from '../../code/mail/logging/testopithecus-event';
import { EventListScenarioSplitter } from '../evaluations/scenario-splitting/event-list-scenario-splitter';
import { Scenario } from '../scenario';
import { MailEvaluation } from './mail-context-applier';
import { MailContext } from './mail-context';

export class ComposeScenarioSplitter extends EventListScenarioSplitter<MailContext> implements MailEvaluation<Scenario[]> {

  private static startEvents = [
    EventNames.LIST_MESSAGE_WRITE_NEW_MESSAGE,
    EventNames.MESSAGE_ACTION_REPLY,
    EventNames.MESSAGE_ACTION_REPLY_ALL,
  ]
  private static finishEvents = [
    EventNames.COMPOSE_BACK,
    EventNames.COMPOSE_SEND_MESSAGE,
  ]

  constructor() {
    super('compose', ComposeScenarioSplitter.startEvents, ComposeScenarioSplitter.finishEvents)
  }

  public name(): string {
    return 'compose_scenario_splitter';
  }

  public getNewScenarioAttributes(event: TestopithecusEvent, context: MailContext): Map<string, any> {
    const attributes = super.getNewScenarioAttributes(event, context)
    if (context !== null) {
      const messageId = context.currentMessageId
      if (messageId != null) {
        const messageDTO = context.messages.get(messageId)
        if (messageDTO) {
          attributes.set('mid', messageDTO.mid)
          attributes.set('receive_timestamp', messageDTO.timestamp)
        }
      }
    }
    return attributes
  }

  public getEndScenarioAttributes(event: TestopithecusEvent, context: MailContext): Map<string, any> {
    const attributes = super.getEndScenarioAttributes(event, context)
    const result = event.name === EventNames.COMPOSE_SEND_MESSAGE
    attributes.set('success', result)
    return attributes
  }

}
