import { TestopithecusEvent } from '../../../../code/mail/logging/testopithecus-event';
import { Nullable } from '../../../../ys/ys';
import { SingleValueEvaluation } from '../extraction/single-value-evaluation';
import { ContextFreeEvaluation } from './context-free-evaluation';

export abstract class ContextFreeSingleValueEvaluation<T> extends SingleValueEvaluation<Nullable<T>, null> implements ContextFreeEvaluation<Nullable<T>> {

  protected constructor(evaluationName: string) {
    super(evaluationName)
  }

  public acceptEvent(event: TestopithecusEvent): any {
    super.acceptEvent(event, null)
  }

  public abstract extractValue(event: TestopithecusEvent): Nullable<T>

}
