import { TestopithecusEvent } from '../../../../code/mail/logging/testopithecus-event';
import { Nullable } from '../../../../ys/ys';
import { Evaluation } from '../../evaluation';

export abstract class SingleValueEvaluation<T, C> implements Evaluation<Nullable<T>, C> {

  private value: Nullable<T> = null
  private valueSet = false

  protected constructor(private evaluationName: string) { }

  public name(): string {
    return this.evaluationName;
  }

  public acceptEvent(event: TestopithecusEvent, context: C): any {
    if (!this.valueSet) {
      this.value = this.extractValue(event, context)
      this.valueSet = true
    }
  }

  public result(): Nullable<T> {
    return this.value === null ? this.defaultValue() : this.value;
  }

  public defaultValue(): Nullable<T> {
    return null
  }

  public abstract extractValue(event: TestopithecusEvent, context: C): T

}
