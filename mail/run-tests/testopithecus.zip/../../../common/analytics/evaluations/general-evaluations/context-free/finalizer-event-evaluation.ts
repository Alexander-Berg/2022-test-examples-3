import { TestopithecusEvent } from '../../../../code/mail/logging/testopithecus-event';
import { Nullable } from '../../../../ys/ys';
import { ContextFreeEvaluation } from './context-free-evaluation';

export class FinalizerEventEvaluation implements ContextFreeEvaluation<Nullable<TestopithecusEvent>> {

  private lastEvent: Nullable<TestopithecusEvent> = null

  public name(): string {
    return 'finisher';
  }

  public acceptEvent(event: TestopithecusEvent): any {
    this.lastEvent = event
  }

  public result(): Nullable<TestopithecusEvent> {
    return this.lastEvent
  }
}
