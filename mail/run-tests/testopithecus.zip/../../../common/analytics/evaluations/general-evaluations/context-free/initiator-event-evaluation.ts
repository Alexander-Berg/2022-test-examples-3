import { TestopithecusEvent } from '../../../../code/mail/logging/testopithecus-event';
import { ContextFreeSingleValueEvaluation } from './context-free-single-value-evaluation';

export class InitiatorEventEvaluation extends ContextFreeSingleValueEvaluation<TestopithecusEvent> {

  public constructor(evaluationName: string = 'initiator') {
    super(evaluationName)
  }

  public extractValue(event: TestopithecusEvent): TestopithecusEvent {
    return event;
  }

}
