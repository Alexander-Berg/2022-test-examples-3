import { TestopithecusEvent } from '../../../../code/mail/logging/testopithecus-event';
import { Int32, int64, Int64 } from '../../../../ys/ys'
import { ParsingUtils } from '../../../processing/parsing-utils'
import { ContextFreeEvaluation } from './context-free-evaluation';

export class FirstEventEvaluation implements ContextFreeEvaluation<Int64> {

  private eventNumber: Int32 = 0
  private initTimestamp: Int64 = int64(0)
  private timestampDiff: Int64 = int64(0)

  public name(): string {
    return 'first_event';
  }

  public acceptEvent(action: TestopithecusEvent): any {
    const timestamp = ParsingUtils.demandTimestamp(action)
    if (this.eventNumber === 0 && timestamp !== null) {
      this.initTimestamp = timestamp
    } else if (this.eventNumber === 1 && timestamp !== null) {
      this.timestampDiff = timestamp - this.initTimestamp
    }
    this.eventNumber += 1
  }

  public result(): Int64 {
    return this.timestampDiff
  }
}
