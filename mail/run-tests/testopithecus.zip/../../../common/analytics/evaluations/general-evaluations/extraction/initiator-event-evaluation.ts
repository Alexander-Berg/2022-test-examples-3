import { TestopithecusEvent } from '../../../../code/mail/logging/testopithecus-event';
import { ContextFreeSingleValueEvaluation } from '../context-free/context-free-single-value-evaluation';

export class InitiatorEventEvaluation extends ContextFreeSingleValueEvaluation<string> {

  public constructor(evaluationName: string = 'initiator') {
    super(evaluationName)
  }

  public extractValue(event: TestopithecusEvent): string {
    return event.name;
  }

}
