import { TestopithecusEvent } from '../../../code/mail/logging/testopithecus-event';
import { Int32 } from '../../../ys/ys';
import { ContextFreeEvaluation } from '../general-evaluations/default/context-free-evaluation';

export abstract class BaseCounterEvaluation implements ContextFreeEvaluation<Int32> {

  private counter: Int32 = 0

  public abstract name(): string

  public acceptEvent(event: TestopithecusEvent): any {
    if (this.matches(event)) {
      this.counter += 1
    }
  }

  protected abstract matches(event: TestopithecusEvent): boolean

  public result(): Int32 {
    return this.counter;
  }

}
