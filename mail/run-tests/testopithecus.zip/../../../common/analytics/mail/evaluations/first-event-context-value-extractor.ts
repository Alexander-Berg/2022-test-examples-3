import { TestopithecusEvent } from '../../../code/mail/logging/testopithecus-event';
import { Nullable } from '../../../ys/ys';
import { MailContext } from '../mail-context';
import { MailEvaluation } from '../mail-context-applier';

export abstract class FirstEventContextValueExtractor<T> implements MailEvaluation<Nullable<T>> {

  private value: Nullable<T> = null
  private valueSet = false

  protected constructor(private evaluationName: string) { }

  public name(): string {
    return this.evaluationName;
  }

  public acceptEvent(event: TestopithecusEvent, context: MailContext): any {
    if (!this.valueSet) {
      this.value = this.extractValue(event, context)
    }
  }

  public result(): Nullable<T> {
    return this.value;
  }

  public abstract extractValue(event: TestopithecusEvent, context: MailContext): T

}
