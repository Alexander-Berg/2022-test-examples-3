import { TestopithecusEvent } from '../../../code/mail/logging/testopithecus-event';
import { Int32 } from '../../../ys/ys';
import { ContextFreeEvaluation } from './context-free-evaluation';

export class FirstEventEvaluation implements ContextFreeEvaluation<Int32> {

  private eventNumber: Int32 = 0
  private initTimestamp: Int32 = 0
  private timestampDiff: Int32 = 0

  public name(): string {
    return 'first-event';
  }

  public acceptEvent(action: TestopithecusEvent): any {
    if (this.eventNumber === 0) {
      this.initTimestamp = action.value.get('timestamp')
    } else if (this.eventNumber === 1) {
      this.timestampDiff = action.value.get('timestamp') - this.initTimestamp
    }
    this.eventNumber += 1
  }

  public result(): Int32 {
    return this.timestampDiff
  }
}
