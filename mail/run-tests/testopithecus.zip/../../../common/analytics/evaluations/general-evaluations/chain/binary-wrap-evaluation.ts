import { TestopithecusEvent } from '../../../../code/mail/logging/testopithecus-event';
import { Evaluation } from '../../evaluation';
import { ContextFreeEvaluation } from '../context-free/context-free-evaluation';

export abstract class BinaryWrapEvaluation<T, U, V, C> implements Evaluation<T, C> {

  protected constructor(private firstEvaluation: Evaluation<U, C>, private secondEvaluation: Evaluation<V, C>) { }

  public acceptEvent(event: TestopithecusEvent, context: C): any {
    this.firstEvaluation.acceptEvent(event, context)
    this.secondEvaluation.acceptEvent(event, context)
  }

  public abstract name(): string

  public abstract wrap(first: U, second: V): T

  public result(): T {
    return this.wrap(this.firstEvaluation.result(), this.secondEvaluation.result());
  }

}

export abstract class ContextFreeBinaryWrapEvaluation<T, U, V> extends BinaryWrapEvaluation<T, U, V, null> implements ContextFreeEvaluation<T> {

  public acceptEvent(event: TestopithecusEvent): void {
    super.acceptEvent(event, null)
  }

}
