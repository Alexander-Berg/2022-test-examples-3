import { TestopithecusEvent } from '../../../../../code/mail/logging/testopithecus-event';
import { Nullable } from '../../../../../ys/ys';
import { InitiatorEventEvaluation } from '../../context-free/initiator-event-evaluation';
import { ContextFreeWrapEvaluation} from '../wrap-evaluation';

export class InitiatorNameEventEvaluation extends ContextFreeWrapEvaluation<Nullable<string>, Nullable<TestopithecusEvent>> {

  public constructor() {
    super(new InitiatorEventEvaluation())
  }

  public name(): string {
    return 'initiator_name';
  }

  public wrap(value: Nullable<TestopithecusEvent>): Nullable<string> {
    return value === null ? null : value.name;
  }

}
