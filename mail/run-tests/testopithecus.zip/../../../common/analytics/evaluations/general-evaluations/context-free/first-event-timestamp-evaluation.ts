import { TestopithecusEvent } from '../../../../code/mail/logging/testopithecus-event';
import { Int64 } from '../../../../ys/ys';
import { ContextFreeEvaluation } from './context-free-evaluation';

export class FirstEventTimestampEvaluation implements ContextFreeEvaluation<Int64> {

  private timestamp: Int64 = -1n

  public name(): string {
    return 'start_timestamp_ms';
  }

  public acceptEvent(event: TestopithecusEvent): any {
    if (this.timestamp === -1n) {
      this.timestamp = event.value.get('timestamp')
    }
  }

  public result(): Int64 {
    return this.timestamp
  }
}
