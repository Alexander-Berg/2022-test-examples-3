import { TestopithecusEvent } from '../../../../../code/mail/logging/testopithecus-event'
import { Int64, Nullable } from '../../../../../ys/ys'
import { ParsingUtils } from '../../../../processing/parsing-utils'
import { FinalizerEventEvaluation } from '../../context-free/finalizer-event-evaluation'
import { ContextFreeWrapEvaluation} from '../wrap-evaluation'

export class LastEventTimestampEvaluation extends ContextFreeWrapEvaluation<Nullable<Int64>, Nullable<TestopithecusEvent>> {

  public constructor() {
    super(new FinalizerEventEvaluation())
  }

  public name(): string {
    return 'last_timestamp_ms'
  }

  public wrap(value: Nullable<TestopithecusEvent>): Nullable<Int64> {
    return value === null ? null : ParsingUtils.demandTimestamp(value)
  }

}
