import { TestopithecusEvent } from '../../../../../code/mail/logging/testopithecus-event';
import { Nullable } from '../../../../../ys/ys';
import { BaseCounterEvaluation } from './base-counter-evaluation';

export class EventCounterEvaluation extends BaseCounterEvaluation {

  private readonly eventName: string
  private readonly evaluationName: Nullable<string>

  constructor(targetEventName: string, evaluationName: Nullable<string> = null) {
    super()
    this.eventName = targetEventName
    this.evaluationName = evaluationName
  }

  public name(): string {
    return this.evaluationName === null ? this.eventName : this.evaluationName;
  }

  protected matches(event: TestopithecusEvent): boolean {
    return event.name === this.eventName;
  }

}
