import { TestopithecusEvent } from '../../../code/mail/logging/testopithecus-event';
import { Evaluation } from '../evaluation';

export interface ContextFreeEvaluation<T> extends Evaluation<T, null> {

  acceptEvent(event: TestopithecusEvent): any

}
