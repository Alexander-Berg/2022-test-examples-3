import { TestopithecusEvent } from '../../../../code/mail/logging/testopithecus-event';
import { Scenario } from '../../../scenario';
import { ContextFreeEvaluation } from './context-free-evaluation';

export class FullScenarioEvaluation<C> implements ContextFreeEvaluation<Scenario> {

  private scenario: Scenario = new Scenario()

  public name(): string {
    return 'full_scenario';
  }

  public acceptEvent(event: TestopithecusEvent): any {
    this.scenario.thenEvent(event)
  }

  public result(): Scenario {
    return this.scenario
  }
}
