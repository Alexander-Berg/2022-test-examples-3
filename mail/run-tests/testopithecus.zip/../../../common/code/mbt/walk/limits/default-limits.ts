import { ActionLimitsStrategy } from "./action-limits-strategy";
import { Stack } from "../data-structures/stack";
import { MBTAction } from "../../mbt-abstractions";
import { PersonalActionLimits } from "./personal-action-limits";
import { Int32 } from "../../../../ys/ys";

export class DefaultLimits implements ActionLimitsStrategy {
  private personalLimits: PersonalActionLimits;

  constructor() {
    const totalLimit: Int32 = 1000;
    const actionLimits: Map<string, Int32> = new Map<string, Int32>();
    actionLimits.set('ReplyMessageAction', 2);
    actionLimits.set('SendMessage', 2);
    this.personalLimits = new PersonalActionLimits(totalLimit, actionLimits);
  }

  check(actions: Stack<MBTAction>): boolean {
    return this.personalLimits.check(actions);
  }

}
