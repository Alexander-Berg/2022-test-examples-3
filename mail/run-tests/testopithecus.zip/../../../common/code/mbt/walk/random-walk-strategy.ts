import { Int32, Nullable } from '../../../ys/ys';
import { PseudoRandomProvider } from '../../utils/pseudo-random';
import { RandomProvider } from '../../utils/random';
import { Registry } from '../../utils/registry';
import { MBTAction, MBTComponent } from '../mbt-abstractions';
import { WalkStrategy } from '../state-machine';

export class RandomWalkStrategy implements WalkStrategy {
  public readonly history: MBTAction[] = []
  private currentStep: Int32 = 0

  constructor(private stepsLimit: Nullable<Int32> = null, private random: RandomProvider = PseudoRandomProvider.INSTANCE) {
  }

  public nextAction(possibleActions: MBTAction[], component: MBTComponent): Nullable<MBTAction> {
    if (possibleActions.length === 0) {
      return null;
    }
    if (this.currentStep === this.stepsLimit) {
      return null
    }
    const order = this.random.generate(possibleActions.length);
    const action = possibleActions[order]
    this.history.push(action)
    this.currentStep += 1
    return action
  }
}
