import { Nullable } from '../../ys/ys';
import { LoginComponent } from '../mail/components/login-component';
import { ImapMailboxBuilderManager, ImapMessage } from '../mail/mailbox-preparer';
import { FeatureID } from '../mbt/mbt-abstractions';
import { MultiRunner } from '../mbt/walk/dfs-walk-strategy';
import { AccountType, AppModelProvider, MBTTest, TestPlan } from '../mbt/walk/fixed-scenario-strategy';
import { OAuthUserAccount } from '../users/user-pool';
import { Logger } from '../utils/logger';

export class FullCoverageTest implements MBTTest {
  constructor(private logger: Logger) {
  }

  public requiredAccounts(): AccountType[] {
    return [AccountType.Yandex];
  }

  public description(): string {
    return 'should cover all application'
  }

  public prepareMailbox(builderManager: ImapMailboxBuilderManager): ImapMailboxBuilderManager {
    return builderManager.addMessageToInbox(ImapMessage.create('subj'));
  }

  public scenario(accounts: OAuthUserAccount[], modelProvider: Nullable<AppModelProvider>, supportedFeatures: FeatureID[]): TestPlan {
    if (modelProvider === null) {
      return TestPlan.createSimpleTestPlan()
    }
    const userAccounts = accounts.map((oauthAcc) => oauthAcc.account);
    const runner = new MultiRunner(new LoginComponent(userAccounts), modelProvider, supportedFeatures, this.logger);
    const path = runner.preparePath()
    const pathLength = path.length
    this.logger.log(`Optimal path length: ${pathLength}`)
    return TestPlan.createSimpleTestPlan().thenChain(path);
  }

}
