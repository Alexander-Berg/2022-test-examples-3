export class RuntimeClassInfo {
  public constructor(public readonly name: string) { }
}
