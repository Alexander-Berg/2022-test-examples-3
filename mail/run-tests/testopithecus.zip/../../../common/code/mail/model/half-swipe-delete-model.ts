import { HalfSwipeDelete } from '../mail-features';
import { DeleteMessageModel } from './base-models/delete-message-model';

export class HalfSwipeDeleteModel implements HalfSwipeDelete {
  constructor(private deleteMessage: DeleteMessageModel) {
  }

  public deleteMessageByHalfSwipe(order: number): void {
    this.deleteMessage.deleteMessage(order)
  }

}
