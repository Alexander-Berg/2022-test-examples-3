import { Int32 } from '../../../ys/ys';
import { MovableToFolder } from '../mail-features';
import { FolderName } from './mail-model';
import { MessageListDisplayModel } from './message-list-display-model';

export class MovableToFolderModel implements MovableToFolder {
  constructor(public model: MessageListDisplayModel) {
  }

  public moveMessageToFolder(order: Int32, folderName: FolderName): void {
    const mids = this.model.getMessageThreadByOrder(order)
    for (const mid of mids) {
      this.model.moveMessageToFolder(mid, folderName);
    }
  }
}
