import { CustomMailServiceLogin } from '../../mail-features';
import { MailAppModelHandler } from '../mail-model';

export class CustomMailServiceLoginModel implements CustomMailServiceLogin {

  public constructor(public accountDataHandler: MailAppModelHandler) {
  }

  public loginWithCustomMailServiceAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password);
  }

  public multiLoginWithCustomMailServiceAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password)
  }
}