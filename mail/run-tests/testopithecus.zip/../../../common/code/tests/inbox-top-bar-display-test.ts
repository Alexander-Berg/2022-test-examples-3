import { Int32, Int64, Nullable } from '../../ys/ys'
import { ImapMailboxBuilder, ImapMessage } from '../mail/mailbox-preparer'
import { MBTPlatform, RegularYandexTestBase, TestSettings } from '../mbt/mbt-test'
import { TestPlan } from '../mbt/walk/fixed-scenario-strategy'
import { UserAccount } from '../users/user-pool'

export class InboxTopBarDisplayTest extends RegularYandexTestBase {
  constructor() {
    super('Отображение топ бара в списке писем Инбокса')
  }

  public testSettings(): TestSettings {
    return TestSettings.regular()
      .androidCase(2300)
      .iosCase(874)
  }

  public prepareMailbox(builder: ImapMailboxBuilder): void {
    builder.nextMessage('subj')
  }

  public regularScenario(account: UserAccount): TestPlan {
    return TestPlan.yandexLogin(account)
  }
}
