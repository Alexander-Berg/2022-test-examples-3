import { GoogleLogin } from '../../mail-features';
import { MailAppModelHandler } from '../mail-model';

export class GoogleLoginModel implements GoogleLogin {

  public constructor(public accountDataHandler: MailAppModelHandler) {
  }

  public loginWithGoogleAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password);
  }

  public multiLoginWithGoogleAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password);
  }
}