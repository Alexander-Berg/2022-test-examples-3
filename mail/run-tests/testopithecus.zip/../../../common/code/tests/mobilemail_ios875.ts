import { DeleteMessageAction } from '../mail/actions/delete-message'
import { ImapMailboxBuilder, ImapMessage } from '../mail/mailbox-preparer'
import { RegularYandexTestBase, TestSettings } from '../mbt/mbt-test'
import { TestPlan } from '../mbt/walk/fixed-scenario-strategy'
import { UserAccount } from '../users/user-pool'

export class SwipeToDeleteTest extends RegularYandexTestBase {
  constructor() {
    super('mobmail_ios-875: Swipe to delete: письмо в Инбоксе')
  }

  public testSettings(): TestSettings {
    return TestSettings.regular()
      .iosCase(875)
  }

  public prepareMailbox(builder: ImapMailboxBuilder): void {
    builder.nextMessage('subj')
  }

  public regularScenario(account: UserAccount): TestPlan {
    return TestPlan.yandexLogin(account)
      .then(new DeleteMessageAction(0))
  }
}
