import { UserAccount } from '../../users/user-pool';
import { UsersGetter } from '../mail-features';
import { MailAppModelHandler } from './mail-model';

export class UsersGetterModel implements UsersGetter {
  public constructor(public accountDataHandler: MailAppModelHandler) {
  }

  public getUsersWhoCanLogin(): UserAccount[] {
    return this.accountDataHandler.accountsData.map((accData) => accData.getAccount());
  }
}
