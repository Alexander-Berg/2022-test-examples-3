import { DeleteCurrentMessage } from '../mail/actions/delete-message'
import { OpenMessage } from '../mail/actions/open-message'
import { ImapMailboxBuilder, ImapMessage } from '../mail/mailbox-preparer'
import { RegularYandexTestBase, TestSettings } from '../mbt/mbt-test'
import { TestPlan } from '../mbt/walk/fixed-scenario-strategy'
import { UserAccount } from '../users/user-pool'

export class DeleteMessageFromMailviewTest extends RegularYandexTestBase {
  constructor() {
    super('Удаление единичного письма из просмотра')
  }

  public testSettings(): TestSettings {
    return TestSettings.regular()
      .iosCase(673)
      .androidCase(2046)
  }

  public prepareMailbox(builder: ImapMailboxBuilder): void {
    builder.nextMessage('subj')
  }

  public regularScenario(account: UserAccount): TestPlan {
    return TestPlan.yandexLogin(account)
      .then(new OpenMessage(0))
      .then(new DeleteCurrentMessage())
  }
}
