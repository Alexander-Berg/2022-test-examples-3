import { YandexLogin } from '../../mail-features';
import { MailAppModelHandler } from '../mail-model';

export class YandexLoginModel implements YandexLogin {

  public constructor(public accountDataHandler: MailAppModelHandler) {
  }

  public loginWithYandexAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password);
  }

  public multiLoginWithYandexAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password);
  }
}
