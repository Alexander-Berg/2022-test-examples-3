import { Int32, int64 } from '../../../ys/ys'
import { App, FeatureID, MBTAction, MBTActionType, MBTComponent, MBTHistory } from '../../mbt/mbt-abstractions'
import { Testopithecus } from '../logging/events/testopithecus'
import { TestopithecusEvent } from '../logging/testopithecus-event'
import { MessageListDisplayFeature, SpamableFeature } from '../mail-features'

export class MoveToSpamAction implements MBTAction {
  public static readonly type: MBTActionType = 'MoveToSpam'

  constructor(private order: Int32) {
  }

  public supported(modelFeatures: FeatureID[], applicationFeatures: FeatureID[]): boolean {
    return MessageListDisplayFeature.get.included(modelFeatures)
      && SpamableFeature.get.includedAll(modelFeatures, applicationFeatures)
  }

  public canBePerformed(model: App): boolean {
    const messageListDisplayModel = MessageListDisplayFeature.get.forceCast(model)
    const messages = messageListDisplayModel.getMessageList(this.order + 1)
    return messages.length > this.order
  }

  public perform(model: App, application: App, history: MBTHistory): MBTComponent {
    SpamableFeature.get.forceCast(model).moveToSpam(this.order)
    SpamableFeature.get.forceCast(application).moveToSpam(this.order)
    return history.currentComponent
  }

  public tostring(): string {
    return `MoveToSpam(#${this.order})`
  }

  public events(): TestopithecusEvent[] {
    return [
      Testopithecus.messageListEvents.openMessageActions(this.order, int64(-1)),
      Testopithecus.messageActionsEvents.markAsSpam(),
    ]
  }

  public getActionType(): MBTActionType {
    return MoveToSpamAction.type
  }
}
