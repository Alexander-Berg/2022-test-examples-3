import { YahooLogin } from '../../mail-features';
import { MailAppModelHandler } from '../mail-model';

export class YahooLoginModel implements YahooLogin {

  public constructor(public accountDataHandler: MailAppModelHandler) {
  }

  public loginWithYahooAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password);
  }

  public multiLoginWithYahooAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password)
  }
}
