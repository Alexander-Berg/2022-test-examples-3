import { MailRuLogin } from '../../mail-features';
import { MailAppModelHandler } from '../mail-model';

export class MailRuLoginModel implements MailRuLogin {

  public constructor(public accountDataHandler: MailAppModelHandler) {
  }

  public loginWithMailRuAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password);
  }

  public multiLoginWithMailRuAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password)
  }
}
