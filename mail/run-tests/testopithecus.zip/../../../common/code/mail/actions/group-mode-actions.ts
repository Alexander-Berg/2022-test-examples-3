import { Int32, int64 } from '../../../ys/ys'
import { BaseSimpleAction } from '../../mbt/base-simple-action'
import {
  App,
  Feature,
  FeatureID,
  MBTAction,
  MBTActionType,
  MBTComponent,
  MBTHistory,
} from '../../mbt/mbt-abstractions'
import { filterByOrders } from '../../utils/utils'
import { GroupOperationsComponent } from '../components/group-operations-component'
import { MaillistComponent } from '../components/maillist-component'
import { Testopithecus } from '../logging/events/testopithecus'
import { TestopithecusEvent } from '../logging/testopithecus-event'
import { GroupMode, GroupModeFeature, MessageListDisplayFeature } from '../mail-features'

export class SelectMessages extends BaseSimpleAction<GroupMode, MaillistComponent> {
  public static readonly type: MBTActionType = 'SelectMessages'

  constructor(private orders: Int32[]) {
    super(SelectMessages.type)
  }

  public requiredFeature(): Feature<GroupMode> {
    return GroupModeFeature.get
  }

  public canBePerformedImpl(model: GroupMode): boolean {
    return !model.isInGroupMode()
  }

  public events(): TestopithecusEvent[] {
    return this.orders.map((order) => Testopithecus.groupActionsEvents.selectMessage(order, int64(-1)))
  }

  public performImpl(modelOrApplication: GroupMode, currentComponent: MaillistComponent): MBTComponent {
    modelOrApplication.selectMessages(this.orders)
    return new GroupOperationsComponent()
  }

  public tostring(): string {
    return `SelectMessages(${this.orders})`
  }
}

export abstract class BaseMarkSelectedMessages implements MBTAction {
  constructor(private type: MBTActionType) {
  }

  public supported(modelFeatures: FeatureID[], applicationFeatures: FeatureID[]): boolean {
    return MessageListDisplayFeature.get.included(modelFeatures) && GroupModeFeature.get.includedAll(modelFeatures, applicationFeatures)
  }

  public canBePerformed(model: App): boolean {
    const messageListModel = MessageListDisplayFeature.get.forceCast(model)
    const groupModeModel = GroupModeFeature.get.forceCast(model)
    const selectedMessageOrders = groupModeModel.getSelectedMessages()
    if (selectedMessageOrders === null) {
      return false
    }
    const messages = messageListModel.getMessageList(10)
    const unreadCount = filterByOrders(messages, selectedMessageOrders!).filter((message) => !message.read).length
    return this.canBePerformedImpl(unreadCount)
  }

  public perform(model: App, application: App, history: MBTHistory): MBTComponent {
    this.performImpl(GroupModeFeature.get.forceCast(model))
    this.performImpl(GroupModeFeature.get.forceCast(application))
    return new MaillistComponent()
  }

  public abstract events(): TestopithecusEvent[]

  public abstract canBePerformedImpl(selectedUnreadCount: Int32): boolean

  public abstract performImpl(modelOrApplication: GroupMode): void

  public tostring(): string {
    return this.getActionType()
  }

  public getActionType(): MBTActionType {
    return this.type
  }
}

export class MarkAsReadSelectedMessages extends BaseMarkSelectedMessages {
  public static readonly type: MBTActionType = 'MarkAsReadSelectedMessages'

  constructor() {
    super(MarkAsReadSelectedMessages.type)
  }

  public canBePerformedImpl(selectedUnreadCount: Int32): boolean {
    return selectedUnreadCount > 0
  }

  public performImpl(modelOrApplication: GroupMode): void {
    modelOrApplication.markAsReadSelectedMessages()
  }

  public events(): TestopithecusEvent[] {
    return [Testopithecus.groupActionsEvents.markAsReadSelectedMessages()]
  }
}

export class MarkAsUnreadSelectedMessages extends BaseMarkSelectedMessages {
  public static readonly type: MBTActionType = 'MarkAsUnreadSelectedMessages'

  constructor() {
    super(MarkAsUnreadSelectedMessages.type)
  }

  public canBePerformedImpl(selectedUnreadCount: Int32): boolean {
    return selectedUnreadCount === 0
  }

  public performImpl(modelOrApplication: GroupMode): void {
    modelOrApplication.markAsUnreadSelectedMessages()
  }

  public events(): TestopithecusEvent[] {
    return [Testopithecus.groupActionsEvents.markAsUnreadSelectedMessages()]
  }
}

export class DeleteSelectedMessages implements MBTAction {
  public static readonly type: MBTActionType = 'DeleteSelectedMessages'

  public supported(modelFeatures: FeatureID[], applicationFeatures: FeatureID[]): boolean {
    return MessageListDisplayFeature.get.included(modelFeatures) && GroupModeFeature.get.includedAll(modelFeatures, applicationFeatures)
  }

  public canBePerformed(model: App): boolean {
    return true
  }

  public perform(model: App, application: App, history: MBTHistory): MBTComponent {
    GroupModeFeature.get.forceCast(model).deleteSelectedMessages()
    GroupModeFeature.get.forceCast(application).deleteSelectedMessages()
    return new MaillistComponent()
  }

  public events(): TestopithecusEvent[] {
    return [Testopithecus.groupActionsEvents.deleteSelectedMessages()]
  }

  public tostring(): string {
    return this.getActionType()
  }

  public getActionType(): MBTActionType {
    return DeleteSelectedMessages.type
  }
}
