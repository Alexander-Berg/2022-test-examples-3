import { DeleteCurrentMessage, DeleteMessageAction } from '../mail/actions/delete-message'
import { OpenMessage } from '../mail/actions/open-message'
import { ImapMailboxBuilder, ImapMessage } from '../mail/mailbox-preparer'
import { RegularYandexTestBase } from '../mbt/mbt-test'
import { TestPlan } from '../mbt/walk/fixed-scenario-strategy'
import { UserAccount } from '../users/user-pool'

export class DeleteThreadTest extends RegularYandexTestBase {
  constructor() {
    super('should delete all messages in thread')
  }

  public prepareMailbox(mailbox: ImapMailboxBuilder): void {
    mailbox.nextThread('thread_subj', 4)
  }

  public regularScenario(account: UserAccount): TestPlan {
    return TestPlan.yandexLogin(account)
      .then(new DeleteMessageAction(0))
  }
}

export class DeleteMessageTest extends RegularYandexTestBase {
  constructor() {
    super('should delete message')
  }

  public prepareMailbox(mailbox: ImapMailboxBuilder): void {
    mailbox.nextMessage('subj')
  }

  public regularScenario(account: UserAccount): TestPlan {
    return TestPlan.yandexLogin(account)
      .then(new DeleteMessageAction(0))
  }
}

export class DeleteCurrentMessageTest extends RegularYandexTestBase {
  constructor() {
    super('should delete current message')
  }

  public prepareMailbox(mailbox: ImapMailboxBuilder): void {
    mailbox.nextMessage('subj')
  }

  public regularScenario(account: UserAccount): TestPlan {
    return TestPlan.yandexLogin(account)
      .then(new OpenMessage(0))
      .then(new DeleteCurrentMessage())
  }
}
