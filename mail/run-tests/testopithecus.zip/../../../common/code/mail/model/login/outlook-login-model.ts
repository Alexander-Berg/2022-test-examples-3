import { OutlookLogin } from '../../mail-features';
import { MailAppModelHandler } from '../mail-model';

export class OutlookLoginModel implements OutlookLogin {

  public constructor(public accountDataHandler: MailAppModelHandler) {
  }

  public loginWithOutlookAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password);
  }

  public multiLoginWithOutlookAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password)
  }
}
