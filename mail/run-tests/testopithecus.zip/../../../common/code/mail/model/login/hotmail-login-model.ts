import { HotmailLogin } from '../../mail-features';
import { MailAppModelHandler } from '../mail-model';

export class HotmailLoginModel implements HotmailLogin {

  public constructor(public accountDataHandler: MailAppModelHandler) {
  }

  public loginWithHotmailAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password);
  }

  public multiLoginWithHotmailAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password);
  }
}