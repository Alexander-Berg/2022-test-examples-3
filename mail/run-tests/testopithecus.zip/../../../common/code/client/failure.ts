import { Nullable } from '../../ys/ys'

export interface Failure {
  readonly message: Nullable<string>
}
