import { Int32 } from '../../../ys/ys'
import { App, FeatureID, MBTAction, MBTActionType, MBTComponent, MBTHistory } from '../../mbt/mbt-abstractions'
import { Testopithecus } from '../logging/events/testopithecus'
import { TestopithecusEvent } from '../logging/testopithecus-event'
import {
  ContextMenuFeature, HalfSwipeDelete,
  HalfSwipeDeleteFeature,
  MessageListDisplayFeature,
  MessageView,
} from '../mail-features'

export abstract class BaseHalfSwipeAction implements MBTAction {
  constructor(protected order: Int32, private type: MBTActionType) {
  }

  public supported(modelFeatures: FeatureID[], applicationFeatures: FeatureID[]): boolean {
    return ContextMenuFeature.get.includedAll(modelFeatures, applicationFeatures)
  }

  public canBePerformed(model: App): boolean {
    const messageListModel = MessageListDisplayFeature.get.forceCast(model)
    const messages = messageListModel.getMessageList(10)
    return this.order < messages.length && this.canBePerformedImpl(messages[this.order])
  }

  public perform(model: App, application: App, history: MBTHistory): MBTComponent {
    this.performImpl(HalfSwipeDeleteFeature.get.forceCast(model))
    this.performImpl(HalfSwipeDeleteFeature.get.forceCast(application))
    return history.currentComponent
  }

  public abstract canBePerformedImpl(message: MessageView): boolean

  public abstract performImpl(modelOrApplication: HalfSwipeDelete): void

  public event(): TestopithecusEvent {
    return Testopithecus.stubEvent()
  }

  public getActionType(): MBTActionType {
    return this.type
  }

  public abstract tostring(): string
}

export class DeleteMessageByHalfSwipe extends BaseHalfSwipeAction {
  public static readonly type: MBTActionType = 'DeleteMessageByHalfSwipe'

  constructor(order: Int32) {
    super(order, DeleteMessageByHalfSwipe.type)
  }

  public canBePerformedImpl(message: MessageView): boolean {
    return true
  }

  public performImpl(modelOrApplication: HalfSwipeDelete): void {
    modelOrApplication.deleteMessageByHalfSwipe(this.order)
  }

  public tostring(): string {
    return `DeleteMessageByFullSwipe(${this.order})`
  }
}
