import { Int32, Int64, Nullable } from '../../../ys/ys';
import { currentTimeMs } from '../../utils/utils';
import { Spamable } from '../mail-features';
import { MarkableReadModel } from './base-models/markable-read-model';
import { DefaultFolderName } from './mail-model';
import { MessageListDisplayModel } from './message-list-display-model';

export class SpamableModel implements Spamable {
  private lastMoveToSpamTime: Nullable<Int64> = null

  constructor(private messageListDisplayModel: MessageListDisplayModel, private markableModel: MarkableReadModel) {
  }

  public moveToSpam(order: Int32): void {
    this.markableModel.markAsRead(order) // Разная логика в iOS приложении и на Web-е
    for (const mid of this.messageListDisplayModel.getMessageThreadByOrder(order)) {
      this.messageListDisplayModel.accountDataHandler.getCurrentAccount().folderToMessages.forEach((msgIds, folder) => {
        msgIds.delete(mid);
      });
      this.messageListDisplayModel.accountDataHandler.getCurrentAccount()
        .folderToMessages.get(DefaultFolderName.spam)!.add(mid);
    }
    this.lastMoveToSpamTime = currentTimeMs()
  }

  public toastShown(): boolean {
    if (this.lastMoveToSpamTime === null) {
      return false
    }
    return currentTimeMs() - this.lastMoveToSpamTime! < 5000;
  }
}
