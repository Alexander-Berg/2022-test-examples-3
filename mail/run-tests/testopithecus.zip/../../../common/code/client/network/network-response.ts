import { Codable } from '../../../ys/ys'

// tslint:disable-next-line:no-empty-interface
export interface NetworkResponse extends Codable { }
