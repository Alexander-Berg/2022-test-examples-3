import { RamblerLogin } from '../../mail-features';
import { MailAppModelHandler } from '../mail-model';

export class RamblerLoginModel implements RamblerLogin {

  public constructor(public accountDataHandler: MailAppModelHandler) {
  }

  public loginWithRamblerAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password);
  }

  public multiLoginWithRamblerAccount(login: string, password: string): void {
    this.accountDataHandler.logInToAccount(login, password)
  }

}
