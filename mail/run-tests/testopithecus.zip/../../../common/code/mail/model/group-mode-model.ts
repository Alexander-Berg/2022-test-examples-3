import { Int32, Nullable } from '../../../ys/ys';
import { requireNonNull } from '../../utils/utils';
import { GroupMode } from '../mail-features';
import { DeleteMessageModel } from './base-models/delete-message-model';
import { MarkableReadModel } from './base-models/markable-read-model';

export class GroupModeModel implements GroupMode {
  public selectedOrders: Nullable<Int32[]> = null;

  constructor(private markableModel: MarkableReadModel, private deleteMessageModel: DeleteMessageModel) {
  }

  public getSelectedMessages(): Nullable<Int32[]> {
    return this.selectedOrders
  }

  public isInGroupMode(): boolean {
    return this.selectedOrders !== null;
  }

  public markAsReadSelectedMessages(): void {
    const selectedMessages = requireNonNull(this.selectedOrders, 'Should select messages before!')
    selectedMessages.forEach((order) => this.markableModel.markAsRead(order));
    this.selectedOrders = null
  }

  public markAsUnreadSelectedMessages(): void {
    const selectedMessages = requireNonNull(this.selectedOrders, 'Should select messages before!')
    selectedMessages.forEach((order) => this.markableModel.markAsUnread(order));
    this.selectedOrders = null
  }

  public deleteSelectedMessages(): void {
    const selectedMessages = requireNonNull(this.selectedOrders, 'Should select messages before!')
    selectedMessages.sort((m1, m2) => m2 - m1).forEach((order) => this.deleteMessageModel.deleteMessage(order));
    this.selectedOrders = null
  }

  public selectMessages(byOrders: Int32[]): void {
    this.selectedOrders = byOrders
  }

  public copy(): GroupModeModel {
    const copy = new GroupModeModel(this.markableModel, this.deleteMessageModel)
    copy.selectedOrders = this.selectedOrders
    return copy
  }
}
