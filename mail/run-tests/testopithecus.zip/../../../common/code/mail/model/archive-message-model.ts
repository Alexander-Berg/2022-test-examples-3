import { Int64, Nullable } from '../../../ys/ys'
import { currentTimeMs } from '../../utils/utils'
import { ArchiveMessage } from '../mail-features'
import { DefaultFolderName } from './mail-model'
import { MessageListDisplayModel } from './message-list-display-model'

export class ArchiveMessageModel implements ArchiveMessage {
  private lastArchiveMessageTime: Nullable<Int64> = null

  constructor(private model: MessageListDisplayModel) {
  }

  public archiveMessage(order: number): void {
    const folderToMessages = this.model.accountDataHandler.getCurrentAccount().folderToMessages

    if (!folderToMessages.has(DefaultFolderName.archive)) {
      folderToMessages.set(DefaultFolderName.archive, new Set())
    }
    const mids = this.model.getMessageThreadByOrder(order)
    for (const mid of mids) {
      this.model.moveMessageToFolder(mid, DefaultFolderName.archive)
    }
    this.lastArchiveMessageTime = currentTimeMs()
}

  public toastShown(): boolean {
    if (this.lastArchiveMessageTime === null) {
      return false
    }
    return currentTimeMs() - this.lastArchiveMessageTime! < 5000
  }

}
