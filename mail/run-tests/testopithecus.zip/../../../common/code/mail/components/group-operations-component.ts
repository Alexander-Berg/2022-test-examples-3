import { App, MBTAction, MBTComponent, MBTComponentType } from '../../mbt/mbt-abstractions'
import { MBTComponentActions } from '../../mbt/walk/behaviour/user-behaviour'
import {
  MarkAsReadSelectedMessages,
  MarkAsUnreadSelectedMessages,
} from '../actions/group-mode-actions'
import { RotatableAction } from '../actions/rotatable-actions'

export class GroupOperationsComponent implements MBTComponent {
  public static readonly type: MBTComponentType = 'GroupOperationsComponent'

  public assertMatches(model: App, application: App): void {
  }

  public tostring(): string {
    return this.getComponentType()
  }

  public getComponentType(): MBTComponentType {
    return GroupOperationsComponent.type
  }
}

export class AllGroupOperationsActions implements MBTComponentActions {
  public getActions(model: App): MBTAction[] {
    const actions: MBTAction[] = []
    actions.push(new MarkAsReadSelectedMessages())
    actions.push(new MarkAsUnreadSelectedMessages())
    RotatableAction.addActions(actions)
    return actions
  }
}
