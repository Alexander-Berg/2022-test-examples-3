import { AnalyticsRunner } from '../../../analytics/analytics-runner';
import { FirstEventEvaluation } from '../../../analytics/evaluations/general-evaluations/context-free/first-event-evaluation';
import { FirstEventTimestampEvaluation } from '../../../analytics/evaluations/general-evaluations/context-free/first-event-timestamp-evaluation';
import { LastEventTimestampEvaluation } from '../../../analytics/evaluations/general-evaluations/context-free/last-event-timestamp-evaluation';
import { Scenario } from '../../../analytics/scenario';
import { Testopithecus } from '../../../code/mail/logging/events/testopithecus';
import { checkEvaluationsResults, setTimeline } from '../utils/utils';

describe('First and last evaluation timestamp event evaluation', () => {
  it('should be correct for usual scenario', (done) => {
    const session = new Scenario()
      .thenEvent(Testopithecus.startEvents.startWithMessageListShow())
      .thenEvent(Testopithecus.messageListEvents.markMessageAsRead(0, 1n))
      .thenEvent(Testopithecus.messageListEvents.deleteMessage(0, 2n))
    setTimeline(session, [10n, 100n, 1000n])

    const evaluations = [new FirstEventEvaluation(), new FirstEventTimestampEvaluation(), new LastEventTimestampEvaluation()]
    const runner = new AnalyticsRunner()
    const results = runner.evaluate(session, evaluations)

    checkEvaluationsResults(evaluations, results, [90n, 10n, 1000n])
    done()
  });
  it('should be correct for empty scenario', (done) => {
    const session = new Scenario()

    const evaluations = [new FirstEventEvaluation(), new FirstEventTimestampEvaluation(), new LastEventTimestampEvaluation()]
    const runner = new AnalyticsRunner()
    const results = runner.evaluate(session, evaluations)

    checkEvaluationsResults(evaluations, results, [0n, -1n, -1n])
    done()
  });
  it('should be correct for one event scenario', (done) => {
    const session = new Scenario()
      .thenEvent(Testopithecus.startEvents.startWithMessageListShow())
    setTimeline(session, [10n])

    const evaluations = [new FirstEventEvaluation(), new FirstEventTimestampEvaluation(), new LastEventTimestampEvaluation()]
    const runner = new AnalyticsRunner()
    const results = runner.evaluate(session, evaluations)

    checkEvaluationsResults(evaluations, results, [0n, 10n, 10n])
    done()
  });
});
