import { EventReporter } from '../../../code/mail/logging/event-reporter';
import { TestopithecusEvent } from '../../../code/mail/logging/testopithecus-event';
import { TestopithecusRegistry } from '../../../code/mail/logging/testopithecus-registry';

export class StackReporter implements EventReporter {

  public events: TestopithecusEvent[] = []

  public report(event: TestopithecusEvent): void {
    this.events.push(event)
  }

}

export function initStackReporterInRegistry(): StackReporter {
  const reporter = new StackReporter()
  TestopithecusRegistry.setEventReporter(reporter)
  return reporter
}
