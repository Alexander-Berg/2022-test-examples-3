import { UserAccount } from '../code/users/user-pool';

export const PRIVATE_BACKEND_CONFIG = {
  account: new UserAccount('yandex-team-47907-42601@yandex.ru', 'simple123456'),
};
