(async() => {
    // var stdin = fs.readFileSync(0); // STDIN_FILENO = 0
    // const tasks = stdin.toString().trim().split('\n').map(line => JSON.parse(line));
    console.log('{ "key": "Hi there1" }')
    console.log('{ "key": "Hi there2" }')
    // processTasks(tasks, config).then(pages => {
    //     for (let page of pages) {
    //         for (let document of page) {
    //             console.log(JSON.stringify(document));
    //         }
    //     }
    // }).catch(error => {
    //     console.error(error);
    //     process.exit(1);
    // });
})();