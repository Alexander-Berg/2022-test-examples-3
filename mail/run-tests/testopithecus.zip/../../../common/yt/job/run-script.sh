#!/bin/bash

node script.js yt_config.json
